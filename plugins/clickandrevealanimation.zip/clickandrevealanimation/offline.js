﻿{
	"version": 1621495149,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/idealogosheet-sheet0.png",
		"images/button-sheet0.png",
		"images/placeholder-sheet0.png",
		"images/sprite-sheet0.png",
		"media/completing an activity.ogg",
		"media/correct.ogg",
		"media/error.ogg",
		"media/menu buttons.ogg",
		"media/completing an activity.m4a",
		"media/correct.m4a",
		"media/error.m4a",
		"media/menu buttons.m4a",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"ideadata.json"
	]
}
﻿{
	"version": 1629275545,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/submitbutton-sheet0.png",
		"images/submitbutton-sheet1.png",
		"images/questionbackgroundasset-sheet0.png",
		"images/questioninicator-sheet0.png",
		"media/menu buttons.ogg",
		"media/menu buttons.m4a",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"ideadata.json",
		"ai-track.min.js",
		"trans.css",
		"ideaLogo.png",
		""
	]
}
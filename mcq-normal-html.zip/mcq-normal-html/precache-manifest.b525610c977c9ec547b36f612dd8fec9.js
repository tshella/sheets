self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "31245368e6f313525feb6593691bd328",
    "url": "./index.html"
  },
  {
    "revision": "a314ef6bf40b9e0cc045",
    "url": "./static/css/2.0d8453b2.chunk.css"
  },
  {
    "revision": "e8fc95a59f408af89f04",
    "url": "./static/css/main.51f2c768.chunk.css"
  },
  {
    "revision": "a314ef6bf40b9e0cc045",
    "url": "./static/js/2.2e8fda0a.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.2e8fda0a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e8fc95a59f408af89f04",
    "url": "./static/js/main.417e56e0.chunk.js"
  },
  {
    "revision": "e5d41724520affeeb43f",
    "url": "./static/js/runtime-main.6403f257.js"
  },
  {
    "revision": "1b0ec7bf5494b51202013cd09ec83ff3",
    "url": "./static/media/click.1b0ec7bf.ogg"
  },
  {
    "revision": "f996ccbcce3590a27cb8cd39be728a79",
    "url": "./static/media/click.f996ccbc.m4a"
  }
]);
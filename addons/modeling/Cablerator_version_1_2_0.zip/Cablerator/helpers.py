import bpy
import sys
from .lib import *
from .ui import *
from .inits import *
class OBJECT_OT_cablerator_helper_add_point(bpy.types.Operator):
  """Click on a bezier point"""
  bl_idname = "object.cablerator_helper_add_point"
  bl_label = "Cablerator: Add Bezier Point at Mouse Cursor"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = False
      if ob and ob.type == 'CURVE':
        edit_condition = True
      return context.area.type == "VIEW_3D" and edit_condition
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif (event.ctrl or event.oskey) and event.type == 'Z' and event.value == 'PRESS':
        if len(self.items):
          bpy.ops.ed.undo()
          self.ob = context.view_layer.objects.active
          switch_mode('EDIT')
          self.items.pop()
        else:
          pass
      elif event.type == 'LEFTMOUSE' and event.value == "RELEASE":
        mode = bpy.context.active_object.mode
        switch_mode('OBJECT')
        clone_curve = duplicate_object(context.view_layer.objects.active, False)
        clone_curve.name = 'TEMP curve clone'
        clone_curve.data.bevel_depth = 0
        clone_curve.data.bevel_object = None
        clone_curve.data.resolution_u = 100
        super_select(clone_curve, context)
        bpy.ops.object.convert(target='MESH')
        switch_mode('EDIT')
        picked_point_length,picked_point_index = find_closest_point(context, event, clone_curve)
        switch_mode('OBJECT')
        bpy.data.objects.remove(clone_curve, do_unlink=True)
        super_select(self.ob, context)
        t,spline,pindex = get_t(self.ob, picked_point_index)
        switch_mode('EDIT')
        if t in [0,1]:
          self.report({'WARNING'}, "Can't add point at the beginning or end of the curve")
          return {'RUNNING_MODAL'}
        create_new_bezier_point(t, self.ob, spline, pindex)
        self.items.append([spline, pindex + 1])
        bpy.ops.ed.undo_push(message="Add a Bezier Point")
      elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    self.title = 'Add Bezier points (Esc to finish)'
    if sys.platform == 'darwin':
      self.empty = ['Cmd+Z to Undo']
    else:
      self.empty = ['Ctrl+Z to Undo']
    self.items = []
    self.ob = context.view_layer.objects.active
    switch_mode('OBJECT')
    super_select(context.view_layer.objects.active, context)
    switch_mode('EDIT')
    bpy.ops.ed.undo_push(message="Add a Bezier Point")
    get_prefs(self, context)
    self.show_curve_length = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    init_font_settings(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
class OBJECT_OT_cablerator_helper_add_circle(bpy.types.Operator):
  """Click on a poly curve circle at 3D Cursor location"""
  bl_idname = "object.cablerator_helper_add_circle"
  bl_label = "Cablerator: Add Polycurve Circle at 3D Cursor Location"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      return context.area.type == "VIEW_3D"
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
          if event.value == 'PRESS':
              self.is_shift = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_shift = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
          if event.value == 'PRESS':
              self.is_ctrl = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_ctrl = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in self.events.keys() and event.value == "PRESS":
          self.first_mouse_x = event.mouse_x
          for key in self.events.keys():
              if event.type == key:
                  if self.events[key]['status']:
                      self.events[key]['status'] = False
                  else:
                      self.events[key]['status'] = True
                      self.first_value = self.events[key]['cur_value']
                      self.first_unchanged_value = self.events[key]['cur_value']
                      self.cur_value = self.events[key]['cur_value']
              else:
                  self.events[key]['status'] = False
          return {'RUNNING_MODAL'}
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif event.type == 'MOUSEMOVE':
          for key in self.events.keys():
              if self.events[key]['status']:
                  if self.is_shift:
                      delta = 1200
                  else:
                      delta = 60
                  if self.is_ctrl:
                      self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  else:
                      self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  if key == 'S':
                      if self.cur_value < 0.001:
                          self.cur_value = 0.001
                          self.events[key]['cur_value'] = 0.001
                      build_circle(self.curve, self.events['D']['cur_value'], self.events['S']['cur_value'])
                  elif key == 'D':
                      if self.cur_value < 3:
                          self.cur_value = 3
                          self.events[key]['cur_value'] = 3
                      build_circle(self.curve, self.events['D']['cur_value'], self.events['S']['cur_value'])
      if event.type == 'LEFTMOUSE' and event.value == "PRESS":
          for ev in self.events:
              if self.events[ev]['status']:
                  self.events[ev]['status'] = not self.events[ev]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          return {'FINISHED'}
      if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['cur_value'] = self.first_unchanged_value
                  build_circle(self.curve, self.events['D']['cur_value'], self.events['S']['cur_value'])
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          bpy.data.objects.remove(self.curve, do_unlink=True)
          return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    self.active_curve = get_active_curve()
    self.title = 'Add Polycurve Circle'
    self.circle_points = 12
    self.width = .1
    get_prefs(self, context)
    self.show_curve_length = False
    if self.active_curve['width'] != 0 and self.active_curve['width'] != None:
      self.width = self.active_curve['width']
    self.events = {
        'D': {
            'name': 'Points Number (D)',
            'status': False,
            'cur_value': self.circle_points,
            'type': 'int',
            'show': True
        },
        'S': {
            'name': 'Radius (S)',
            'status': False,
            'cur_value': self.width,
            'type': 'float',
            'show': True
        },
    }
    self.curve = create_circle(self.events['D']['cur_value'], self.events['S']['cur_value'])
    self.first_mouse_x = event.mouse_x
    self.cur_value = -1
    self.first_value = -1
    self.first_unchanged_value = -1
    self.is_shift = False
    self.is_ctrl = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    init_font_settings(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
class OBJECT_OT_cablerator_helper_single_vert(bpy.types.Operator):
  """Place 3D Cursor to desired location"""
  bl_idname = "object.cablerator_helper_single_vert"
  bl_label = "Cablerator: Add Single Vert at 3D Cursor"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = True
      if ob:
        edit_condition = context.object.mode == 'OBJECT'
      return context.area.type == "VIEW_3D" and edit_condition
  def execute(self, context):
    scene = context.scene
    cursor_pos = scene.cursor.location.copy()
    if anything_selected():
      deselect_all()
    mesh = bpy.data.meshes.new("mesh")
    obj = bpy.data.objects.new("Cablerator Vert", mesh)
    scene.collection.objects.link(obj)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    mesh_data = obj.data
    bm = bmesh.new()
    bm.verts.new((0,0,0))
    for vert in bm.verts:
        vert.select = True
    bm.to_mesh(mesh_data)
    bm.free()
    obj.location = cursor_pos
    switch_mode('EDIT')
    bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
    switch_mode('OBJECT')
    return {'FINISHED'}
class OBJECT_OT_cablerator_helper_find_profile(bpy.types.Operator):
  """Select bezier curves in Object mode"""
  bl_idname = "object.cablerator_helper_find_profile"
  bl_label = "Cablerator: Find Selected Curves Profiles"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = False
      if ob:
        edit_condition = True
      return context.area.type == "VIEW_3D" and edit_condition
  def invoke(self, context, event):
    objs = bpy.context.selected_objects
    curves = []
    profiles = []
    for ob in objs:
        if ob.type == 'CURVE':
          if ob.data.bevel_object:
            curves.append(ob.data.bevel_object)
          elif ob.data.bevel_depth == 0:
            profiles.append(ob)
    if not len(curves) and not len(profiles):
      self.report({'WARNING'}, "Selected objects don't have curve profiles or aren't profiles themselves")
      return {'CANCELLED'}
    if not event.shift:
      deselect_all()
    for profile in profiles:
          for ob in bpy.data.objects:
            if ob.type == 'CURVE' and ob not in curves:
              if ob.data.bevel_object == profile:
                ob.select_set(True)
    for curve in curves:
      curve.select_set(True)
    if len(context.selected_objects):
      context.view_layer.objects.active = context.selected_objects[0]
    else:
      self.report({'WARNING'}, "Selected objects don't have curve profiles or aren't profiles themselves")
      return {'CANCELLED'}
    return {'FINISHED'}
class OBJECT_OT_cablerator_helper_switch_handle(bpy.types.Operator):
  """Select bezier points in edit mode"""
  bl_idname = "object.cablerator_helper_switch_handle"
  bl_label = "Cablerator: Switch Bezier Points Handles Auto <> Aligned"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = True
      if ob:
        edit_condition = context.object.mode == 'EDIT'
      else:
        edit_condition = False
      return context.area.type == "VIEW_3D" and edit_condition
  def execute(self, context):
    objs = bpy.context.selected_objects
    for ob in objs:
        if ob.type == 'CURVE':
            for spline in ob.data.splines:
                if spline.type == 'BEZIER':
                    for point in spline.bezier_points:
                        if point.select_control_point:
                            if point.handle_left_type == 'AUTO' and point.handle_right_type == 'AUTO':
                                point.handle_right_type = point.handle_left_type = 'ALIGNED'
                            else:
                                point.handle_right_type = point.handle_left_type = 'AUTO'
    return {'FINISHED'}
class OBJECT_OT_cablerator_helper_unrotate(bpy.types.Operator):
  """Select bezier points in edit mode"""
  bl_idname = "object.cablerator_helper_unrotate"
  bl_label = "Cablerator: Reset Points Rotation"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = True
      if ob:
        edit_condition = context.object.mode == 'EDIT'
      else:
        edit_condition = False
      return context.area.type == "VIEW_3D" and edit_condition
  def execute(self, context):
    objs = bpy.context.selected_objects
    points = []
    for ob in objs:
      if ob.type == 'CURVE':
        for spline in ob.data.splines:
          if spline.type == 'BEZIER':
            for point in spline.bezier_points:
              if point.select_control_point:
                  points.append({
                    'ob': ob,
                    'spline': spline,
                    'point': point
                    })
    for point in points:
      bpy.ops.curve.select_all(action='DESELECT')
      ob, spline, p = point.values()
      p.select_control_point = True
      mw = ob.matrix_world
      mwi = mw.inverted()
      vec_bp = p.handle_right.copy() - p.co.copy()
      dist_right = distance_between(p.co, p.handle_right)
      dist_left = distance_between(p.co, p.handle_left)
      abs_vec = [abs(el) for el in vec_bp]
      wrong_ax = max(abs_vec)
      axis = []
      for ax in abs_vec:
          axis.append(ax != wrong_ax)
      inverted_axis = [int(not el) for el in axis]
      bpy.ops.transform.resize(value=inverted_axis, orient_type='LOCAL', orient_matrix=mw.to_3x3(), orient_matrix_type='LOCAL', constraint_axis=axis)
      vec_right = p.handle_right.copy() - p.co.copy()
      vec_left = p.handle_left.copy() - p.co.copy()
      vec_right.normalize()
      vec_left.normalize()
      p.handle_right = p.co.copy() + vec_right * dist_right
      p.handle_left = p.co.copy() + vec_left * dist_left
    for point in points:
      point['point'].select_control_point = True
    return {'FINISHED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_unrotate)
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_switch_handle)
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_find_profile)
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_add_point)
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_single_vert)
    bpy.utils.register_class(OBJECT_OT_cablerator_helper_add_circle)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_unrotate)
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_switch_handle)
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_find_profile)
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_add_point)
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_single_vert)
    bpy.utils.unregister_class(OBJECT_OT_cablerator_helper_add_circle)

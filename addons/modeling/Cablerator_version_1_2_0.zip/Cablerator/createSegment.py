import bpy
from .lib import *
from .ui import *
from math import radians, degrees
class OBJECT_OT_cablerator_segment(bpy.types.Operator):
  """Select a Mesh and a Curve or a Segment mesh in Object Mode"""
  bl_idname = "object.cablerator_segment"
  bl_label = "Cablerator: Add Segment"
  bl_options = {"REGISTER", "UNDO"}
  duplicate: bpy.props.BoolProperty(name="From Duplicate", default=False)
  @classmethod
  def poll(cls, context):
    if len(context.selected_objects) < 1:
      return False
    ob = context.object
    edit_condition = True
    if ob:
      edit_condition = context.object.mode == 'OBJECT'
    return context.area.type == "VIEW_3D"
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
          if event.value == 'PRESS':
              self.is_shift = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_shift = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
          if event.value == 'PRESS':
              self.is_ctrl = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_ctrl = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in self.events.keys() and event.value == "PRESS":
          self.first_mouse_x = event.mouse_x
          for key in self.events.keys():
              if event.type == key:
                  if self.events[key]['status']:
                      self.events[key]['status'] = False
                  else:
                      self.events[key]['status'] = True
                      self.first_unchanged_value = self.events[key]['cur_value']
                      self.first_value = self.events[key]['cur_value']
                      self.cur_value = self.events[key]['cur_value']
              else:
                  self.events[key]['status'] = False
          return {'RUNNING_MODAL'}
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif event.type == 'MOUSEMOVE':
          for key in self.events.keys():
              if self.events[key]['status']:
                  if self.is_shift:
                      delta = 1200 if key != 'F' else 25
                  else:
                      delta = 60 if key != 'F' else 5
                  if self.is_ctrl:
                      if key != 'F':
                        self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                      else:
                        self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta * 5)/5)*5
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  else:
                      self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  if key == 'D':
                      self.displ_mod.strength = self.events[key]['cur_value']
                  elif key == 'F':
                      self.segment.rotation_euler[2] = radians(self.events[key]['cur_value'])
      if event.type in self.actions.keys() and event.value == "PRESS":
          for key in self.events.keys():
            self.events[key]['status'] = False
          for key in self.actions.keys():
              if event.type == key:
                  if key == 'Q':
                      new_obj = self.segment.copy()
                      new_obj.data = self.segment.data
                      new_obj.animation_data_clear()
                      context.scene.collection.objects.link(new_obj)
                      self.segment.select_set(False)
                      context.view_layer.objects.active = self.ob
                      bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
                      bpy.ops.object.cablerator_segment('INVOKE_DEFAULT', duplicate=True)
                      return {'FINISHED'}
          return {'RUNNING_MODAL'}
      elif event.type == 'LEFTMOUSE' and event.value == "PRESS":
          for ev in self.events:
              if self.events[ev]['status']:
                  self.events[ev]['status'] = not self.events[ev]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          return {'FINISHED'}
      elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['cur_value'] = self.first_unchanged_value
                  if key == 'D':
                      self.displ_mod.strength = self.events[key]['cur_value']
                  elif key == 'F':
                      self.segment.rotation_euler[2] = radians(self.events[key]['cur_value'])
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          bpy.ops.ed.undo()
          return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    mods = [x for x in context.selected_objects[0].modifiers if x.type == 'CURVE' or x.type == 'DISPLACE']
    curve_mod = next((mod for mod in mods if mod.type == 'CURVE'), None)
    if len(context.selected_objects) == 1:
      if context.selected_objects[0].type != 'MESH' or len(mods) != 2 or not curve_mod:
        self.report({'ERROR'}, 'Wrong object selected for Segment editing, aborting. To create a segment select a mesh and a curve.')
        return {'CANCELLED'}
      self.ob = curve_mod.object
      self.segment = context.selected_objects[0]
    elif len(context.selected_objects) != 2:
      self.report({'ERROR'}, str(len(context.selected_objects)) + ' objects selected: expected 2 (a Mesh and a Curve). Aborting')
      return {'CANCELLED'}
    else:
      for obj in context.selected_objects:
        if obj.type == 'CURVE':
          self.ob = obj
        elif obj.type == 'MESH':
          self.segment = obj
        else:
          self.report({'ERROR'}, f"Unexpected object found: {obj.type}, aborting")
          return {'CANCELLED'}
      if mods == 2 and curve_mod.object != self.ob:
        new_obj = self.segment.copy()
        new_obj.data = self.segment.data
        new_obj.animation_data_clear()
        context.scene.collection.objects.link(new_obj)
        if new_obj.parent:
          new_obj.parent = None
        self.segment.select_set(False)
        context.view_layer.objects.active = self.ob
        mods = [x for x in self.segment.modifiers if x.type == 'CURVE' or x.type == 'DISPLACE']
        curve_mod = next((mod for mod in mods if mod.type == 'CURVE'), None)
        curve_mod.ob = self.ob
        self.segment = new_obj
    self.context = context
    self.parent_connectors = True
    if 'Cablerator' in context.preferences.addons:
        if context.preferences.addons['Cablerator'].preferences is not None:
            FontGlobal.size = context.preferences.addons['Cablerator'].preferences.font_size
            self.parent_connectors = context.preferences.addons['Cablerator'].preferences.parent_connectors
    self.displ_mod, self.curve_mod = set_segment(self)
    self.finished = False
    self.prev_rotation = 0
    self.rotation_deg = 0
    self.prev_sign = 0
    self.prev_mouse = -1
    self.actual_val = 0
    self.curve_length = -1
    self.show_curve_length = False
    self.title="Add segments to a curve."
    self.events = {
        'F': {
            'name': 'Tilt Segment (F)',
            'status': False,
            'cur_value': normal_round(degrees(self.segment.rotation_euler[2])),
            'type': 'int',
            'show': True
        },
        'D': {
            'name': 'Offset Segment (D)',
            'status': self.duplicate,
            'cur_value': self.displ_mod.strength,
            'type': 'float',
            'show': True
        },
    }
    self.actions = {
        'Q': {
            'name': 'Duplicate (Q)',
            'status': True,
            'show': True,
        },
    }
    self.first_mouse_x = event.mouse_x
    self.cur_value = -1 if not self.duplicate else self.displ_mod.strength
    self.first_unchanged_value = -1 if not self.duplicate else self.displ_mod.strength
    self.first_value = -1 if not self.duplicate else self.displ_mod.strength
    self.is_shift = False
    self.is_ctrl = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    if not FontGlobal.size:
        FontGlobal.size = 13
    temp = get_column_width(self, FontGlobal.font_id, FontGlobal.size, FontGlobal.dpi)
    FontGlobal.LN = get_line(FontGlobal.font_id, FontGlobal.size, FontGlobal.dpi)
    FontGlobal.column_width = temp[0]
    FontGlobal.add_width = temp[1]
    FontGlobal.column_height = get_column_height(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
    return {'FINISHED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator_segment)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator_segment)
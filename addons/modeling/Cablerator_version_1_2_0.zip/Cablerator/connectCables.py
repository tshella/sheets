import bpy
from .lib import *
from .ui import *
class OBJECT_OT_cableratorconnect(bpy.types.Operator):
  """Select two end points of a cable"""
  bl_idname = "object.cableratorconnect"
  bl_label = "Cablerator: Merge Two Selected End Points"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
      ob = context.object
      edit_condition = True
      if ob:
        edit_condition = context.object.mode == 'EDIT'
      else:
        edit_condition = False
      return context.area.type == "VIEW_3D" and edit_condition
  def execute(self, context):
    obs = context.selected_objects
    if len(obs) > 1:
      self.report({'ERROR'}, 'This function requires one selected curve object')
      return {'CANCELLED'}
    self.ob = context.view_layer.objects.active
    self.active_curve = get_active_curve()
    self.points = get_selected_points(self.ob)
    if len(self.points) != 2:
      self.report({'ERROR'}, 'This function expects 2 end points')
      return {'CANCELLED'}
    bpy.ops.curve.select_all(action='DESELECT')
    for point in self.points:
      if point['type'] == 'BEZIER':
        self.ob.data.splines[point['spline']].bezier_points[point['index']].select_control_point = True
      else:
        self.ob.data.splines[point['spline']].points[point['index']].select = True
    try:
      bpy.ops.curve.make_segment()
    except:
      self.report({'ERROR'},"Can't connect points! (maybe different spline types?)")
      return {'CANCELLED'}
    self.new_points = get_selected_inner_points(self)
    index = -1
    deleted_index = -1
    rest_index = -1
    condition = self.new_points[0]['index'] > self.new_points[1]['index']
    remove_index = int(not self.new_points[0]['index'] > self.new_points[1]['index'])
    stay_index = int(not remove_index)
    cycle_segment = False
    if abs(self.new_points[0]['index'] - self.new_points[1]['index']) == 1:
      cycle_segment = True
    if self.new_points[0]['type'] == 'BEZIER':
      directions = {
        'left': self.points[0]['p2'] if self.points[0]['orientation'] == 'left' else self.points[1]['p2'],
        'right': self.points[0]['p2'] if self.points[0]['orientation'] == 'right' else self.points[1]['p2'],
      }
      self.new_points[stay_index]['point'].select_control_point = False
      self.new_points[stay_index]['point'].select_right_handle = False
      self.new_points[stay_index]['point'].select_left_handle = False
      index = self.new_points[stay_index]['index']
      spline_type = 'BEZIER'
    else:
      self.new_points[stay_index]['point'].select = False
      index = self.new_points[stay_index]['index']
      index = self.new_points[stay_index]['index']
      spline_type = 'POLY'
    bpy.ops.curve.delete(type='VERT')
    mw = self.ob.matrix_world
    mwi = self.ob.matrix_world.inverted()
    if spline_type == 'BEZIER':
      self.new_point = self.ob.data.splines[self.new_points[0]['spline']].bezier_points[index]
      self.new_point.co = (self.new_points[0]['coordinate'] + self.new_points[1]['coordinate'])/2
      offset1 = self.new_points[0]['coordinate'] - self.new_point.co
      offset2 = self.new_points[1]['coordinate'] - self.new_point.co
      self.new_point.handle_left = mwi @ directions['left']
      self.new_point.handle_right = mwi @ directions['right']
    else:
      self.new_point = self.ob.data.splines[self.new_points[0]['spline']].points[index]
      self.new_point.co = (self.new_points[0]['coordinate'] + self.new_points[1]['coordinate'])/2
    return {'FINISHED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cableratorconnect)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cableratorconnect)
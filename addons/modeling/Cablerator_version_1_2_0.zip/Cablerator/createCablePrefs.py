import bpy
import bpy.utils.previews
import os
import rna_keymap_ui
icons_dict = None
addon_keymaps = []
def get_hotkey_entry_item(km, kmi_name, kmi_value, properties):
    for i, km_item in enumerate(km.keymap_items):
        if km.keymap_items.keys()[i] == kmi_name:
            if properties == 'name':
                if km.keymap_items[i].properties.name == kmi_value:
                    return km_item
            elif properties == 'tab':
                if km.keymap_items[i].properties.tab == kmi_value:
                    return km_item
            elif properties == 'none':
                return km_item
    return None
maps = [
    'object.cablerator',
    'object.cableratordraw',
    'object.cablerator_create_cable_from_edge',
    'object.cablerator_create_cable_from_selected',
    'object.cablerator_edit_cable',
    'object.cableratorconnect',
    'object.cablerator_connector',
    'object.cablerator_segment',
    'object.cablerator_geocable',
    'object.cableratorsplit',
    'object.cableratorsplitrecable',
    ]
class createCablePrefs(bpy.types.AddonPreferences):
    bl_idname = __package__
    tabs: bpy.props.EnumProperty(name="Preferences", items=[('PREFS','Preferences',''),('KEYS','Hotkeys','')], default="PREFS")
    right_click: bpy.props.EnumProperty(name="Click", items=[('0','Left',''),('1','Right','')], default='0')
    font_size: bpy.props.IntProperty(name="Font Size", min=8, default=13)
    width: bpy.props.FloatProperty(name="Default Cable Width", min=0, default=0.1)
    res: bpy.props.IntProperty(name="Curve Resolution", min=1, default=20)
    bevel_res: bpy.props.IntProperty(name="Bevel Resolution", min=0, default=6)
    subdivisions: bpy.props.IntProperty(name="Subdivide Cable in the end", min=0, default=1)
    twist: bpy.props.EnumProperty(name="Twist Mode", items=[('0','Z-Up',''),('1','Minimum',''),('2','Tangent','')], default='0')
    show_tilt: bpy.props.BoolProperty(name="Show Points Tilt in Modal", default=False)
    show_length: bpy.props.BoolProperty(name="Show Cable Length in Modal", default=False)
    show_res: bpy.props.BoolProperty(name="Show Resolution in Modal", default=False)
    show_bevel_res: bpy.props.BoolProperty(name="Show Bevel Resolution in Modal", default=False)
    show_subdivisions: bpy.props.BoolProperty(name="Show Subdivisions in Modal", default=True)
    show_twist: bpy.props.BoolProperty(name="Show Twist Mode in Modal", default=True)
    show_wire: bpy.props.BoolProperty(name="Show Toggle Wire in Modal", default=True)
    parent_connectors: bpy.props.BoolProperty(name="Parent Connectors, Segments and Hooks to Curves", default=True)
    empties: bpy.props.EnumProperty(name="Hook Display Type", items=[('PLAIN_AXES','Plain Axes',''),
                                                                    ('ARROWS','Arrows',''),
                                                                    ('SINGLE_ARROW','Single Arrow',''),
                                                                    ('CIRCLE','Circle',''),
                                                                    ('CUBE','Cube',''),
                                                                    ('SPHERE','Sphere',''),
                                                                    ('CONE','Cone','')], default='CUBE')
    empty_size: bpy.props.FloatProperty(name="Hook Object Size", min=0.01, default=0.5)
    circle_points: bpy.props.IntProperty(name="Default Circle Points Number", min=3, default=12)
    circle_rad: bpy.props.FloatProperty(name="Circle Radius", min=0.001, default=0.1)
    def draw(self, context):
        layout = self.layout
        r = layout.row()
        r.prop(self, "tabs", expand=True)
        column_main = layout.column()
        if self.tabs == "PREFS":
            column = column_main.column(align=True)
            r = column.split(factor=0.25)
            r.label(text="Select with mouse button:")
            row3 = r.row(align=True)
            row3.prop(self, 'right_click', expand=True)
            row = column_main.split(factor=0.5)
            row.separator()
            row.prop(self, 'font_size')
            row = column_main.split(factor=0.5)
            row.separator()
            row.prop(self, 'width')
            row = column_main.row()
            row.prop(self, "show_res")
            row.prop(self, 'res')
            row = column_main.row()
            row.prop(self, "show_bevel_res")
            row.prop(self, 'bevel_res')
            row = column_main.row()
            row.prop(self, "show_subdivisions")
            row.prop(self, 'subdivisions')
            column_main.prop(self, "show_wire")
            column_main.prop(self, 'show_tilt')
            column_main.prop(self, 'show_length')
            column_main.prop(self, 'show_twist')
            column = column_main.column(align=True)
            r = column.split(factor=0.25)
            r.label(text="Default Twist Mode:")
            row3 = r.row(align=True)
            row3.prop(self, 'twist', expand=True)
            column_main.prop(self, 'parent_connectors')
            column_main.separator()
            row = column_main.row()
            r = row.split(factor=0.33)
            r.prop(self, "empty_size")
            r.prop(self, 'empties')
            column_main.separator()
            row = column_main.row()
            r = row.split(factor=0.5)
            r.prop(self, "circle_points")
            r.prop(self, 'circle_rad')
        elif self.tabs == "KEYS":
            column = column_main.column()
            wm = bpy.context.window_manager
            kc = wm.keyconfigs.user
            km = kc.keymaps['3D View']
            column.label(text="Cablerator Menu:")
            kmi = get_hotkey_entry_item(km, 'wm.call_menu', 'VIEW3D_MT_cablerator', 'name')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            column.label(text=" Main functions:")
            for keymap in maps:
                kmi = get_hotkey_entry_item(km, keymap, 'none', 'none')
                if kmi:
                    column.context_pointer_set("keymap", km)
                    rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
                else:
                    column.label(text="No hotkey entry found")
            column.label(text="Hooks:")
            km = kc.keymaps['Curve']
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_add_hook', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            km = kc.keymaps['3D View']
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_apply_hook', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_remove_hook', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            column.label(text="Helpers:")
            km = kc.keymaps['Curve']
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_add_point', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_switch_handle', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_unrotate', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            km = kc.keymaps['3D View']
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_find_profile', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_single_vert', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
            kmi = get_hotkey_entry_item(km, 'object.cablerator_helper_add_circle', 'none', 'none')
            if kmi:
                column.context_pointer_set("keymap", km)
                rna_keymap_ui.draw_kmi([], kc, km, kmi, column, 0)
            else:
                column.label(text="No hotkey entry found")
        column_main = layout.column()
        column_main.separator()
        box = column_main.box()
        box.scale_y = 1
        row = box.row()
        row.operator("wm.url_open",text="Gumroad").url = "https://gumroad.com/kritskiy"
        row.operator("wm.url_open",text="Cubebrush").url = "https://cubebrush.co/kritskiy"
        row.operator("wm.url_open",text="Artstation").url = "https://www.artstation.com/sergeykritskiy"
        row.operator("wm.url_open",text="Youtube").url = "https://www.youtube.com/user/tyrtyrtyr/"
class VIEW3D_MT_cablerator_hooks(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_cablerator_hooks"
    bl_label = "Hooks"
    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator("object.cablerator_helper_add_hook", text="Add Aligned Hooks")
        layout.operator("object.cablerator_helper_apply_hook", text="Apply Hooks to Selected")
        layout.operator("object.cablerator_helper_remove_hook", text="Remove Hooks from Selected")
class VIEW3D_MT_cablerator_helper(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_cablerator_helper"
    bl_label = "Helpers"
    def draw(self, context):
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        layout.operator("object.cablerator_helper_add_point", text="Add Bezier Point at Mouse Cursor...")
        layout.operator("object.cablerator_helper_unrotate", text="Reset Points Orientation")
        layout.operator("object.cablerator_helper_switch_handle", text="Switch Points Handles Auto <> Aligned")
        layout.operator("object.cablerator_helper_find_profile", text="Find Selected Curves Profiles")
        layout.operator("object.cablerator_helper_single_vert", text="Add Single Vert at 3D Cursor")
        layout.operator("object.cablerator_helper_add_circle", text="Add Polycurve Circle at 3D Cursor...")
class VIEW3D_MT_cablerator(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_cablerator"
    bl_label = "Cablerator"
    def draw(self, context):
        global icons_dict
        layout = self.layout
        layout.operator_context = 'INVOKE_REGION_WIN'
        myop = layout.operator("object.cablerator", text="Create Cable", icon_value=icons_dict["create_cable_icon"].icon_id)
        myop.use_bevel=False
        myop.use_method=-1
        myop.use_length=-1
        layout.operator("object.cableratordraw", text="Draw Cable")
        layout.operator("object.cablerator_create_cable_from_edge", text="Create from Edges")
        layout.operator("object.cablerator_create_cable_from_selected", text="Create from Selected Objects")
        layout.separator()
        layout.operator("object.cablerator_edit_cable", text="Edit Cable")
        layout.operator("object.cableratorconnect", text="Merge Selected End Points")
        layout.separator()
        layout.operator("object.cablerator_connector", text="Add Connectors")
        layout.operator("object.cablerator_segment", text="Add or Edit Segment").duplicate = False
        layout.operator("object.cablerator_geocable", text="Convert Curve to Mesh Cable")
        layout.separator()
        layout.operator("object.cableratorsplit", text="Split Cable by Profiles")
        layout.operator("object.cableratorsplitrecable", text="Rebuild Split Cable")
        layout.separator()
        layout.menu(VIEW3D_MT_cablerator_hooks.bl_idname)
        layout.menu(VIEW3D_MT_cablerator_helper.bl_idname)
def cablerator_menu(self, context):
    global icons_dict
    self.layout.menu("VIEW3D_MT_cablerator", icon_value=icons_dict["create_cable_icon"].icon_id)
def register():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        if "3D View" not in kc.keymaps:
            km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        else:
            km = kc.keymaps["3D View"]
        kmi = km.keymap_items.new("wm.call_menu", "C", "PRESS", alt=True, shift=True)
        kmi.properties.name ="VIEW3D_MT_cablerator"
        kmi.active = True
        for keymap in maps:
            kmi = km.keymap_items.new(keymap, "NONE", "PRESS")
            kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_find_profile", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_add_circle", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_single_vert", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_apply_hook", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_remove_hook", "NONE", "PRESS")
        kmi.active = False
        addon_keymaps.append((km, kmi))
        if "Curve" not in kc.keymaps:
            km = kc.keymaps.new(name="Curve", space_type="EMPTY")
        else:
            km = kc.keymaps["Curve"]
        kmi = km.keymap_items.new("object.cablerator_helper_add_hook", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_switch_handle", "V", "PRESS", alt=True)
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_unrotate", "NONE", "PRESS")
        kmi.active = False
        kmi = km.keymap_items.new("object.cablerator_helper_add_point", "NONE", "PRESS")
        kmi.active = False
        addon_keymaps.append((km, kmi))
    global icons_dict
    icons_dict = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    icons_dict.load("create_cable_icon", os.path.join(icons_dir, "create_cable.png"), 'IMAGE')
    bpy.utils.register_class(createCablePrefs)
    bpy.utils.register_class(VIEW3D_MT_cablerator)
    bpy.utils.register_class(VIEW3D_MT_cablerator_helper)
    bpy.utils.register_class(VIEW3D_MT_cablerator_hooks)
    bpy.types.VIEW3D_MT_add.append(cablerator_menu)
    bpy.types.VIEW3D_MT_curve_add.append(cablerator_menu)
def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    global icons_dict
    bpy.utils.previews.remove(icons_dict)
    bpy.utils.unregister_class(createCablePrefs)
    bpy.utils.unregister_class(VIEW3D_MT_cablerator)
    bpy.utils.unregister_class(VIEW3D_MT_cablerator_helper)
    bpy.utils.unregister_class(VIEW3D_MT_cablerator_hooks)
    bpy.types.VIEW3D_MT_add.remove(cablerator_menu)
    bpy.types.VIEW3D_MT_curve_add.remove(cablerator_menu)
import bpy
from .lib import *
from .ui import *
from .inits import *
from math import radians, degrees
class OBJECT_OT_cablerator_create_cable_from_selected(bpy.types.Operator):
  """Select objects and create cables between them"""
  bl_idname = "object.cablerator_create_cable_from_selected"
  bl_label = "Cablerator: Create a Cable from Selected Objects"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
    if len(context.selected_objects) < 2:
      return False
    ob = context.object
    edit_condition = True
    if ob:
      edit_condition = context.object.mode == 'OBJECT'
    return context.area.type == "VIEW_3D" and edit_condition
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
          if event.value == 'PRESS':
              self.is_shift = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_shift = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
          if event.value == 'PRESS':
              self.is_ctrl = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_ctrl = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in self.events.keys() and event.value == "PRESS":
          clean_pickers(self)
          self.first_mouse_x = event.mouse_x
          for key in self.events.keys():
              if event.type == key:
                  if self.events[key]['status']:
                      self.events[key]['status'] = False
                  else:
                      self.events[key]['status'] = True
                      self.first_value = self.events[key]['cur_value']
                      self.first_unchanged_value = self.events[key]['cur_value']
                      self.cur_value = self.events[key]['cur_value']
                      edit_curves(self, key)
              else:
                  self.events[key]['status'] = False
          return {'RUNNING_MODAL'}
      if event.type in self.bools.keys() and event.value == "PRESS":
          clean_pickers(self)
          clean_events(self)
          for key in self.events.keys():
            self.events[key]['status'] = False
          for key in self.bools.keys():
              if event.type == key:
                  self.bools[key]['status'] = not self.bools[key]['status']
          return {'RUNNING_MODAL'}
      if event.type in self.actions.keys() and event.value == "PRESS":
          clean_pickers(self)
          clean_events(self)
          for key in self.actions.keys():
              if event.type == key:
                  if key == 'N' and self.actions[key]['status']:
                      set_curves_from_selected(self, context, key)
          return {'RUNNING_MODAL'}
      if event.type in self.enums.keys() and event.value == "PRESS":
          clean_pickers(self)
          clean_events(self)
          for key in self.enums.keys():
              if event.type == key:
                  if self.enums[key]['cur_value'] == len(self.enums[key]['items']) - 1:
                      self.enums[key]['cur_value'] = 0
                  else:
                      self.enums[key]['cur_value'] += 1
                  if key == 'H':
                      edit_curves(self, key)
          return {'RUNNING_MODAL'}
      if event.type in self.pickers.keys() and event.value == "PRESS":
        clean_events(self)
        for key in self.pickers.keys():
          if event.type != key:
              self.pickers[key]['status'] = False
              self.pickers[key]['selecting'] = False
        for key in self.pickers.keys():
            if event.type == key and self.pickers[key]['usable']:
                if self.pickers[key]['status']:
                    self.pickers[key]['status'] = False
                    self.pickers[key]['selecting'] = False
                else:
                    self.pickers[key]['status'] = True
                    self.pickers[key]['selecting'] = True
            else:
                self.pickers[key]['status'] = False
        return {'RUNNING_MODAL'}
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif event.type == 'MOUSEMOVE':
          for key in self.events.keys():
              if self.events[key]['status']:
                  if self.is_shift:
                      delta = 1200
                  else:
                      delta = 60
                  if self.is_ctrl:
                      self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  else:
                      self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  if key == 'S' or key == 'V':
                      if self.cur_value < 0:
                          self.cur_value = 0
                          self.events[key]['cur_value'] = 0
                      edit_curves(self, key)
                  elif key == 'D':
                      if self.cur_value < 0:
                          self.cur_value = 0
                          self.events[key]['cur_value'] = 0
                      self.strength = self.events[key]['cur_value']
                      set_curves_from_selected(self, context, key)
                      self.init_ten = self.events[key]['cur_value']
                  elif key == 'F':
                      if self.cur_value < 1:
                          self.cur_value = 1
                          self.events[key]['cur_value'] = 1
                      edit_curves(self, key)
                  elif key == 'T' and self.pickers['A']['object']:
                      s = self.events[key]['cur_value']
                      self.pickers['A']['object'].scale = s,s,s
      if event.type == self.button and event.value == "PRESS" and self.pickers['A']['status']:
          bpy.ops.object.select_all(action='DESELECT')
          bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
          return {'PASS_THROUGH'}
      elif event.type == self.button and event.value == "RELEASE" and self.pickers['A']['status']:
        if len(context.selected_objects) == 0:
          self.pickers['A']['status'] = False
          self.pickers['A']['selecting'] = False
          self.pickers['A']['object'] = None
          for curve in self.objects:
            curve.data.bevel_object = None
          self.events['T']['show'] = False
          FontGlobal.column_height = get_column_height(self)
        elif context.view_layer.objects.active.type == 'CURVE' and context.view_layer.objects.active not in self.objects:
          self.pickers['A']['status'] = False
          self.pickers['A']['selecting'] = False
          self.pickers['A']['object'] = context.view_layer.objects.active
          for curve in self.objects:
            curve.data.bevel_object = context.view_layer.objects.active
          self.events['T']['show'] = True
          self.events['T']['cur_value'] = sum(self.pickers['A']['object'].scale)/3
          FontGlobal.column_height = get_column_height(self)
        bpy.ops.object.select_all(action='DESELECT')
        return {'RUNNING_MODAL'}
      elif event.type == 'LEFTMOUSE' and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          for key in self.pickers.keys():
              if self.pickers[key]['status']:
                  self.pickers[key]['status'] = False
                  self.pickers[key]['selecting'] = False
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          finish_curve_from_edges(self)
          return {'FINISHED'}
      elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['cur_value'] = self.first_unchanged_value
                  edit_curves(self, key)
                  if key == 'D':
                    self.strength = self.events[key]['cur_value']
                    set_curves_from_selected(self,context, 'D')
                  elif key == 'T':
                      s = self.events[key]['cur_value']
                      self.pickers['A']['object'].scale = s,s,s
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          for key in self.pickers.keys():
            if self.pickers[key]['status']:
              self.pickers[key]['status'] = False
              self.pickers[key]['selecting'] = False
              return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          remove_cables(self)
          return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    self.mesh_objects = context.selected_objects
    self.coord_pairs = []
    for index,ob in enumerate(self.mesh_objects):
      if index != len(self.mesh_objects)-1:
        self.coord_pairs.append([ob.location,self.mesh_objects[index+1].location])
    self.objects, self.strength = curves_from_selected(self, context)
    self.initial_curve_points = []
    self.init_ten = self.strength
    init_curve_points(self)
    set_curves_from_selected(self, context, 'D')
    self.res = 20
    self.bevel_res = 6
    self.twist = 0
    self.width = 0
    self.show_res = True
    self.show_bevel_res = True
    self.show_twist = True
    self.random_tension = .2
    self.right_click = 0
    get_prefs(self, context)
    self.show_curve_length = False
    self.button = 'RIGHTMOUSE' if self.right_click == '1' else 'LEFTMOUSE'
    for curve in self.objects:
      curve.data.bevel_depth = self.width
      curve.data.resolution_u = self.res
      curve.data.bevel_resolution = self.bevel_res
    self.title="Create a Cable from Selected Objects."
    self.events = {
        'T': {
            'name': 'Scale Profile (T)',
            'status': False,
            'cur_value': 1,
            'type': 'float',
            'show': False
        },
        'V': {
            'name': 'Bevel Resolution (V)',
            'status': False,
            'cur_value': self.bevel_res,
            'type': 'int',
            'show': self.show_bevel_res
        },
        'F': {
            'name': 'Resolution (F)',
            'status': False,
            'cur_value': self.res,
            'type': 'int',
            'show': self.show_res
        },
        'D': {
            'name': 'Tension (D)',
            'status': False,
            'cur_value': self.strength,
            'type': 'float',
            'show': True
        },
        'S': {
            'name': 'Width (S)',
            'status': False,
            'cur_value': self.width,
            'type': 'float',
            'show': True
        }
    }
    self.bools = {
            'R': {
                'name': 'Remove the Original Mesh (R)',
                'status': False,
                'usable': True,
                'show': True
            },
    }
    self.enums = {
        'H': {
            'name': 'Twist Method (H)',
            'status': False,
            'usable': True,
            'cur_value': self.twist,
            'items': [('Z_UP','Z-Up',0),('MINIMUM','Minimum',1),('TANGENT','Tangent',2)],
            'show': self.show_twist
        },
    }
    edit_curves(self, 'H')
    self.actions = {
        'N': {
            'name': 'Randomize Tension (N)',
            'status': True,
            'show': True,
        },
    }
    self.pickers = {
        'A': {
            'name': 'Set Profile (A)',
            'status': False,
            'selecting': False,
            'object': None,
            'show': True,
            'usable': True,
            'vtext': 'Select an object...'
        }
    }
    self.first_mouse_x = event.mouse_x
    self.cur_value = -1
    self.first_value = -1
    self.first_unchanged_value = -1
    self.is_shift = False
    self.is_ctrl = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    init_font_settings(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator_create_cable_from_selected)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator_create_cable_from_selected)
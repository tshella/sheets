import bpy
from .lib import *
from .ui import *
from .inits import *
from math import radians, degrees
class OBJECT_OT_cablerator_edit_cable(bpy.types.Operator):
  """Edit cable width and other params"""
  bl_idname = "object.cablerator_edit_cable"
  bl_label = "Cablerator: Edit Cable"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
    if len(context.selected_objects) == 0:
      return False
    ob = context.object
    edit_condition = True
    if ob:
      edit_condition = ob.type == 'CURVE'
    return context.area.type == "VIEW_3D" and edit_condition
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
          if event.value == 'PRESS':
              self.is_shift = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_shift = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
          if event.value == 'PRESS':
              self.is_ctrl = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_ctrl = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in self.events.keys() and event.value == "PRESS":
          for key in self.pickers.keys():
            self.pickers[key]['status'] = False
            self.pickers[key]['selecting'] = False
          self.first_mouse_x = event.mouse_x
          for key in self.events.keys():
              if event.type == key:
                  if self.events[key]['status']:
                      self.events[key]['status'] = False
                  else:
                      self.events[key]['status'] = True
                      self.first_value = self.events[key]['cur_value']
                      self.first_unchanged_value = self.events[key]['cur_value']
                      self.cur_value = self.events[key]['cur_value']
                      edit_curves(self, key)
              else:
                  self.events[key]['status'] = False
          return {'RUNNING_MODAL'}
      if event.type in self.enums.keys() and event.value == "PRESS":
          for key in self.events.keys():
            self.events[key]['status'] = False
          for key in self.pickers.keys():
            self.pickers[key]['status'] = False
            self.pickers[key]['selecting'] = False
          for key in self.enums.keys():
              if event.type == key:
                  if self.enums[key]['cur_value'] == len(self.enums[key]['items']) - 1:
                      self.enums[key]['cur_value'] = 0
                  else:
                      self.enums[key]['cur_value'] += 1
                  if key == 'H':
                      edit_curves(self, key)
          return {'RUNNING_MODAL'}
      if event.type in self.bools.keys() and event.value == "PRESS":
          for key in self.events.keys():
            self.events[key]['status'] = False
          for key in self.bools.keys():
              if event.type == key:
                  if key == 'X':
                      self.bools[key]['status'] = not self.bools[key]['status']
                      for ob in self.objects:
                        ob.show_wire = self.bools[key]['status']
          return {'RUNNING_MODAL'}
      if event.type in self.pickers.keys() and event.value == "PRESS":
        for key in self.events.keys():
          self.events[key]['status'] = False
          for key in self.pickers.keys():
            if event.type != key:
                self.pickers[key]['status'] = False
                self.pickers[key]['selecting'] = False
        for key in self.pickers.keys():
            if event.type == key and self.pickers[key]['usable']:
                if self.pickers[key]['status']:
                    self.pickers[key]['status'] = False
                    self.pickers[key]['selecting'] = False
                else:
                    if key == 'A' and not self.is_object_mode:
                      switch_mode('OBJECT')
                    elif 'D' in self.pickers and key == 'D':
                      switch_mode('EDIT')
                    if key == 'A':
                      if self.active.data.bevel_object:
                        for ob in self.objects:
                          ob.data.bevel_object = self.active.data.bevel_object
                    self.pickers[key]['status'] = True
                    self.pickers[key]['selecting'] = True
            else:
                self.pickers[key]['status'] = False
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif event.type == 'MOUSEMOVE':
          for key in self.events.keys():
              if self.events[key]['status']:
                  if self.is_shift:
                      delta = 1200
                  else:
                      delta = 60
                  if self.is_ctrl:
                      self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  else:
                      self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  if key == 'S' or key == 'V':
                      if self.cur_value < 0:
                          self.cur_value = 0
                          self.events[key]['cur_value'] = 0
                      edit_curves(self, key)
                  elif key == 'F':
                      if self.cur_value < 1:
                          self.cur_value = 1
                          self.events[key]['cur_value'] = 1
                      edit_curves(self, key)
                  elif key == 'T' and self.pickers['A']['object']:
                      s = self.events[key]['cur_value']
                      self.pickers['A']['object'].scale = s,s,s
      if event.type == self.button and event.value == "PRESS":
          if self.pickers['A']['status']:
              bpy.ops.object.select_all(action='DESELECT')
              bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
              return {'PASS_THROUGH'}
          if 'D' in self.pickers and self.pickers['D']['status']:
              return {'PASS_THROUGH'}
      if event.type == self.button and event.value == "RELEASE":
        if self.pickers['A']['status']:
          if len(context.selected_objects) == 0:
            self.pickers['A']['status'] = False
            self.pickers['A']['selecting'] = False
            self.pickers['A']['object'] = None
            for curve in self.objects:
              curve.data.bevel_object = None
            self.events['T']['show'] = False
            FontGlobal.column_height = get_column_height(self)
          elif context.view_layer.objects.active.type == 'CURVE' and context.view_layer.objects.active not in self.objects:
            self.pickers['A']['status'] = False
            self.pickers['A']['selecting'] = False
            self.pickers['A']['object'] = context.view_layer.objects.active
            for curve in self.objects:
              curve.data.bevel_object = context.view_layer.objects.active
            self.events['T']['show'] = True
            self.events['T']['cur_value'] = sum(self.pickers['A']['object'].scale)/3
            FontGlobal.column_height = get_column_height(self)
          bpy.ops.object.select_all(action='DESELECT')
          for ob in self.objects:
            ob.select_set(True)
          context.view_layer.objects.active = self.ob
        elif 'D' in self.pickers and self.pickers['D']['status']:
          loc, normal = main(context, event, self, False)
          if loc and normal:
            normal.normalize()
            ob = self.selected_points[0]['object']
            spline = self.selected_points[0]['spline']
            bp = self.selected_points[0]['index']
            mwi = ob.matrix_world.copy().inverted()
            mw = ob.matrix_world.copy()
            dist = distance_between(self.selected_points[0]['p1'], self.selected_points[0]['p2'])
            ob.data.splines[spline].bezier_points[bp].co = mwi @ loc
            if self.selected_points[0]['orientation'] == 'left':
              ob.data.splines[spline].bezier_points[bp].handle_left = mwi @ (loc + normal * dist)
              ob.data.splines[spline].bezier_points[bp].handle_right = mwi @ (loc - normal * dist)
            if self.selected_points[0]['orientation'] == 'right':
              ob.data.splines[spline].bezier_points[bp].handle_right = mwi @ (loc + normal * dist)
              ob.data.splines[spline].bezier_points[bp].handle_left = mwi @ (loc - normal * dist)
            self.pickers['D']['status'] = False
            self.pickers['D']['selecting'] = False
          elif 'D' in self.pickers:
            self.pickers['D']['status'] = False
            self.pickers['D']['selecting'] = False
        return {'RUNNING_MODAL'}
      if event.type == 'LEFTMOUSE' and event.value == "PRESS":
          for ev in self.events:
              if self.events[ev]['status']:
                  self.events[ev]['status'] = not self.events[ev]['status']
                  return {'RUNNING_MODAL'}
          switch_mode('OBJECT')
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          return {'FINISHED'}
      if event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['cur_value'] = self.first_unchanged_value
                  if key == 'T':
                    s = self.events[key]['cur_value']
                    self.pickers['A']['object'].scale = s,s,s
                  else:
                    edit_curves(self, key)
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          for key in self.pickers.keys():
            if self.pickers[key]['status']:
              self.pickers[key]['status'] = False
              self.pickers[key]['selecting'] = False
              return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    self.objects = context.selected_objects
    self.active = context.view_layer.objects.active
    self.vertices = []
    self.is_object_mode = context.object.mode == 'OBJECT'
    self.selected_points = []
    if len(self.objects) == 0:
      self.report({'ERROR'}, "No objects selected, aborting")
      return {'CANCELLED'}
    for ob in self.objects:
      if ob.type != 'CURVE':
        self.report({'ERROR'}, f"'{ob.name}' is not a Curve object: expected all selected objects to be curves, aborting")
        return {'CANCELLED'}
      elif not self.is_object_mode:
        temp = get_selected_points(ob)
        for item in temp:
          item['object'] = ob
        self.selected_points.append(temp)
    self.selected_points = [points for obj in self.selected_points for points in obj]
    self.ob = context.view_layer.objects.active
    if self.ob.data.twist_mode == 'Z_UP':
      self.twist = 0
    elif self.ob.data.twist_mode == 'MINIMUM':
      self.twist = 1
    elif self.ob.data.twist_mode == 'TANGENT':
      self.twist = 2
    self.title="Edit Cable."
    self.show_wire = True
    self.wire_status = self.active.show_wire
    for ob in self.objects:
      ob.show_wire = self.wire_status
    self.right_click = 0
    get_prefs(self, context)
    self.show_curve_length = False
    self.button = 'RIGHTMOUSE' if self.right_click == '1' else 'LEFTMOUSE'
    self.events = {
        'T': {
            'name': 'Scale Profile (T)',
            'status': False,
            'cur_value': 1,
            'type': 'float',
            'show': False
        },
        'V': {
            'name': 'Bevel Resolution (V)',
            'status': False,
            'cur_value': self.ob.data.bevel_resolution,
            'type': 'int',
            'show': True
        },
        'F': {
            'name': 'Resolution (F)',
            'status': False,
            'cur_value': self.ob.data.resolution_u,
            'type': 'int',
            'show': True
        },
        'S': {
            'name': 'Width (S)',
            'status': False,
            'cur_value': self.ob.data.bevel_depth,
            'type': 'float',
            'show': True
        }
    }
    self.bools = {
            'X': {
                'name': 'Show Wire (X)',
                'status': self.wire_status,
                'usable': True,
                'show': self.show_wire
            },
          }
    self.enums = {
        'H': {
            'name': 'Twist Method (H)',
            'status': False,
            'usable': True,
            'cur_value': self.twist,
            'items': [('Z_UP','Z-Up',0),('MINIMUM','Minimum',1),('TANGENT','Tangent',2)],
            'show': True
        },
    }
    self.pickers = {
        'A': {
            'name': 'Set Bevel Object (A)',
            'status': False,
            'selecting': False,
            'object': self.ob.data.bevel_object,
            'show': True,
            'usable': True,
            'vtext': 'Select an object...'
        }
    }
    if self.pickers['A']['object']:
        self.events['T']['show'] = True
        self.events['T']['cur_value'] = sum(self.pickers['A']['object'].scale)/3
    if len(self.selected_points) == 1:
        self.pickers['D'] = {
            'name': 'Move Active Point (D)',
            'status': False,
            'selecting': False,
            'object': True,
            'show':  True,
            'usable': True,
            'vtext': 'Click on a polygon...'
        }
        key_order = ('D', 'A')
        self.pickers = dict((k, self.pickers[k]) for k in key_order)
    self.first_mouse_x = event.mouse_x
    self.cur_value = -1
    self.first_value = -1
    self.first_unchanged_value = -1
    self.is_shift = False
    self.is_ctrl = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    init_font_settings(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator_edit_cable)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator_edit_cable)
import bpy
from .lib import *
from .ui import *
from .inits import *
from math import radians, degrees
class OBJECT_OT_cablerator_connector(bpy.types.Operator):
  """Select a Mesh and a Curve end points in Edit Mode to move the object to these points.
  Mesh will be oriented by Z axis"""
  bl_idname = "object.cablerator_connector"
  bl_label = "Cablerator: Assign Connector"
  bl_options = {"REGISTER", "UNDO"}
  @classmethod
  def poll(cls, context):
    if len(context.selected_objects) == 0:
      return False
    ob = context.object
    edit_condition = True
    if ob:
      edit_condition = context.object.mode == 'EDIT'
    return context.area.type == "VIEW_3D" and edit_condition
  def modal(self, context, event):
      context.area.tag_redraw()
      if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
          if event.value == 'PRESS':
              self.is_shift = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_shift = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
          if event.value == 'PRESS':
              self.is_ctrl = True
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
          elif event.value == 'RELEASE':
              self.is_ctrl = False
              self.first_value = self.cur_value
              self.first_mouse_x = event.mouse_x
      if event.type in self.events.keys() and event.value == "PRESS":
          self.first_mouse_x = event.mouse_x
          for key in self.events.keys():
              if event.type == key:
                  if self.events[key]['status']:
                      self.events[key]['status'] = False
                  else:
                      self.events[key]['status'] = True
                      self.first_value = self.events[key]['cur_value']
                      self.first_unchanged_value = self.events[key]['cur_value']
                      self.cur_value = self.events[key]['cur_value']
              else:
                  self.events[key]['status'] = False
          return {'RUNNING_MODAL'}
      if event.type in self.bools.keys() and event.value == "PRESS":
          for key in self.events.keys():
            self.events[key]['status'] = False
          for key in self.bools.keys():
              if event.type == key:
                  if key == 'A' and self.bools[key]['usable']:
                      self.bools[key]['status'] = not self.bools[key]['status']
                      self.flip = self.bools[key]['status']
                      reposition_clones(self)
                  elif key == 'R':
                    self.bools[key]['status'] = not self.bools[key]['status']
                  elif key == 'H':
                    self.bools[key]['status'] = not self.bools[key]['status']
          return {'RUNNING_MODAL'}
      if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
          return {'PASS_THROUGH'}
      elif event.type == 'MOUSEMOVE':
          for key in self.events.keys():
              if self.events[key]['status']:
                  if self.is_shift:
                      delta = 1200
                  else:
                      delta = 60
                  if self.is_ctrl:
                      self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  else:
                      self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                      if self.events[key]['type'] == 'int':
                          self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                      self.cur_value = self.events[key]['cur_value']
                  if key == 'D':
                      self.offset = self.events[key]['cur_value']
                      reposition_clones(self)
                  elif key == 'S':
                      self.offset_point = self.events[key]['cur_value']
                      edit_connector_spline(self)
                  elif key == 'T':
                      scale_clones(self)
      elif event.type == 'LEFTMOUSE' and event.value == "PRESS":
          for ev in self.events:
              if self.events[ev]['status']:
                  self.events[ev]['status'] = not self.events[ev]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          finish_clones(self)
          return {'FINISHED'}
      elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
          for key in self.events:
              if self.events[key]['status']:
                  self.events[key]['cur_value'] = self.first_unchanged_value
                  if key == 'D':
                      self.offset = self.events[key]['cur_value']
                      reposition_clones(self)
                  elif key == 'S':
                      self.offset_point = self.events[key]['cur_value']
                      edit_connector_spline(self)
                  elif key == 'T':
                      scale_clones(self)
                  self.events[key]['status'] = not self.events[key]['status']
                  return {'RUNNING_MODAL'}
          bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
          finish_clones(self)
          return {'CANCELLED'}
      return {'RUNNING_MODAL'}
  def invoke(self, context, event):
    try:
      self.objects = geo_sort_objects(context.selected_objects)
    except Exception as e:
      self.report({'ERROR'}, str(e))
      return {'CANCELLED'}
    self.connector = self.objects['ob']
    self.curves = self.objects['curves']
    self.context = context
    self.flip = False
    self.offset = 0
    self.offset_point = 0
    self.rotate = 0
    self.finished = False
    self.prev_rotation = 0
    self.rotation_deg = 0
    self.prev_sign = 0
    self.prev_mouse = -1
    self.actual_val = 0
    self.curve_length = -1
    self.show_curve_length = False
    self.connector_data = None
    self.parent_connectors = True
    self.scale = sum(self.objects['ob'].scale) / len(self.objects['ob'].scale)
    self.title="Assign conectors to points."
    self.events = {
        'T': {
            'name': 'Scale Connector (T)',
            'status': False,
            'cur_value': self.scale,
            'type': 'float',
            'show': True
        },
        'D': {
            'name': 'Offset Connector (D)',
            'status': False,
            'cur_value': self.offset,
            'type': 'float',
            'show': True
        },
        'S': {
            'name': 'Offset Point (S)',
            'status': False,
            'cur_value': self.offset_point,
            'type': 'float',
            'show': True
        },
    }
    self.bools = {
        'R': {
            'name': 'Remove the Original Mesh (R)',
            'status': False,
            'usable': True,
            'show': True
        },
        'H': {
            'name': 'Hook Point to Connector (H)',
            'status': True,
            'usable': True,
            'show': True
        },
        'A': {
            'name': 'Flip Direction (A)',
            'status': self.flip,
            'usable': True,
            'show': True
        },
    }
    get_prefs(self, context)
    self.show_curve_length = False
    self.selected_points = []
    for curve in self.curves:
      found_points = {
        'ob': curve,
        'points': get_selected_points(curve)
        }
      if len(found_points) == 0:
        self.report({'ERROR'}, 'No valid points found in '+curve.name+', aborting')
        return {'CANCELLED'}
      self.selected_points.append(found_points)
    switch_mode('OBJECT')
    self.clones = clone_connectors(self.selected_points, self)
    position_clones(self)
    self.first_mouse_x = event.mouse_x
    self.cur_value = -1
    self.first_value = -1
    self.first_unchanged_value = -1
    self.is_shift = False
    self.is_ctrl = False
    self.reg = get_view(context, event.mouse_x, event.mouse_y)
    init_font_settings(self)
    if context.space_data.type == 'VIEW_3D':
        self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    else:
        self.report({'WARNING'}, "Active space must be a View3d")
        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
        return {'CANCELLED'}
    return {'FINISHED'}
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator_connector)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator_connector)
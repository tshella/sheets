import bpy
from .lib import *
from .ui import *
from .inits import *
class OBJECT_OT_cablerator(bpy.types.Operator):
    """Create a curve by setting start and finish points"""
    bl_idname = "object.cablerator"
    bl_label = "Cablerator: Create a Cable"
    bl_options = {"REGISTER", "UNDO"}
    use_bevel: bpy.props.BoolProperty(name="Use Bevel", default=False)
    use_method: bpy.props.IntProperty(name="Twist Method", default=-1)
    use_length: bpy.props.FloatProperty(name="Desired Length", default=-1)
    def __init__(self):
        self.ui_vertices = []
        self.vertices = []
        self.create_batch3d()
    @classmethod
    def poll(cls, context):
        return context.area.type == "VIEW_3D"
    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'LEFT_SHIFT', 'RIGHT_SHIFT'}:
            if event.value == 'PRESS':
                self.is_shift = True
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
            elif event.value == 'RELEASE':
                self.is_shift = False
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
        if event.type in {'LEFT_CTRL', 'RIGHT_CTRL', 'OSKEY'}:
            if event.value == 'PRESS':
                self.is_ctrl = True
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
            elif event.value == 'RELEASE':
                self.is_ctrl = False
                self.first_value = self.cur_value
                self.first_mouse_x = event.mouse_x
        if event.type in self.events.keys() and event.value == "PRESS":
            clean_pickers(self)
            self.first_mouse_x = event.mouse_x
            for key in self.events.keys():
                if event.type == key:
                    if self.events[key]['status']:
                        self.events[key]['status'] = False
                    else:
                        self.events[key]['status'] = True
                        self.first_value = self.events[key]['cur_value']
                        self.first_unchanged_value = self.events[key]['cur_value']
                        self.cur_value = self.events[key]['cur_value']
                else:
                    self.events[key]['status'] = False
            return {'RUNNING_MODAL'}
        if event.type in self.bools.keys() and event.value == "PRESS":
            clean_pickers(self)
            clean_events(self)
            for key in self.bools.keys():
                if event.type == key:
                    if key == 'X':
                        self.bools[key]['status'] = not self.bools[key]['status']
                        if self.curve:
                            self.curve.show_wire = self.bools[key]['status']
                    elif key == 'J' and self.show_join_points:
                        self.bools[key]['status'] = not self.bools[key]['status']
            return {'RUNNING_MODAL'}
        if event.type in self.actions.keys() and event.value == "PRESS":
            clean_pickers(self)
            clean_events(self)
            for key in self.actions.keys():
                if event.type == key:
                    if key == 'Q' and self.actions[key]['status']:
                        bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
                        if self._draw_handler3d:
                            self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
                        add_point(self.curve, context, self.events['G']['cur_value'])
                        bpy.ops.object.cablerator('INVOKE_DEFAULT', use_bevel=self.pickers['A']['status'], use_method = self.enums['H']['cur_value'], use_length = self.curve_length)
                        return {'FINISHED'}
            return {'RUNNING_MODAL'}
        if event.type in self.enums.keys() and event.value == "PRESS":
            clean_pickers(self)
            clean_events(self)
            for key in self.enums.keys():
                if event.type == key:
                    if self.enums[key]['cur_value'] == len(self.enums[key]['items']) - 1:
                        self.enums[key]['cur_value'] = 0
                    else:
                        self.enums[key]['cur_value'] += 1
                    if key == 'H':
                        edit_curve(self.curve, self.enums[key]['items'][self.enums[key]['cur_value']][0], self.curve_obj, self, key)
            return {'RUNNING_MODAL'}
        if event.type in self.pickers.keys() and event.value == "PRESS":
          clean_events(self)
          for key in self.pickers.keys():
            if event.type != key:
                self.pickers[key]['status'] = False
                self.pickers[key]['selecting'] = False
          for key in self.pickers.keys():
              if event.type == key and self.pickers[key]['usable']:
                  if self.pickers[key]['status']:
                      self.pickers[key]['status'] = False
                      self.pickers[key]['selecting'] = False
                  else:
                      self.pickers[key]['status'] = True
                      self.pickers[key]['selecting'] = True
              else:
                  self.pickers[key]['status'] = False
          return {'RUNNING_MODAL'}
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or event.alt:
            return {'PASS_THROUGH'}
        elif event.type == 'MOUSEMOVE':
            for key in self.events.keys():
                if self.events[key]['status']:
                    if self.is_shift:
                        delta = 1200 if key != 'W' and key != 'E' else 25
                    else:
                        delta = 60 if key != 'W' and key != 'E' else 5
                    if self.is_ctrl:
                        if key != 'W' and key != 'E':
                          self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta)*20)/20
                        else:
                          self.events[key]['cur_value'] = normal_round((self.first_value - (self.first_mouse_x - event.mouse_x) / delta * 5)/5)*5
                        if self.events[key]['type'] == 'int':
                            self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                        self.cur_value = self.events[key]['cur_value']
                    else:
                        self.events[key]['cur_value'] = self.first_value - (self.first_mouse_x - event.mouse_x) / delta
                        if self.events[key]['type'] == 'int':
                            self.events[key]['cur_value'] = normal_round(self.events[key]['cur_value'])
                        self.cur_value = self.events[key]['cur_value']
                    if key == 'S':
                        if self.cur_value < 0:
                            self.cur_value = 0
                            self.events[key]['cur_value'] = 0
                        if self.curve:
                            self.curve.data.bevel_depth = self.events[key]['cur_value']
                    elif key == 'D':
                        if self.cur_value < 0.01:
                            self.cur_value = 0.01
                            self.events[key]['cur_value'] = 0.01
                        if self.curve:
                            edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                            self.init_ten = self.events[key]['cur_value']
                    elif key == 'G':
                        if self.cur_value < 0:
                            self.cur_value = 0
                            self.events[key]['cur_value'] = 0
                    elif key == 'F':
                        if self.cur_value < 1:
                            self.cur_value = 1
                            self.events[key]['cur_value'] = 1
                        if self.curve:
                            edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'V':
                        if self.cur_value < 0:
                            self.cur_value = 0
                            self.events[key]['cur_value'] = 0
                        if self.curve:
                            edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'W' or key == 'E':
                        if self.curve:
                            edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'T' and self.pickers['A']['object']:
                        s = self.events[key]['cur_value']
                        self.pickers['A']['object'].scale = s,s,s
        if event.type == self.button and event.value == "PRESS" and self.pickers['A']['status']:
            bpy.ops.object.select_all(action='DESELECT')
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'PASS_THROUGH'}
        elif event.type == self.button and event.value == "RELEASE" and self.pickers['A']['status']:
          if len(context.selected_objects) == 0:
            self.pickers['A']['status'] = False
            self.pickers['A']['selecting'] = False
            self.pickers['A']['object'] = None
            self.curve.data.bevel_object = None
            self.events['T']['show'] = False
            FontGlobal.column_height = get_column_height(self)
          elif context.view_layer.objects.active.type == 'CURVE' and context.view_layer.objects.active != self.curve:
            self.pickers['A']['status'] = False
            self.pickers['A']['selecting'] = False
            self.pickers['A']['object'] = context.view_layer.objects.active
            self.curve.data.bevel_object = context.view_layer.objects.active
            self.events['T']['show'] = True
            self.events['T']['cur_value'] = sum(self.pickers['A']['object'].scale)/3
            FontGlobal.column_height = get_column_height(self)
          bpy.ops.object.select_all(action='DESELECT')
          self.curve.select_set(True)
          context.view_layer.objects.active = self.curve
          return {'RUNNING_MODAL'}
        elif event.type == 'LEFTMOUSE' and event.value == "PRESS":
            for key in self.events:
                if self.events[key]['status']:
                    self.events[key]['status'] = not self.events[key]['status']
                    return {'RUNNING_MODAL'}
            for key in self.pickers.keys():
                if self.pickers[key]['status']:
                    self.pickers[key]['status'] = False
                    self.pickers[key]['selecting'] = False
                    return {'RUNNING_MODAL'}
            if self.finished:
                bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
                if self._draw_handler3d:
                    self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
                add_point(self.curve, context, self.events['G']['cur_value'])
                if self.show_join_points and self.bools['J']['status']:
                    join_new_cable(self)
                return {'FINISHED'}
            if self.mouse_click < 2:
                self.mouse_click += 1
                self.curve_obj['point' + str(self.mouse_click)] = main(context, event, self, True)
                if self.curve_obj['point' + str(self.mouse_click)][1] == None:
                    self.report({'ERROR'}, "Point wasn't registered, aborting")
                    bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
                    if self._draw_handler3d:
                        self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
                    return {'CANCELLED'}
                else:
                    self.status['point' + str(self.mouse_click)]['status'] = True
                if self.mouse_click == 2:
                    if self._draw_handler3d:
                        self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
                    finish_clicks(self)
            elif self.mouse_click == 2:
                if self._draw_handler3d:
                    self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
                finish_clicks(self)
        elif event.type in {'RIGHTMOUSE', 'ESC'} and event.value == "PRESS":
            for key in self.events:
                if self.events[key]['status']:
                    self.events[key]['cur_value'] = self.first_unchanged_value
                    if key == 'S':
                        self.curve.data.bevel_depth = self.events[key]['cur_value']
                    elif key == 'D':
                        edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'G':
                        if self.cur_value < 0:
                            self.cur_value = 0
                            self.events[key]['cur_value'] = 0
                    elif key == 'F':
                        edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'W' or key == 'E':
                        edit_curve(self.curve, self.events[key]['cur_value'], self.curve_obj, self, key)
                    elif key == 'T':
                        s = self.events[key]['cur_value']
                        self.pickers['A']['object'].scale = s,s,s
                    self.events[key]['status'] = not self.events[key]['status']
                    return {'RUNNING_MODAL'}
            for key in self.pickers.keys():
              if self.pickers[key]['status']:
                self.pickers[key]['status'] = False
                self.pickers[key]['selecting'] = False
                return {'RUNNING_MODAL'}
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            if self._draw_handler3d:
                self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
            if self.finished:
                bpy.data.objects.remove(self.curve, do_unlink=True)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}
    def create_batch3d(self):
        self.shader3d = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.batch3d = batch_for_shader(self.shader3d, 'POINTS', {"pos": self.vertices})
    def invoke(self, context, event):
        selected_points = init_points()
        if len(selected_points) > 2:
            self.report({'ERROR'}, "Expected to find maximum 2 curve points selected, found " + str(len(selected_points)))
            return {'CANCELLED'}
        self.context = context
        self.mouse_click = 0
        self.curve_obj = {
            'point1': [],
            'point2': [],
            'created_from_init1': False,
            'created_from_init2': False,
            'ob1': None,
            'ob2': None,
        }
        self.additional_data = {
            'point1': [],
            'point2': [],
        }
        self.title="Create a cable."
        self.prev_show = True
        self.subdivisions = 1
        self.show_subdivisions = True
        self.res = 20
        self.bevel_res = 6
        self.show_res = True
        self.strength = 1
        self.init_tens = -1
        self.curve_length = -1
        self.twist = 0
        self.show_twist = True
        self.show_wire = True
        self.show_tilt = False
        self.bevel = 0.1
        self.curve = None
        self.finished = False
        self.active_curve = get_active_curve()
        self.show_curve_length = False
        self.random_tension = .2
        self.right_click = 0
        get_prefs(self, context)
        temp_res = self.res;
        temp_bevel_res = self.bevel_res
        self.button = 'RIGHTMOUSE' if self.right_click == '1' else 'LEFTMOUSE'
        if self.active_curve['width'] == 0 or self.active_curve['width'] == None:
            self.active_curve['width'] = 0.1
        if self.active_curve['res'] != None:
            self.res = self.active_curve['res']
        if self.active_curve['bevel_res'] != None:
            self.bevel_res = self.active_curve['bevel_res']
        self.init_handles = dict()
        self.events = {
            'T': {
                'name': 'Scale Profile (T)',
                'status': False,
                'cur_value': 1,
                'type': 'float',
                'show': False
            },
            'E': {
                'name': 'Tilt Point 2 (E)',
                'status': False,
                'cur_value': 0,
                'type': 'float',
                'show': self.show_tilt
            },
            'W': {
                'name': 'Tilt Point 1 (W)',
                'status': False,
                'cur_value': 0,
                'type': 'float',
                'show': self.show_tilt
            },
            'G': {
                'name': 'Add Subdivision Points (G)',
                'status': False,
                'cur_value': self.subdivisions,
                'type': 'int',
                'show': self.show_subdivisions
            },
            'V': {
                'name': 'Bevel Resolution (V)',
                'status': False,
                'cur_value': self.bevel_res,
                'type': 'int',
                'show': self.show_bevel_res
            },
            'F': {
                'name': 'Resolution (F)',
                'status': False,
                'cur_value': self.res,
                'type': 'int',
                'show': self.show_res
            },
            'D': {
                'name': 'Tension (D)',
                'status': False,
                'cur_value': self.strength,
                'type': 'float',
                'show': True
            },
            'S': {
                'name': 'Width (S)',
                'status': False,
                'cur_value': self.active_curve['width'],
                'type': 'float',
                'show': True
            }
        }
        self.enums = {
            'H': {
                'name': 'Twist Method (H)',
                'status': False,
                'usable': True,
                'cur_value': self.twist,
                'items': [('Z_UP','Z-Up',0),('MINIMUM','Minimum',1),('TANGENT','Tangent',2)],
                'show': self.show_twist
            },
        }
        self.bools = {
                'X': {
                    'name': 'Show Wire (X)',
                    'status': False,
                    'usable': True,
                    'show': self.show_wire
                },
        }
        self.status = {
            'point2': {
                'name': 'Point 2',
                'status': False
            },
            'point1': {
                'name': 'Point 1',
                'status': False
            },
        }
        self.actions = {
            'Q': {
                'name': 'Create Another (Q)',
                'status': False,
                'show': True,
            },
        }
        self.pickers = {
            'A': {
                'name': 'Set Profile (A)',
                'status': False,
                'selecting': False,
                'object': self.active_curve['bevel'],
                'show': True,
                'usable': True,
                'vtext': 'Select an object...'
            }
        }
        if self.active_curve['active']:
            if self.active_curve['bevel'] == None and self.active_curve['active'].data.bevel_depth == 0:
                self.pickers['A']['object'] = self.active_curve['active']
                self.res = temp_res;
                self.bevel_res = temp_bevel_res
                self.events['F']['cur_value'] = self.res
                self.events['V']['cur_value'] = self.bevel_res
        if self.pickers['A']['object']:
            self.events['T']['show'] = True
            self.events['T']['cur_value'] = sum(self.pickers['A']['object'].scale)/3
        if len(selected_points) >= 1:
            self.curve_obj['point1'] = (selected_points[0]['co'], selected_points[0]['start'])
            self.curve_obj['created_from_init1'] = True
            self.curve_obj['ob1'] = selected_points[0]['object']
            self.additional_data['point1'] = [
                selected_points[0]['tilt'],
                selected_points[0]['radius'],
            ]
            self.events['W']['cur_value'] = math.degrees(selected_points[0]['tilt'])
            self.status['point1']['status'] = True
            self.mouse_click = 1
        if len(selected_points) == 2:
            self.curve_obj['point2'] = (selected_points[1]['co'], selected_points[1]['finish'])
            self.curve_obj['created_from_init2'] = True
            self.curve_obj['ob2'] = selected_points[1]['object']
            self.additional_data['point2'] = [
                selected_points[1]['tilt'],
                selected_points[1]['radius'],
            ]
            self.events['E']['cur_value'] = math.degrees(selected_points[1]['tilt'])
            self.status['point2']['status'] = True
            self.mouse_click = 2
        self.show_join_points = False
        if self.curve_obj['created_from_init1']:
            self.show_join_points = True
            self.bools['J'] = {
                'name': 'Join With Selected Points (J)',
                'status': True,
                'show': True,
                'usable': True,
            }
            key_order = ('J', 'X')
            self.bools = dict((k, self.bools[k]) for k in key_order)
        self.first_mouse_x = event.mouse_x
        self.cur_value = -1
        self.first_value = -1
        self.first_unchanged_value = -1
        self.is_shift = False
        self.is_ctrl = False
        self.reg = get_view(context, event.mouse_x, event.mouse_y)
        init_font_settings(self)
        if self.mouse_click == 2:
            finish_clicks(self)
        if context.space_data.type == 'VIEW_3D':
            self._draw_handler = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, (self, context), 'WINDOW', 'POST_PIXEL')
            self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_add(draw_callback_3d, (self, context), 'WINDOW', 'POST_VIEW')
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Active space must be a View3d")
            bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler, 'WINDOW')
            if self._draw_handler3d:
                self._draw_handler3d = bpy.types.SpaceView3D.draw_handler_remove(self._draw_handler3d, 'WINDOW')
            return {'CANCELLED'}
def menu_func(self, context):
    self.layout.operator_context = 'INVOKE_DEFAULT'
    myop = self.layout.operator("object.cablerator")
    myop.use_bevel=False
    myop.use_method=-1
    myop.use_length=-1
def register():
    bpy.utils.register_class(OBJECT_OT_cablerator)
def unregister():
    bpy.utils.unregister_class(OBJECT_OT_cablerator)

import bpy


def view_layer_unhide(collection, check=None, chain=[]):
    view_layer_collection = bpy.context.view_layer.layer_collection
    current = view_layer_collection if not check else check

    if collection.name in current.children:
        collection.hide_viewport = False

        collection = current.children[collection.name]
        collection.exclude = False
        collection.hide_viewport = False

        for col in chain:
            col.exclude = False
            col.hide_viewport = False
            bpy.data.collections[col.name].hide_viewport = False

        return True

    for child in current.children:
        if not child.children:
            continue

        if check:
            chain.append(check)

        if view_layer_unhide(collection, check=child, chain=chain):
            child.exclude = False
            child.hide_viewport = False
            bpy.data.collections[child.name].hide_viewport = False

            return True

    return False

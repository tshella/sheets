import time

import bpy

from bpy.types import SpaceView3D

# import bmesh
import gpu

from bgl import *
# from gpu_extras.batch import batch_for_shader

from math import pi, cos, sin
from mathutils import Vector

from ...... utility import new_type, method_handler, addon, math, screen, shader, view3d


def dot_size():
    return addon.preference().display.dot_size * screen.dpi_factor()


def wire_width():
    return screen.dpi_factor(rounded=True, integer=True)


def highlight_distance():
    size = dot_size()
    factor = addon.preference().display.dot_factor

    return size * factor


class setup:
    handler = None

    exit: bool = False

    @staticmethod
    def polys(batch, shader, color):
        shader.bind()
        shader.uniform_float('color', color)

        glEnable(GL_BLEND)

        batch.draw(shader)

        glDisable(GL_BLEND)

    @staticmethod
    def lines(batch, shader, color, width=1):
        shader.bind()
        shader.uniform_float('color', color)

        glEnable(GL_LINE_SMOOTH)
        glEnable(GL_BLEND)

        glLineWidth(width)
        batch.draw(shader)

        glDisable(GL_BLEND)
        glDisable(GL_LINE_SMOOTH)

        # glLineWidth(1)


    def __init__(self, op, exit=False):
        preference = addon.preference()

        self.active = ''
        self.operation = 'NONE'
        self.mouse = Vector((0, 0))

        self.widgets = []

        self.widgets.append(new_type(name='draw_dot', operation='DRAW', type='DOT')) # XXX: use type
        self.widgets.append(new_type(name='extrude_dot', operation='EXTRUDE', type='DOT'))
        self.widgets.append(new_type(name='offset_dot', operation='OFFSET', type='DOT'))
        self.widgets.append(new_type(name='bevel_dot', operation='BEVEL', type='DOT'))
        self.widgets.append(new_type(name='displace_dot', operation='DISPLACE', type='DOT'))

        size = preference.display.dot_size * 0.5 * screen.dpi_factor()

        color = Vector(preference.color.dot[:])
        bevel_color = Vector(preference.color.dot_bevel[:])

        self.fade = False
        self.dot_fade_time_in = preference.display.dot_fade_time_in * 0.001
        self.dot_fade_time_out = preference.display.dot_fade_time_in * 0.001

        start = time.perf_counter()
        for widget in self.widgets:
            widget.enable = False
            widget.time = start
            widget.fade_time = 0.0
            widget.fade = False
            widget.fade_type = 'NONE'
            widget.alpha = 0.0
            widget.color = color if widget.operation != 'BEVEL' else bevel_color
            widget.size = size
            widget.vert = []
            widget.location = Vector()
            widget.location2d = Vector((0, 0))
            widget.highlight = False

        self.shaders = {'uniform2d': gpu.shader.from_builtin('2D_UNIFORM_COLOR')}
        setup = self.shader
        setup(widgets=True, widgets2d=True, batch=True, operator=op)

        draw_arguments = (self.draw_handler, (None, bpy.context), 'WINDOW', 'POST_PIXEL')
        self.handler = SpaceView3D.draw_handler_add(*draw_arguments)


    def shader(self, widgets=False, widgets2d=False, batch=False, alpha=False, operator=None):
        preference = addon.preference()
        bc = bpy.context.scene.bc if widgets or widgets2d else None

        if widgets and bc.shape and operator:
            self.origin = operator.origin
            self.modified = operator.modified
            self.rotated = operator.rotated
            self.scaled = operator.scaled
            self.shape_type = operator.shape_type
            self.mode = operator.mode
            self.operation = operator.operation
            self.mouse = operator.mouse['location']

            op = operator
            matrix = bc.shape.matrix_world

            thin = bc.lattice.dimensions[2] <= preference.shape.offset
            front = (1, 2, 5, 6)
            back = (0, 3, 4, 7)
            left = (4, 5, 6, 7)
            right = (0, 1, 2, 3)

            for widget in self.widgets:
                if widget.operation in {'OFFSET', 'EXTRUDE'}:
                    indices = front if widget.operation == 'OFFSET' else back
                    points = [op.bounds[index] for index in indices]

                    widget.location = matrix @ (0.25 * math.vector_sum(points))

                elif widget.operation == 'DRAW':
                    if op.shape_type in {'BOX', 'CUSTOM'}:
                        widget.location = matrix @ op.bounds[op.draw_dot_index]

                    elif op.shape_type == 'CIRCLE':
                        indices = (5, 6) if op.draw_dot_index in {5, 6} else (1, 2)
                        points = [op.bounds[index] for index in indices]

                        widget.location = matrix @ (0.5 * math.vector_sum(points))

                elif widget.operation == 'DISPLACE':
                    indices = right if op.draw_dot_index in {5, 6} else left
                    points = [op.bounds[point] for point in indices]

                    widget.location = matrix @ (0.25 * math.vector_sum(points))

                elif widget.operation == 'BEVEL':
                    index_keys = {1: 7, 2: 4, 5: 3, 6: 0}
                    offset = 0.05
                    dot_index = op.draw_dot_index if op.draw_dot_index in index_keys.keys() else 1

                    widget.location = Vector(op.bounds[index_keys[dot_index]])
                    widget.location.x -= offset if op.draw_dot_index in {5, 6} else -offset
                    widget.location.y -= offset if op.draw_dot_index in {2, 6} else -offset

                    if not thin:
                        widget.location.z -= offset

                    widget.location = matrix @ widget.location

        if widgets2d and bc.lattice:
            color = Vector(preference.color.dot[:])
            bevel_color = Vector(preference.color.dot_bevel[:])

            thin = bc.lattice.dimensions[2] <= preference.shape.offset
            displace = len([mod for mod in bc.shape.modifiers if mod.type == 'DISPLACE'])

            for widget in self.widgets:
                widget.enable = (self.operation == 'NONE' or self.operation == widget.operation) and self.modified and preference.display.dots

                if widget.enable:
                    if self.mode in {'MAKE', 'JOIN'}:
                        if widget.operation == 'EXTRUDE' and thin:
                            widget.enable = False

                        # if widget.operation == 'OFFSET' and self.modified:
                        #     widget.enable = True

                    elif widget.operation == 'OFFSET' and thin:
                        widget.enable = False

                    elif widget.operation == 'DISPLACE' and not displace:
                        widget.enable = False

                    elif widget.operation == 'BEVEL' and self.shape_type == 'CUSTOM':
                        widget.enable = False

                if not widget.enable:
                    continue

                widget.location2d = view3d.location3d_to_location2d(widget.location)

                if widget.location2d:
                    widget.highlight = math.coordinate_overlap2d(
                        # op.mouse['location'],
                        self.mouse,
                        widget.location2d,
                        size = highlight_distance())
                else:
                    widget.highlight = False
                    widget.location2d = Vector((0, 0))

                if widget.operation == self.operation:
                    widget.highlight = True

            widgets = [widget for widget in self.widgets if widget.enable]
            locations = [self.mouse - widget.location2d for widget in widgets]

            closest = widgets[locations.index(min(locations))] if locations else None
            self.active = closest.operation if locations and closest.highlight else ''

            for widget in self.widgets:
                if (widget != closest or not widget.highlight or not widget.enable) and self.operation != widget.operation:
                    widget.highlight = False
                    widget.color = color if widget.operation != 'BEVEL' else bevel_color

                elif widget.highlight or self.operation == widget.operation:
                    widget.color = Vector(preference.color.dot_highlight[:])

        if batch:
            uniform = self.shaders['uniform2d']

            for widget in self.widgets:
                if not widget.enable and not widget.location2d:
                    continue

                x = widget.location2d.x
                y = widget.location2d.y
                vert, loop_index, edge_vert, edge_index = shader.circle_coordinates(x, y,
                    size=widget.size)

                if vert != widget.vert:
                    widget.vert = vert
                    verts = {'pos': vert}
                    edge_verts = {'pos': edge_vert}
                    widget.polys = shader.batch(uniform, 'TRIS', verts, indices=loop_index)
                    widget.lines = shader.batch(uniform, 'LINES', edge_verts, indices=edge_index)

        if alpha:
            counter = time.perf_counter()

            for widget in self.widgets:
                current = 1.0 if widget.enable and not self.exit else 0.0

                if widget.fade_time:
                    current = (counter - widget.time) / widget.fade_time

                if widget.fade_type == 'IN':
                    widget.alpha = current

                    if current >= 1.0:
                        widget.fade_type = 'NONE'
                        widget.alpha = 1.0
                        widget.fade = False

                elif widget.fade_type == 'OUT':
                    widget.alpha = 1.0 - current

                    if widget.alpha <= 0.0:
                        widget.fade_type = 'NONE'
                        widget.alpha = 0.0
                        widget.fade = False

                elif widget.fade_type == 'NONE':
                    if widget.enable and not widget.alpha:
                        widget.time = counter
                        widget.fade_time = self.dot_fade_time_in
                        widget.fade_type = 'IN'
                        widget.fade = True

                    elif not widget.enable and widget.alpha:
                        widget.time = counter
                        widget.fade_time = self.dot_fade_time_out
                        widget.fade_type = 'OUT'
                        widget.fade = True

            if self.exit:
                self.fade = False
                for widget in self.widgets:
                    widget.alpha = 0.0


    def draw(self, _, context):
        method_handler(self.draw_handler,
            arguments = (_, context),
            identifier = 'Widgets Shader',
            exit_method = self.remove)


    def draw_handler(self, _, context):
        setup = self.shader
        setup(widgets2d=True, batch=True)

        for widget in self.widgets:
            color = widget.color
            color[3] *= widget.alpha
            self.lines(widget.lines, self.shaders['uniform2d'], color, width=wire_width())
            self.polys(widget.polys, self.shaders['uniform2d'], color)


    def update(self, op, context):
        method_handler(self.update_handler,
            arguments = (op, context),
            identifier = 'Widgets Update',
            exit_method = self.remove)


    def update_handler(self, op, context):
        setup = self.shader
        op = op if not self.exit else None
        setup(widgets=not self.exit, operator=op, alpha=True)


    def remove(self):
        if self.handler:
            SpaceView3D.draw_handler_remove(self.handler, 'WINDOW')
            self.handler = None

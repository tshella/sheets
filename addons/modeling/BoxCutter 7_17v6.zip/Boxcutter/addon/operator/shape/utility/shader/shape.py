import time

import bpy
import bmesh
import gpu

from bgl import *

from gpu.types import GPUShader

from bpy.types import SpaceView3D
from mathutils import Vector

from ...... utility import method_handler, addon, shader, screen


def wire_width():
    preference = addon.preference()
    bc = bpy.context.scene.bc

    width = preference.display.wire_width * screen.dpi_factor(rounded=True, integer=True)
    if preference.display.wire_only and preference.display.thick_wire:
        width *= preference.display.wire_size_factor

    return round(width) if (not bc.shape or len(bc.shape.data.vertices) > 2) else round(width * 1.5)


class setup:
    handler = None

    exit: bool = False

    @staticmethod
    def polys(batch, shader, color, xray=False):
        shader.bind()
        shader.uniform_float('color', color)

        glEnable(GL_BLEND)

        if not xray:
            glEnable(GL_DEPTH_TEST)
            glEnable(GL_CULL_FACE)
            glEnable(GL_BACK)

        batch.draw(shader)

        if not xray:
            glDisable(GL_CULL_FACE)
            glDisable(GL_DEPTH_TEST)

        glDisable(GL_BLEND)

    @staticmethod
    def lines(batch, shader, color, width, xray=False):
        shader.bind()
        shader.uniform_float('color', color)

        glEnable(GL_BLEND)
        glEnable(GL_LINE_SMOOTH)

        glLineWidth(width)

        if not xray:
            glEnable(GL_DEPTH_TEST)
            glDepthFunc(GL_LESS)

        batch.draw(shader)

        if not xray:
            glDisable(GL_DEPTH_TEST)

        glDisable(GL_LINE_SMOOTH)
        glDisable(GL_BLEND)


    def __init__(self, op):
        preference = addon.preference()
        bc = bpy.context.scene.bc

        self.running = True
        self.name = bc.shape.name
        self.verts = []
        self.last = []
        self.verts_shell = []
        self.index_tri = []
        self.index_edge = []
        self.polygons = 0

        self.mode = op.mode

        self.time = time.perf_counter()
        self.fade_time = preference.display.shape_fade_time_in * 0.001
        self.fade = bool(preference.display.shape_fade_time_in) or bool(preference.display.shape_fade_time_out)
        self.fade_type = 'IN' if bool(preference.display.shape_fade_time_in) else 'NONE'
        self.alpha = 1.0 if self.fade_type == 'NONE' else 0.0

        self.shaders = {
            'uniform': gpu.shader.from_builtin('3D_UNIFORM_COLOR')}
        self.batches = dict()

        setup = self.shader
        setup(polys=True, batch=True, color=True, operator=op)

        draw_arguments = (self.draw_handler, (op, bpy.context), 'WINDOW', 'POST_VIEW')
        self.handler = SpaceView3D.draw_handler_add(*draw_arguments)


    def shader(self, polys=False, batch=False, alpha=False, color=False, operator=None):
        preference = addon.preference() if alpha else None
        bc = bpy.context.scene.bc

        if self.running:
            self.running = bc.running

        if self.running and bc.shape:
            self.name = bc.shape.name

        ref_by_name = None
        if self.name in bpy.data.objects:
            ref_by_name = bpy.data.objects[self.name]

        shape = bc.shape if self.running else ref_by_name

        self.last = []
        if polys and shape:
            polygons = len(shape.data.polygons)

            if polygons != self.polygons:
                self.polygons = polygons

            self.last = self.verts[:]
            self.verts, self.index_tri, self.index_edge, mesh = shader.coordinates_from_mesh(shape)

            if self.last[:] != self.verts[:]:
                bm = bmesh.new()
                bm.from_mesh(mesh)

                self.verts_shell = []

                offset = min(shape.dimensions[:-1]) * 0.001

                for vert in bm.verts:
                    location = vert.co + (offset * vert.normal)
                    self.verts_shell.append(shape.matrix_world @ location)

                bm.free()

        if batch and (not self.batches or (not self.last or self.verts[:] != self.last)):
            uniform = self.shaders['uniform']
            verts = {'pos': self.verts}
            shell = {'pos': self.verts_shell}
            edges = self.index_edge

            self.batches = {
                'polys': shader.batch(uniform, 'TRIS', verts, indices=self.index_tri),
                'lines': shader.batch(uniform, 'LINES', verts, indices=edges),
                'shell': shader.batch(uniform, 'LINES', shell, indices=edges)}

        if alpha:
            current = 1.0 if not self.exit else 0.0

            if self.fade and self.fade_time:
                current = (time.perf_counter() - self.time) / self.fade_time

            if self.fade_type == 'IN':
                self.alpha = current if current < 1.0 else 1.0

                if current >= 1.0:
                    self.fade_type = 'NONE'

            elif self.fade_type == 'OUT':
                self.alpha = 1.0 - current

                if self.alpha <= 0.0:
                    self.fade_type = 'NONE'
                    self.fade = False

            elif self.fade_type == 'NONE':
                if self.fade and self.exit:
                    self.fade_time = preference.display.shape_fade_time_out * 0.001
                    self.time = time.perf_counter()
                    current = 0.0

                    self.fade_type = 'OUT'

        if color:
            preference = addon.preference()

            self.color = Vector(getattr(preference.color, operator.mode.lower()))
            self.color[3] = self.color[3] * self.alpha

            self.negative_color = Vector(preference.color.negative)
            self.negative_color[3] = self.negative_color[3] * self.alpha

            self.wire_color = Vector(preference.color.show_shape_wire[:]) if preference.behavior.show_shape else Vector(preference.color.wire[:])
            self.wire_color[3] = self.wire_color[3] * self.alpha


    def draw(self, op, context):
        method_handler(self.draw_handler,
            arguments = (op, context),
            identifier = 'Shape Shader',
            exit_method = self.remove)


    def draw_handler(self, op, context):
        preference = addon.preference()

        color = Vector(self.color)
        negative_color = Vector(self.negative_color)
        wire_color = Vector(self.wire_color)

        uniform = self.shaders['uniform']
        polys = self.batches['polys']
        lines = self.batches['lines']
        shell = self.batches['shell']

        if preference.display.wire_only or len(self.verts) < 3:
            mode_color = (color[0], color[1], color[2], wire_color[3])

            if self.polygons:
                negative_color[3] *= 0.5
                self.polys(polys, uniform, negative_color, xray=True)

            xray_wire_color = Vector(mode_color)
            xray_wire_color[3] *= 0.5
            self.lines(lines, uniform, xray_wire_color, wire_width(), xray=True)
            self.lines(shell, uniform, mode_color, wire_width())

        else:
            if self.polygons or op.shape_type == 'CIRCLE':
                xray = op.shape_type == 'NGON' and op.thin
                self.polys(polys, uniform, negative_color, xray=True)
                self.polys(polys, uniform, color, xray=xray)

            xray_wire_color = Vector(wire_color)
            xray_wire_color[3] *= 0.5
            self.lines(lines, uniform, xray_wire_color, wire_width(), xray=True)
            self.lines(shell, uniform, wire_color, wire_width())


    def update(self, op, context):
        method_handler(self.update_handler,
            arguments = (op, context),
            identifier = 'Shape Shader Update',
            exit_method = self.remove)


    def update_handler(self, op, context):
        if not self.exit:
            self.mode = op.mode

        setup = self.shader
        setup(polys=not self.exit, batch=not self.exit, alpha=True, color=True, operator=op)


    def remove(self):
        if self.handler:
            SpaceView3D.draw_handler_remove(self.handler, 'WINDOW')
            self.handler = None

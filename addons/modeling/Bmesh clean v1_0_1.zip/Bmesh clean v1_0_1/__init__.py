﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Add-on info
bl_info = {
    "name": "Bmesh Clean",
    "author": "Andrea Donati",
    "version": (1, 0, 1),
    "blender": (2, 80, 0),
    "location": "View3D > Tools > Bmesh",
    "description": "Cleaning your model!", 
    "tracker_url": "mailto:tredistudio@hotmail.com",      
    "category": "3D View"}
        
import bpy, bmesh , os
from bpy.props import StringProperty, BoolProperty ,IntProperty,FloatProperty,EnumProperty
from bpy.utils import register_class, unregister_class
from math import radians
from mathutils import Vector
from distutils.util import strtobool
from os import listdir
from os.path import isfile, join

###percorso =  os.path.join(bpy.path.abspath("//"), "Preset")
percorso =  os.path.join(os.path.dirname(__file__),"Preset")

default_preset = ['0 - default',"1 - Import clean","2 - Blender Default"]

enum_ttq = (
    ('TTQ', "Tris to quad", "Tranform triangulate polygons in quad polygons"),
    ('TRIANGULATE', "Triangulate", "Triangulate quad faces"),
)
enum_inout =(
    ('IN', "Inside", "Adjust Backface inside"),
    ('OUT', "Outside", "Adjust Backface outside"),
)
    
enum_quad_method = (
    ('BEAUTY',"Beauty","Split the quads in nice triangles, slower method"),
    ('FIXED',"Fixed","Split the quads on the first and third vertices"),
    ('ALTERNATE',"FIxed alternate","Split the quads on the 2nd and 4th vertices"),
    ('SHORT_EDGE',"Shortest diagonal","Split the quads based on the distance between the vertices"))
    
enum_quad_polymet = (
    ('BEAUTY',"Beauty","Arrange the nwe triangles evenly"),
    ('EAR_CLIP',"Clip","Split the polygons with an ear clipping algorithm"))
                  
def bmesh_clean():
    
    selected = bpy.context.selected_objects
 
    
    
    mesh_list = []
    for o in selected:
        if o.type == 'MESH':
            mesh_list.append(o)
             
    if bpy.context.view_layer.objects.active == None:
        bpy.context.view_layer.objects.active = mesh_list[0]
       
    if bpy.context.view_layer.objects.active.type != 'MESH':
        bpy.context.view_layer.objects.active = mesh_list[0]
            
        
        
    
        
    bpy.ops.object.mode_set(mode='OBJECT')
   
    preset = bpy.context.scene.scene_check_set
    ##delete loose:
    delete_loose = preset.delete_loose
    loose_vertex = preset.loose_vertex
    loose_edge = preset.loose_edge
    loose_face = preset.loose_face    
    ###Remove Doubles:
    delete_double = preset.delete_double
    double_value = preset.double_value
    ###
    make_normal = preset.make_normal
    limited_dissolve = preset.limited_dissolve    
    in_out_menu = preset.in_out_menu            
    t_t_t_q = preset.t_t_t_q
    tris_quad_menu = preset.tris_quad_menu
    quad_method =  preset.quad_method
    quad_polymet = preset.quad_polymet    
    ######tris to quad:        
    max_face_angle = preset.max_face_angle
    max_shape_angle = preset.max_shape_angle
    compare_uv = preset.compare_uv
    compare_vcols = preset.compare_vcols
    compare_seam = preset.compare_seam
    compare_sharp = preset.compare_sharp
    compare_materials = preset.compare_materials     
    ###limited dissolve:   
    dissolve_value = preset.dissolve_value   
    all_boundaries = preset.all_boundaries      
    regular_dissolve = preset.regular_dissolve
    material_dissolve = preset.material_dissolve
    seam_dissolve = preset.seam_dissolve
    sharp_dissolve = preset.sharp_dissolve
    uvs_dissolve = preset.uvs_dissolve
                        
 
    
    context = bpy.context        
    meshes = set(o.data for o in context.selected_objects if o.type == 'MESH')
    
    first_ver = []
    first_edg = []
    first_fac = []
       
    for o in context.selected_objects:
        if o.type != 'MESH':
            continue
        me = o.data
        vertices = len(me.vertices)
        edges = len(me.edges)
        faces = len(me.polygons)
        
        first_ver.append(vertices)
        first_edg.append(edges)
        first_fac.append(faces)
     
    if delete_loose == True:
        
        if loose_vertex == True:
        
            bm = bmesh.new()

            for m in meshes:

                bm.from_mesh(m)
               
                verts = [v for v in bm.verts if not v.link_faces]
                             
                for v in verts:
                    bm.verts.remove(v)

                bm.to_mesh(m)
                m.update()
                bm.clear()
                
        if loose_edge  == True:
                          
             bm = bmesh.new()
             for m in meshes:
                bm.from_mesh(m)
                edges = [e for e in bm.edges if not e.link_faces]
               
                for e in edges:
                    bm.edges.remove(e)

                bm.to_mesh(m)
                m.update()
                bm.clear()
                              
    if delete_double == True:
            
        bm = bmesh.new()
        for m in meshes:
            bm.from_mesh(m)
            bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=double_value)
            bm.to_mesh(m)
            m.update()
            bm.clear()

        bm.free()

    if t_t_t_q == True:

        if tris_quad_menu == "TRIANGULATE":
        
            bm = bmesh.new()
            
            for m in meshes:
                bm.from_mesh(m)
                bmesh.ops.triangulate(bm, faces=bm.faces[:], quad_method=quad_method, ngon_method = quad_polymet)
                bm.to_mesh(m)
                m.update()
                bm.clear()
            bm.free()
            
        if tris_quad_menu == 'TTQ':
                       
            bm = bmesh.new()
            
            for m in meshes:
                bm.from_mesh(m)
                bmesh.ops.join_triangles(bm, faces=bm.faces[:],
                    angle_face_threshold = radians(max_face_angle),
                    angle_shape_threshold = radians(max_shape_angle),
                    cmp_seam = compare_seam,
                    cmp_uvs=compare_uv,
                    cmp_vcols=compare_vcols,
                    cmp_sharp = compare_sharp,
                    cmp_materials=compare_materials)
                    
                bm.to_mesh(m)
                m.update()
                bm.clear()
            bm.free()

    if limited_dissolve == True:
        
        dissolve_mode = {'NORMAL','MATERIAL','SEAM','SHARP','UV'}
        
        if regular_dissolve == False:
            dissolve_mode.remove('NORMAL')
        if material_dissolve == False:
            dissolve_mode.remove('MATERIAL')
        if seam_dissolve == False:
            dissolve_mode.remove('SEAM')
        if sharp_dissolve  == False:
            dissolve_mode.remove('SHARP')        
        if uvs_dissolve  == False:
            dissolve_mode.remove('UV')
        
        distance = dissolve_value
        
        bm = bmesh.new()

        for m in meshes:
            bm.from_mesh(m)
            bmesh.ops.dissolve_limit(bm, angle_limit=radians(distance),use_dissolve_boundaries = all_boundaries, verts=bm.verts, edges=bm.edges, delimit = dissolve_mode)
            bm.to_mesh(m)
            m.update()
            bm.clear()

        bm.free()
               
    if make_normal == True:
        
        bm = bmesh.new()
        
        for m in meshes:
            bm.from_mesh(m)      
            bmesh.ops.recalc_face_normals(bm,faces = bm.faces)
            bm.to_mesh(m)
            m.update()
            bm.clear()
        bm.free()
        
        if in_out_menu != 'IN':
            bm = bmesh.new()
            
            for m in meshes:
                bm.from_mesh(m)                   
                bmesh.ops.reverse_faces(bm,faces = (bm.faces), flip_multires = True)
                bm.to_mesh(m)
                m.update()
                bm.clear()
            bm.free()
    
     
    second_ver = []
    second_edg = []
    second_fac = []        
    for o in context.selected_objects:
        if o.type != 'MESH':
            continue
        me = o.data
        vertices = len(me.vertices)
        edges = len(me.edges)
        faces = len(me.polygons)
        
        second_ver.append(vertices)
        second_edg.append(edges)
        second_fac.append(faces)
   

        
    if  first_fac != second_fac:     
        preset.result_faces = -(sum(first_fac) - sum(second_fac))
    else:
        preset.result_faces = 0     
    if first_ver != second_ver:
        preset.result_vertex = -(sum(first_ver) - sum(second_ver))
    else:
        preset.result_vertex = 0
    if first_edg != second_edg:
        preset.result_edges = -(sum(first_edg) - sum(second_edg))
    else:
        preset.result_edges = 0
            
    bpy.ops.object.mode_set(mode='EDIT')
    return
    
class PurgeOperatorButton(bpy.types.Operator):

    """Apply to selected object"""
   
    bl_idname = "clean.operator"
    bl_label = "Result of the count:"
        
    def execute(self,context):
        bpy.ops.object.mode_set(mode='OBJECT')
        
        return{'FINISHED'}
    
    def invoke(self, context, event):
        selected = bpy.context.selected_objects
        check = []
        for o in selected:
            if o.type == 'MESH':
                check.append(o)
                
        if len(check) == 0:
            return {'FINISHED'}   
             
        bmesh_clean()
        return context.window_manager.invoke_props_dialog(self, width = 200)

    def draw(self,context):
        
        sett = bpy.context.scene.scene_check_set 
        self.layout.label(text = "")
        self.layout.label(text = "Vertices: " + str(sett.result_vertex))
        self.layout.label(text = "Edges: " + str(sett.result_edges))
        self.layout.label(text = "Faces: " + str(sett.result_faces))
            
class PURGE_PT_FacesPanel(bpy.types.Panel):
    
    bl_label = "Bmesh Clean"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Bmesh"
    
    def draw(self, context):
           
        wm = context.window_manager   
        delete_double = bpy.context.scene.scene_check_set.delete_double
        limited_dissolve = bpy.context.scene.scene_check_set.limited_dissolve  
        t_t_t_q = bpy.context.scene.scene_check_set.t_t_t_q
        tris_quad_menu = bpy.context.scene.scene_check_set.tris_quad_menu
        quad_polymet = bpy.context.scene.scene_check_set.quad_polymet 
        make_normal = bpy.context.scene.scene_check_set.make_normal 
        delete_loose = bpy.context.scene.scene_check_set.delete_loose
        preset_tool = bpy.context.scene.scene_check_set.preset_tool               
        scn = context.scene
        layout = self.layout
       	col = layout.column(align=True)       
        split = layout.row()
        row = layout.split()           
        row.scale_y = 2
        row.operator("clean.operator", text='Apply to selected')        
        split = layout.row()        
        box = layout.box()          
        col = box.column(align = True)
        row1 = col.row(align = True) 
         
        row1.prop(scn.scene_check_set, 'preset_tool',  text="Preset tool",icon = 'DISCLOSURE_TRI_DOWN' if preset_tool else 'DISCLOSURE_TRI_RIGHT')
               
        if preset_tool == True:
            
            col = box.column(align = True)
            row1 = col.row(align = True)
            row1.operator('aggiungi.preset',text="Save", icon = 'PRESET_NEW')
            col = box.column(align = True)
            row1.scale_x = 1.75
            row1.prop(scn.scene_check_set,'preset_save_name',text = "")          
            row1 = col.row(align = True)
            row1.operator('cancella.preset',text="Delete:", icon = 'CANCEL')
            row1.scale_x = 1.75
            row1.prop(scn.scene_check_set,'preset_list',text="")
         
        box = layout.box()          
        col = box.column(align = True)
        row = col.row(align = True)
        
        row.prop(scn.scene_check_set, 'delete_loose',  text="Delete Loose",icon = 'DISCLOSURE_TRI_DOWN' if delete_loose else 'DISCLOSURE_TRI_RIGHT')
                
        if delete_loose == True:
            
            col = box.column(align = True)     
            row = col.row(align = True)
            row.prop(scn.scene_check_set, 'loose_vertex',  text="Vertex")
            row.prop(scn.scene_check_set, 'loose_edge',  text="Edge")
            #row.prop(scn.scene_check_set, 'loose_face',  text="Face")
                
        row = layout.box()       
        row.prop(scn.scene_check_set, 'delete_double',  text="Remove Doubles",icon = 'DISCLOSURE_TRI_DOWN' if delete_double else 'DISCLOSURE_TRI_RIGHT')
        if delete_double == True:
                
            row.prop(scn.scene_check_set, 'double_value',  text="Double Distance")
                        
        row = layout.box()        
        row.prop(scn.scene_check_set, 't_t_t_q',  text = "Subdivision Type", icon = 'DISCLOSURE_TRI_DOWN' if t_t_t_q else 'DISCLOSURE_TRI_RIGHT')
        
        if t_t_t_q == True:  
                      
            row.prop(scn.scene_check_set, 'tris_quad_menu', text = 'Tris or Quad')  
            
            if  tris_quad_menu == 'TRIANGULATE':
                                
                row = layout.box()                            
                row.prop(scn.scene_check_set, 'quad_method',text = 'Quad Method')
                row.prop(scn.scene_check_set, 'quad_polymet', text = 'Polygon Method') 
            
            if tris_quad_menu == 'TTQ':
                                                       
                row.prop(scn.scene_check_set, 'max_face_angle', text = 'Max face angle')
                row.prop(scn.scene_check_set, 'max_shape_angle' , text = 'Max shape angle')
                row.prop(scn.scene_check_set, 'compare_uv', text = 'Compare UVs')               
                row.prop(scn.scene_check_set, 'compare_vcols',text = 'Compare VCols')                
                row.prop(scn.scene_check_set, 'compare_seam', text = 'Compare Seam')
                row.prop(scn.scene_check_set, 'compare_sharp', text = 'Compare Sharp')               
                row.prop(scn.scene_check_set, 'compare_materials', text = 'Compare Materials')
                               
        box = layout.box()          
        col = box.column(align = True)
        row = col.row(align = True)
        
        row.prop(scn.scene_check_set, 'limited_dissolve',  text = "Limited Dissolve", icon = 'DISCLOSURE_TRI_DOWN' if limited_dissolve else 'DISCLOSURE_TRI_RIGHT')
        
        if limited_dissolve == True:
            col = box.column(align = True)
            row = col.row(align = True)          
            row.prop(scn.scene_check_set, 'dissolve_value', text = 'Max value°')
            row = col.row(align = True)                
            row.prop(scn.scene_check_set, 'all_boundaries',  text = "All Boundaries") 
            row = col.row(align = True)          
            row.prop(scn.scene_check_set, 'regular_dissolve',  text = "Regular")
            row.prop(scn.scene_check_set, 'material_dissolve',  text = "Material")
            row = col.row(align = True)
            row.prop(scn.scene_check_set, 'seam_dissolve',  text = "Seam")
            row.prop(scn.scene_check_set, 'sharp_dissolve',  text = "Sharp")
            row = col.row(align = True)
            row.prop(scn.scene_check_set, 'uvs_dissolve',  text = "UVs")
                     
        row = layout.box()        
        row.prop(scn.scene_check_set, 'make_normal',  text="Make Normals Cosistent",icon = 'DISCLOSURE_TRI_DOWN' if make_normal else 'DISCLOSURE_TRI_RIGHT')
        
        if make_normal == True:
            
            row.prop(scn.scene_check_set, 'in_out_menu', text = 'Orient face:')
                                
def updatepreset(self,context): 
   
    set = bpy.context.scene.scene_check_set
    dir_name = set.preset_list
        
    if dir_name not in default_preset :
        set.preset_save_name = dir_name
    else:
        set.preset_save_name = ''
     
    with open(percorso + os.sep + dir_name + ".txt") as f:
        
        opzione = f.read().split()
                
    set.delete_loose = strtobool(opzione[0])
    set.loose_vertex = strtobool(opzione[1])
    set.loose_edge = strtobool(opzione[2])    
    set.delete_double = strtobool(opzione[3])
    set.double_value = float(opzione[4])    
    set.t_t_t_q = strtobool(opzione[5])
    set.tris_quad_menu = opzione[6]    
    set.max_face_angle = float(opzione[7])
    set.max_shape_angle = float(opzione[8])
    set.compare_seam = strtobool(opzione[9])
    set.compare_uv = strtobool(opzione[10])
    set.compare_vcols = strtobool(opzione[11])
    set.compare_sharp = strtobool(opzione[12])
    set.compare_materials = strtobool(opzione[13])        
    set.quad_method = opzione[14]
    set.quad_polymet = opzione[15]    
    set.limited_dissolve = strtobool(opzione[16])
    set.dissolve_value = float(opzione[17]) 
    set.regular_dissolve = strtobool(opzione[18])
    set.material_dissolve = strtobool(opzione[19])
    set.seam_dissolve = strtobool(opzione[20])
    set.sharp_dissolve = strtobool(opzione[21])
    set.uvs_dissolve = strtobool(opzione[22])  
    set.make_normal = strtobool(opzione[23])      
    set.in_out_menu = opzione[24]
    set.all_boundaries = strtobool(opzione[25])
  
    return 
  
def items_preset(self, context):
    
    dirListing = os.listdir(percorso)
    file_name = []
    for item in dirListing:
        if ".txt" in item:
            file_name.append(item)
            
    return [(name[:-4], name[:-4], "") for name in file_name]
     
class AddPreset(bpy.types.Operator):
    """Save/overwrite preset (write the preset name first)"""
   
    bl_idname = "aggiungi.preset"
    bl_label = "AggiungiPreset"
    
    def execute(self,context):
               
        set = bpy.context.scene.scene_check_set
        dir_name = set.preset_save_name
        pres_name = set.preset_list
                            
        if dir_name not in default_preset:
                                    
            file = open(percorso + os.sep +  dir_name + ".txt", "w")        
            file.write(str(set.delete_loose) + " " + 
                       str(set.loose_vertex) + " " +
                       str(set.loose_edge) + " " +
                       str(set.delete_double) + " " +
                       str(set.double_value) + " " +
                       str(set.t_t_t_q) + " " +
                       set.tris_quad_menu + " " +
                       str(set.max_face_angle) + " " +
                       str(set.max_shape_angle) + " " +
                       str(set.compare_seam) + " " +
                       str(set.compare_uv) + " " +
                       str(set.compare_vcols) + " " +
                       str(set.compare_sharp) + " " +
                       str(set.compare_materials) + " " +
                       set.quad_method + " " +
                       set.quad_polymet + " " +
                       str(set.limited_dissolve) + " " +
                       str(set.dissolve_value) + " " +
                       str(set.regular_dissolve) + " " +
                       str(set.material_dissolve) + " " +
                       str(set.seam_dissolve) + " " +
                       str(set.sharp_dissolve) + " " +
                       str(set.uvs_dissolve) + " " +                      
                       str(set.make_normal) + " " +
                       set.in_out_menu + " " +
                       str(set.all_boundaries)
                       )          
            file.close()                 
            set.preset_list = dir_name                 
            items_preset(self, context) 
         
        return{'FINISHED'}
       
class ClearPreset(bpy.types.Operator):
    """Delete current preset (Default presets cannot be deleted)"""
    
    bl_idname = "cancella.preset"
    bl_label = "CancellaPreset"
    
    def execute(self,context):
        
        
        set = bpy.context.scene.scene_check_set
        pres_name = set.preset_list

             
        if pres_name not in default_preset:
        
            os.remove(percorso + os.sep + pres_name + ".txt")
            
            items_preset(self, context)
            
            set.preset_list = '0 - default'
          
        return{'FINISHED'}
       
class PropPerSet(bpy.types.PropertyGroup):
       
    preset_tool: BoolProperty(default = False, description = 'Preset tool  area')
    preset_list: EnumProperty(items = items_preset, update = updatepreset)
    ###remove doubles:
    delete_double: BoolProperty(default = False, description = "Delete double face")
    double_value: FloatProperty(min = 0.0001,max = 10, default = 0.0001,description = "Minumum distance between elements to merge")
    use_unselected: BoolProperty(default = False, description = "Merge selected to other unselected vertices")
    make_normal: BoolProperty(default = False, description = "Adjust/Orient mesh Faces")
    limited_dissolve: BoolProperty(default = False, description = "Erases unnecessary edges")    
    ###Triangulate
    t_t_t_q: BoolProperty(default = False, description = "Transform mesh subdivision")
    tris_quad_menu: EnumProperty(items=enum_ttq)
    quad_method: EnumProperty(items = enum_quad_method)
    quad_polymet: EnumProperty(items = enum_quad_polymet)
    ################
    ####Tris to quad:
    max_face_angle: FloatProperty(min = 0,max= 180, default = 40,description = "Face angle limit")
    max_shape_angle: FloatProperty(min = 0,max= 180, default = 40,description = "Shape angle limit")
    compare_uv: BoolProperty(default = False)
    compare_vcols: BoolProperty(default = False)
    compare_seam: BoolProperty(default = False)
    compare_sharp: BoolProperty(default = False)
    compare_materials: BoolProperty(default = False)
    ################
    ################       
    in_out_menu: EnumProperty(items=enum_inout)   
    dissolve_value: FloatProperty(min = 0 ,max = 180, default = 0.1,description = "Minimum angle dissolve")
    all_boundaries: BoolProperty(default = False, description = "Dissolve all vertices inbetween face boundaries")
    regular_dissolve: BoolProperty(default = False,description = "Delimit by face directions")
    material_dissolve: BoolProperty(default = False, description = "Delimit by face material")
    seam_dissolve: BoolProperty(default = False,description = "Delimit by edge seams")
    sharp_dissolve: BoolProperty(default = False, description = "Delimit by sharp edges")
    uvs_dissolve: BoolProperty(default = False, description = "Delimit by UV coordinates")
    
    ###delete loose:  
    delete_loose: BoolProperty(default = False , description = "Remove loose: edge, vertex")
    loose_vertex: BoolProperty(default = False)
    loose_edge: BoolProperty(default = False)
    loose_face: BoolProperty(default = False)
    preset_save_name: StringProperty()
       
    result_vertex: IntProperty()
    result_edges: IntProperty()
    result_faces: IntProperty()

def register():
	  
    from bpy.types import (WindowManager,
    Panel,
    Operator,
    AddonPreferences,
    Object,
    PropertyGroup,
    Scene)
       
    from bpy.props import (
        StringProperty,
        BoolProperty,
        PointerProperty,
        IntProperty,
        FloatProperty
    )
    
    bpy.utils.register_class(PropPerSet)
    bpy.utils.register_class(PURGE_PT_FacesPanel)
    bpy.utils.register_class(PurgeOperatorButton)
    bpy.utils.register_class(AddPreset)
    bpy.utils.register_class(ClearPreset)
    Scene.scene_check_set = bpy.props.PointerProperty(type = PropPerSet)
        
def unregister():
    
    bpy.utils.unregister_class(PropPerSet)
    bpy.utils.unregister_class(PURGE_PT_FacesPanel)
    bpy.utils.register_class(PurgeOperatorButton)
    bpy.utils.unregister_class(AddPreset)
    bpy.utils.unregister_class(ClearPreset)

if __name__ == "__main__":
    register()
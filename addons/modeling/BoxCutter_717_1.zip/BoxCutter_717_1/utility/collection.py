import bpy


def view_layer_unhide(collection, check=None, chain=[], enable=False):
    view_layer_collection = bpy.context.view_layer.layer_collection
    current = view_layer_collection if not check else check

    if collection.name in current.children:
        collection.hide_viewport = False

        collection = current.children[collection.name]
        collection.hide_viewport = False

        if enable:
            collection.exclude = False

        for col in chain:
            col.hide_viewport = False
            bpy.data.collections[col.name].hide_viewport = False

            if enable:
                col.exclude = False

        return True

    for child in current.children:
        if not child.children:
            continue

        if check:
            chain.append(check)

        if view_layer_unhide(collection, check=child, chain=chain, enable=enable):
            child.hide_viewport = False
            bpy.data.collections[child.name].hide_viewport = False

            if enable:
                child.exclude = False

            return True

    return False

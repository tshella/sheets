import bpy

from bpy.types import Operator
from bpy.props import BoolProperty, EnumProperty

from .... utility import addon, object
from .. utility import st3_simple_notification
from ... import toolbar
from mathutils import Matrix


class BC_OT_box(Operator):
    bl_idname = 'bc.box'
    bl_label = 'Box'
    bl_description = ('Draws using box shape utilizing corner draw by default.\n\n'
                      'Hotkeys :\n\n'
                      'Alt - center draw\n'
                      'Shift - square proportion constrain\n'
                      'Shift + Alt - center box draw\n'
                      'Period during draw toggles center draw if needed')
    bl_options = {'INTERNAL'}


    def execute(self, context):
        toolbar.options().shape_type = 'BOX'
        preference = addon.preference()
        preference.behavior.line_box = False

        context.workspace.tools.update()

        return {'FINISHED'}


class BC_OT_circle(Operator):
    bl_idname = 'bc.circle'
    bl_label = 'Circle'
    bl_description = ('Draws using round plane figure whose boundary consists of points equidistant from the center.\n'
                      'Typically defaults to center draw.\n\n'
                      'Hotkeys :\n\n'
                      'Alt - free constrain\n'
                      'Alt + Shift - center contrain\n'
                      'Period during draw toggles corner / center draw if needed')
    bl_options = {'INTERNAL'}


    def execute(self, context):
        toolbar.options().shape_type = 'CIRCLE'
        preference = addon.preference()
        preference.behavior.line_box = False

        context.workspace.tools.update()

        return {'FINISHED'}


class BC_OT_ngon(Operator):
    bl_idname = 'bc.ngon'
    bl_label = 'Ngon'
    bl_description = ('Draws using custom points determined by the user.\n'
                      'Hold Ctrl during draw to angle snap.\n'
                      'Line is also available by pressing C during draw')
    bl_options = {'INTERNAL'}


    def execute(self, context):
        toolbar.options().shape_type = 'NGON'
        preference = addon.preference()
        preference.shape.lasso = False
        preference.shape.cyclic = True

        context.workspace.tools.update()

        return {'FINISHED'}


class BC_OT_custom(Operator):
    bl_idname = 'bc.custom'
    bl_label = 'Custom'
    bl_description = ('Draws utilizing custom shape.\n'
                      'Without a specified mesh the boxcutter logo will be drawn\n'
                      'Specify custom mesh using dropdown in tool options or select mesh and press C\n'
                      'Capable of utilizing itself as cutter for self.cut')
    bl_options = {'INTERNAL'}

    set: BoolProperty(default=False)


    def execute(self, context):
        bc = context.scene.bc
        option = toolbar.options()

        obj = context.active_object
        assigned = False

        if not self.set:
            option.shape_type = 'CUSTOM'

        if self.set and obj and obj.type in {'MESH', 'FONT'} and option.shape_type == 'CUSTOM':
            assigned = True
            bc.shape = obj
            text = F'Custom Shape: {bc.shape.name}'
            st3_simple_notification(text)
            self.report({'INFO'}, text)

        context.workspace.tools.update()

        if self.set and not assigned:
            return {'PASS_THROUGH'} # XXX: pass through for circle select

        return {'FINISHED'}


class BC_OT_subtype_scroll(Operator):
    bl_idname = 'bc.subtype_scroll'
    bl_label = 'Shape Type'
    bl_description = 'Scroll through shape types'
    bl_options = {'INTERNAL'}

    direction: EnumProperty(items=[('UP', 'Up', ''), ('DOWN', 'Down', '')])


    def invoke(self, context, event):
        preference = addon.preference()
        bc = context.scene.bc
        option = toolbar.options()

        if bc.running:
            return {'PASS_THROUGH'}

        line_box = preference.behavior.line_box
        wedge = preference.shape.wedge
        lasso = preference.shape.lasso
        cyclic = preference.shape.cyclic

        order = [
            'CIRCLE',
            'BOX',
            'LINE BOX',
            'WEDGE',
            'CUSTOM',
            'NGON',
            'NONCYCLIC',
            'LASSO',
        ]

        check = {
            'CIRCLE': option.shape_type == 'CIRCLE',
            'BOX': option.shape_type == 'BOX' and not line_box and not wedge,
            'LINE BOX': option.shape_type == 'BOX' and line_box and not wedge,
            'WEDGE': option.shape_type == 'BOX' and line_box and wedge,
            'CUSTOM': option.shape_type == 'CUSTOM',
            'NGON': option.shape_type == 'NGON' and cyclic and not lasso,
            'NONCYCLIC': option.shape_type == 'NGON' and not cyclic and not lasso,
            'LASSO': option.shape_type == 'NGON' and lasso,
        }

        argument = {
            'CIRCLE': {'shape': 'CIRCLE'},
            'BOX': {'shape': 'BOX'},
            'LINE BOX': {'shape': 'BOX', 'line_box': True},
            'WEDGE': {'shape': 'BOX', 'wedge': True},
            'CUSTOM': {'shape': 'CUSTOM'},
            'NGON': {'shape': 'NGON', 'cyclic': True},
            'NONCYCLIC': {'shape': 'NGON'},
            'LASSO': {'shape': 'NGON', 'lasso': True},
        }

        element_count = len(order)
        for index, shape in enumerate(order):
            if not check[shape]:
                continue

            self.update_subtype(**argument[order[index-1] if self.direction == 'DOWN' else order[index+1 if index+1 < element_count else 0]])

            break

        return {'FINISHED'}


    def update_subtype(self, shape='BOX', line_box=False, wedge=False, cyclic=False, lasso=False):
        preference = addon.preference()
        option = toolbar.options()
        option.shape_type = shape

        preference.behavior.line_box = line_box or wedge
        preference.shape.wedge = wedge
        preference.shape.cyclic = cyclic or lasso
        preference.shape.lasso = lasso

        shape_type = shape
        if line_box:
            shape_type = F'Line {shape_type}'
        elif wedge:
            shape_type = 'Wedge'
        elif cyclic:
            pass
        elif shape == 'NGON' and not cyclic and not lasso:
            shape_type += ' (Line)'
        elif lasso:
            shape_type = 'Lasso'

        text = F'Shape Type: {shape_type.title()}'
        st3_simple_notification(text)
        self.report({'INFO'}, text)

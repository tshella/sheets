# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

bl_info = {
    "name": "Construction Lines",
    "description": "Measure distances, build construction guides, draw lines and build primitive shapes in place.",
    "author": "Daniel Norris, DN DRAWINGS <https://dndrawings.com>",
    "version": (0, 9, 2),
    "blender": (2, 80, 0),
    "location": "View3D > TOOLS",
    "wiki_url": "http://dndrawings.com/add-ons",
    "doc_url": "http://dndrawings.com/add-ons", #2.83 onwards
    "tracker_url": "http://dndrawings.com/contact",
    "category": "3D View",
}


if "bpy" in locals():
    import importlib

    try:
        importlib.reload(construction_lines28)
        importlib.reload(cl_ctxmenu)
    except Exception as E:
        print(E)
else:
    from . import construction_lines28

    # from . import cl_ctxmenu

    from .construction_lines28 import VIEW_OT_ConstructionLines, CLSettings
    from .cl_ctxmenu import (
        CL_CTX_Menu,
        VIEW_OT_CLMenuAction,
        register_icons,
        unregister_icons,
    )

import bpy

from bpy.props import EnumProperty, PointerProperty, FloatVectorProperty
from bpy.types import AddonPreferences

CL_GUIDE_COL = (0.3, 0.3, 0.3, 1.0)


#############################################
# WORKSPACE TOOL
############################################
from bpy.utils.toolsystem import ToolDef

addon_keymaps = []
CL_ = "Construction Lines"


@ToolDef.from_fn
def tool_cl():
    import os

    def draw_settings(context, layout, tool):
        pass

    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    return dict(
        idname="cl.construction_lines",
        label="Construction Lines",
        description="Measure distances, build construction guides, draw lines and build primitive shapes in place.\nShortcut Alt `",
        icon=os.path.join(icons_dir, "ops.view3d.construction_lines"),
        widget="",
        keymap=CL_,
        draw_settings=draw_settings,
    )


# -----------------------------------------------------------------------------
# Tool Registraion
def get_tool_list(space_type, context_mode):
    from bl_ui.space_toolsystem_common import ToolSelectPanelHelper

    cls = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
    return cls._tools[context_mode]


def register_cl_tool():
    tools = get_tool_list("VIEW_3D", "EDIT_MESH")

    for idx, tool in enumerate(tools, 1):
        if isinstance(tool, ToolDef) and tool.label == "Measure":
            break

    if idx > -1:
        tools[:idx] += None, tool_cl
    else:
        tools[: len(tools)] += None, tool_cl

    tools = get_tool_list("VIEW_3D", "OBJECT")
    tools += None, tool_cl
    del tools


def unregister_cl_tool():
    tools = get_tool_list("VIEW_3D", "EDIT_MESH")
    idx = tools.index(tool_cl) - 1  # None
    tools.pop(idx)
    tools.remove(tool_cl)
    tools = get_tool_list("VIEW_3D", "OBJECT")
    idx = tools.index(tool_cl) - 1  # None
    tools.pop(idx)
    tools.remove(tool_cl)
    del tools
    del idx


############################################
# Add-on Preferences
############################################
class CLAddonPreferences(AddonPreferences):

    bl_idname = __name__

    cl_guide_col: FloatVectorProperty(
        name="Colour Of Guide Lines:",
        subtype="COLOR_GAMMA",
        size=4,
        default=CL_GUIDE_COL,
    )

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.use_property_split = True
        row.prop(self, "cl_guide_col")


#############################################
# REG/UN_REG
############################################


classes = (
    VIEW_OT_ConstructionLines,
    CLSettings,
    CL_CTX_Menu,
    VIEW_OT_CLMenuAction,
    CLAddonPreferences,
)

enum_menu_items = [
    ("OPT1", "Metric(mm)", "", 1),
    ("OPT2", "Metric(cm)", "", 2),
    ("OPT3", "Metric(m)", "", 3),
    ("OPT4", "Imperial(inch)", "", 4),
    ("OPT5", "Imperial(feet & inch)", "", 5),
]


def km_cl():
    return [
        (
            CL_,
            {"space_type": "VIEW_3D", "region_type": "WINDOW"},
            {
                "items": [
                    (
                        "view3d.construction_lines",
                        {"type": "MOUSEMOVE", "value": "ANY"},
                        {"properties": []},
                    )
                ]
            },
        )
    ]


def register_keymaps():
    keyconfigs = bpy.context.window_manager.keyconfigs
    kc_defaultconf = keyconfigs.default
    kc_addonconf = keyconfigs.addon

    from bl_keymap_utils.io import keyconfig_init_from_data

    keyconfig_init_from_data(kc_defaultconf, km_cl())
    keyconfig_init_from_data(kc_addonconf, km_cl())

    # keymap
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(
        name="Window", space_type="EMPTY", region_type="WINDOW"
    )
    kmi = km.keymap_items.new(
        "view3d.construction_lines", type="ACCENT_GRAVE", alt=True, value="PRESS",
    )
    addon_keymaps.append((km, kmi))


def unregister_keymaps():
    keyconfigs = bpy.context.window_manager.keyconfigs
    defaultmap = keyconfigs.get("blender").keymaps
    addonmap = keyconfigs.get("blender addon").keymaps

    km_name, km_args, km_content = km_cl()[0]
    addonmap.remove(addonmap.find(km_name, **km_args))
    defaultmap.remove(defaultmap.find(km_name, **km_args))


def register():
    from bpy.utils import register_class

    register_keymaps()
    register_icons()
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.units_enum = bpy.props.EnumProperty(items=enum_menu_items)
    bpy.types.Scene.cl_settings = bpy.props.PointerProperty(type=CLSettings)

    register_cl_tool()


def unregister():
    from bpy.utils import unregister_class

    for cls in reversed(classes):
        try:
            unregister_class(cls)
        except RuntimeError:
            pass
    unregister_cl_tool()
    del bpy.types.Scene.units_enum

    # keymap
    # wm = bpy.context.window_manager
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    # clear list
    addon_keymaps.clear()

    unregister_icons()
    unregister_keymaps()


if __name__ == "__main__":
    register()

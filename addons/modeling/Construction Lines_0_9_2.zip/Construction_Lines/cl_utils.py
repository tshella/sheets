# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import math
import bpy
import bmesh

import re

from mathutils import Vector
from bpy_extras.view3d_utils import location_3d_to_region_2d
from . import cl_geom as clg


def debug_log(cl_op, msg):
    cl_op.report({"INFO"}, msg)


CL_COL_NAME = "Construction Lines"  # Parent object - Collection 2.8
CL_C_NAME = "_CL_"  # CL Object
CL_C_POINTNAME = "_CL_POINT"
CL_C_LINENAME = "_CL_LINE"
CL_C_RECTNAME = "_CL_RECT"
CL_C_CIRCLENAME = "_CL_CIRCLE"
CL_C_ARCNAME = "_CL_ARC"
CL_NEW_NAME = "CL_POINT_FACE"
CL_TOOL_NAME = "cl.construction_lines"

ACTION_HIDESHOW = "ACTION_HIDESHOW"
ACTION_REMOVEALL = "ACTION_REMOVEALL"
ACTION_EXITCANCEL = "ACTION_EXITCANCEL"
ACTION_MOVE = "ACTION_MOVE"
ACTION_FACE = "ACTION_FACE"
ACTION_DRAWTAPE = "ACTION_DRAWTAPE"
ACTION_DRAWLINE = "ACTION_DRAWLINE"
ACTION_DRAWRECT = "ACTION_DRAWRECT"
ACTION_DRAWCIRCLE = "ACTION_DRAWCIRCLE"
ACTION_DRAWARC = "ACTION_DRAWARC"
ACTION_SCALE_CLS = "ACTION_SCALE_CLS"

CL_BEST_DIST = 530
CL_BEST_E_DIST = 23  # sqrt of BEST_DIST
CL_FACE_SNAP_SENSITIVITY = 1
CL_DEFAULT_CIR_SEGS = 12
CL_DEFAULT_GUIDE_DIVISIONS = 1
CL_CLOSE_AXIS_TOL = 0.89
CL_CLOSE_AXIS_TOL_O = 0.99
CL_CP_SCALE = 0.2
CL_GRAPH_MAX_DEPTH = 32
CL_SELECT_REGION_SIZE = 25

CL_HIGHLIGHT_COL = (0.5, 1.0, 0.1, 0.5)
CL_HIGHLIGHT_COL_VERT = (0.5, 1.0, 0.1, 0.5)
CL_HIGHLIGHT_COL_EDGE_C = (0.59, 0.1, 0.7, 1)
CL_HIGHLIGHT_COL_EDGE = (0.3, 0.3, 0.9, 1)
CL_HIGHLIGHT_COL_FACE = (0.3, 0.9, 0.9, 1)
CL_SELECT_COL = (0.75, 0.1, 0.1, 1)
CL_XAXIS_COL = (1.0, 0.1, 0.1, 1.0)
CL_YAXIS_COL = (0.1, 1.0, 0.1, 1.0)
CL_ZAXIS_COL = (0.1, 0.5, 1, 1.0)
CL_GUIDE_COL = (0.3, 0.3, 0.3, 1.0)
CL_DEFAULT_COL = (1, 1, 0.2, 1)

CL_STATE_MC = "MEASURE CREATE STATE"
CL_STATE_MV = "MOVE STATE"
CL_STATE_EX = "EXTRUDE STATE"

TYPE_VERT = "VERT"
TYPE_EDGE = "EDGE"
TYPE_EDGE_C = "EDGE_C"
TYPE_FACE = "FACE"
TYPE_EMPTY = "EMPTY"
TYPE_AXIS = "AXIS"
TYPE_CURSOR = "CURSOR"

POLY_TYPE_TAPE = "TAPE"
POLY_TYPE_LINE = "LINE"
POLY_TYPE_CIR = "CIRCLE"
POLY_TYPE_RECT = "RECT"
POLY_TYPE_ARC = "ARC"

POLY_ALL_MODES = {
    POLY_TYPE_TAPE,
    POLY_TYPE_LINE,
    POLY_TYPE_CIR,
    POLY_TYPE_RECT,
    POLY_TYPE_ARC,
}

POLY_NORM_MODES = {POLY_TYPE_TAPE, POLY_TYPE_LINE, POLY_TYPE_CIR, POLY_TYPE_RECT}

TAPE_TYPE_LRC = 1
TAPE_TYPE_A = 2


# IMP_PATTERN = re.compile(r"""^(?:([0-9]+)\')?(?:([0-9]+)\x22?)?$""")


# IMP_PATTERN = re.compile(
#     """^(?:([0-9]+)\'?)?(?:([0-9]+)\x22?)?\s?(?:([0-9]+\/[0-9]+)?)?$"""
# )

IMP_PATTERN = re.compile("""^(?:([0-9]?\.?[0-9]?)\'?)?(?:(\s?[0-9]+)\x22?)?\s?(?:([0-9]+\/[0-9]+)?)?$""")

B_NUMS = [
    "ZERO",
    "ONE",
    "TWO",
    "THREE",
    "FOUR",
    "FIVE",
    "SIX",
    "SEVEN",
    "EIGHT",
    "NINE",
    "PERIOD",
]

B_NUM_OPS = [
    "NUMPAD_SLASH",
    "SLASH",
    "MINUS",
    "NUMPAD_MINUS",
    "NUMPAD_PLUS",
    "NUMPAD_ASTERIX",
    "EQUAL",
    "COMMA",
]

B_INPUT_PT = ["MIDDLEMOUSE", "TAB", "TRACKPADPAN", "TRACKPADZOOM", "MOUSEROTATE"]

B_NUMPAD_NUMS = [
    "NUMPAD_0",
    "NUMPAD_1",
    "NUMPAD_2",
    "NUMPAD_3",
    "NUMPAD_4",
    "NUMPAD_5",
    "NUMPAD_6",
    "NUMPAD_7",
    "NUMPAD_8",
    "NUMPAD_9",
]

B_ARROWS_WHEEL = ["UP_ARROW", "WHEELUPMOUSE", "DOWN_ARROW", "WHEELDOWNMOUSE"]

NUM_OPS = ["/", "*", "-", "+"]
IMP_OPS = ['"', "'", " "]
B_AKEYS = ["X", "Y", "Z"]
DEFAULT_STATUS = "Select vertex to measure from | X,Y,Z Keys to lock axis | Esc to exit"
SECOND_CLICK_STATUS = (
    "   |  Click second vertex or type value and press Enter | Esc to cancel"
)
CIRCLE_SEG_STATUS = "Segments: "
OBJ_TYPES = ["MESH", "EMPTY"]


def convert_shift_bnum(b_num):
    return {"EIGHT": "*", "EQUAL": "+"}.get(b_num, "")


def convert_bakey(b_akey):
    return {"X": 0, "Y": 1, "Z": 2}.get(b_akey, -1)


def convert_bnum(b_num):
    return {
        "ZERO": "0",
        "ONE": "1",
        "TWO": "2",
        "THREE": "3",
        "FOUR": "4",
        "FIVE": "5",
        "SIX": "6",
        "SEVEN": "7",
        "EIGHT": "8",
        "NINE": "9",
        "PERIOD": ".",
        "SLASH": "/",
        "NUMPAD_SLASH": "/",
        "MINUS": "-",
        "NUMPAD_MINUS": "-",
        "NUMPAD_PLUS": "+",
        "NUMPAD_ASTERIX": "*",
        "COMMA": ",",
    }.get(b_num, "")


def unit_scale(b_unit):
    return {
        "KILOMETERS": 1000.0,
        "METERS": 1.0,
        "CENTIMETERS": 0.01,
        "MILLIMETERS": 0.001,
        "MICROMETERS": 0.0000001,
        "MILES": 1609.34,
        "FEET": 0.3048,
        "INCHES": 0.0254,
        "THOU": 2.54e-5,
    }.get(b_unit, 1.0)


# NONE, METRIC or IMPERIAL
def return_scene_unit_sys(context):
    return context.scene.unit_settings.system


# return feet, inches, hundredths
# from input string
def parse_imp_str(str_inpt) -> (int, int):
    match = re.match(IMP_PATTERN, str_inpt)
    if match:
        return match.groups()
    return []


def parse_imp_input(inpt, context):
    parse_elms = parse_imp_str(inpt)
    units = return_b_length_unit(context)
    r_val = ""
    if parse_elms:
        if units == "FEET":
            feet = float(parse_elms[0]) if parse_elms[0] else 0
            inches = float(parse_elms[1]) if parse_elms[1] else 0
            hunds = float(eval(str(parse_elms[2]))) if parse_elms[2] else 0
            to_feet = inches + hunds

            if to_feet > 0:
                to_feet = to_feet / 12
            r_val = str(feet + to_feet)

        elif units == "INCHES":
            inches = float(parse_elms[0]) if parse_elms[0] else 0
            inches += float(parse_elms[1]) if parse_elms[1] else 0
            inches += float(eval(str(parse_elms[2]))) if parse_elms[2] else 0
            r_val = str(inches)

    return r_val


# unit scale from Blender property
def return_b_unit_scale(context):
    return context.scene.unit_settings.scale_length


def return_b_length_unit(context):
    return context.scene.unit_settings.length_unit


def highlight_col(s_type):
    return {
        TYPE_VERT: CL_HIGHLIGHT_COL_VERT,
        TYPE_EDGE_C: CL_HIGHLIGHT_COL_EDGE_C,
        TYPE_EDGE: CL_HIGHLIGHT_COL_EDGE,
        TYPE_FACE: CL_HIGHLIGHT_COL_FACE,
    }.get(s_type, CL_HIGHLIGHT_COL)


def get_axis_col(axis_lock):
    if axis_lock[0]:
        return CL_XAXIS_COL
    elif axis_lock[1]:
        return CL_YAXIS_COL
    elif axis_lock[2]:
        return CL_ZAXIS_COL

    return CL_DEFAULT_COL


def convert_loc_2d(vert, context):
    new_2dco = location_3d_to_region_2d(
        context.region, context.space_data.region_3d, vert
    )

    return new_2dco


def convert_to_cur_scale(val, context):
    unit = context.scene.unit_settings.length_unit
    return (val * (unit_scale(unit)) * return_b_unit_scale(context))
    # return val * (unit_scale(unit))


def reverse_scale(val, context):
    unit = context.scene.unit_settings.length_unit
    return round((val / (unit_scale(unit)) * return_b_unit_scale(context)), 4)
    # return round(val / unit_scale(unit), 4)


# expected range, target range, value
def map_range(a, b, n):
    (a1, a2), (b1, b2) = a, b
    return b1 + ((n - a1) * (b2 - b1) / (a2 - a1))


def cursor_loc(context):
    return [context.scene.cursor.location, TYPE_CURSOR]


def viewport_zoom_dist():
    for area in bpy.context.screen.areas:
        if area.type == "VIEW_3D":
            return area.spaces[0].region_3d.view_distance


# do any useable objects exist in the scene
def objs_exist(context):
    for obj in context.visible_objects:
        if obj.type == "MESH" or obj.type == "EMPTY":
            return True

    return False


def deselect_all_objects():
    for obj in bpy.data.objects:
        obj.select_set(False)


def return_all_CL_POINTS(context):
    clp = []
    for ob in context.scene.objects:
        if not ob:
            continue
        if ob.type == "EMPTY" and ob.name.startswith(CL_C_NAME):
            clp.append(ob)
    return clp


def solid_modifer_to_obj(obj):
    if not obj:
        return

    mod = obj.modifiers.new(name="Solidify", type="SOLIDIFY")
    mod.use_even_offset = True
    mod.use_rim = True
    # mod.show_viewport = False


def bool_modifer_to_obj(obj, bool_obj):
    if not obj:
        return

    mod = obj.modifiers.new(name="Boolean", type="BOOLEAN")
    mod.operation = "DIFFERENCE"
    mod.object = bool_obj
    # mod.show_viewport = False


def only_select(obj):
    deselect_all_objects()
    obj.select_set(True)


def setup_new_obj(name, context):
    obj_name = name
    mesh = bpy.data.meshes.new("mesh")
    obj = bpy.data.objects.new(obj_name, mesh)
    context.scene.collection.objects.link(obj)
    context.view_layer.objects.active = obj
    obj.select_set(True)
    mesh = context.object.data
    bm = bmesh.new()
    return obj, mesh, bm


def apply_transformations(obj, reset_mode):
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.transform_apply(location=True, scale=True, rotation=True)
    bpy.ops.object.mode_set(mode=reset_mode)
    obj.select_set(False)


def flag_switch(flags, f_num):
    tmp = flags[f_num]
    clear_flags(flags)
    flags[f_num] = not tmp


def clear_flags(flags):
    for i in range(len(flags)):
        flags[i] = False


def is_in_ortho_view(context):
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    if space.region_3d.is_perspective:
                        return False

    return True


def get_view_matrix(context):
    for area in context.screen.areas:
        if area.type == "VIEW_3D":
            r3d = area.spaces.active.region_3d
            return r3d.view_matrix

    return []


def get_view_orientation_from_matrix(view_matrix):
    r = lambda x: round(x, 2)
    view_rot = view_matrix.to_euler()

    orientation_dict = {
        (0.0, 0.0, 0.0): "TOP",
        (r(math.pi), 0.0, 0.0): "BOTTOM",
        (r(-math.pi / 2), 0.0, 0.0): "FRONT",
        (r(math.pi / 2), 0.0, r(-math.pi)): "BACK",
        (r(-math.pi / 2), r(math.pi / 2), 0.0): "LEFT",
        (r(-math.pi / 2), r(-math.pi / 2), 0.0): "RIGHT",
    }

    return orientation_dict.get(tuple(map(r, view_rot)), "UNDEFINED")


# remove depth dependent on ortho orientation
# base off of click location
def flatten_location_to_ortho(ort, loc, start_loc):
    n_loc = loc.copy()
    s_loc = start_loc.copy()
    if ort in {"TOP", "BOTTOM"}:
        n_loc[2] = s_loc[2]  # no Z
    elif ort in {"FRONT", "BACK"}:
        n_loc[1] = s_loc[1]  # no Y
    elif ort in {"LEFT", "RIGHT"}:
        n_loc[0] = s_loc[0]  # no X

    return n_loc.copy()


def select_closest_obj(context, x, y, cur_mode):
    if cur_mode == "EDIT":
        bpy.ops.object.mode_set(mode="OBJECT")

    # Make sure that selection won't pass through
    context.view_layer.objects.active = None
    deselect_all_objects()
    bpy.ops.view3d.select(location=(x, y), toggle=True)
    return context.selected_objects[-1] if context.selected_objects else None


def return_all_guide_geom(context):
    guides = [[], [], []]
    clps = return_all_CL_POINTS(context)
    for obj in clps:
        guide = return_guide_geom(obj)
        if not guide:
            continue
        if len(guide) > 1:
            guides[0].extend(guide[0])
            guides[1].extend(guide[1])
            guides[2].extend(guide[2])
        else:
            guides[0].extend(guide)
        # else:
        #     guides = guide
    return guides


def return_guide_geom(obj):
    g_v = return_guide_data(obj)
    if g_v:
        if len(g_v) > 1:
            g_ec = [clg.find_edge_center(g_v[0], g_v[1])]
            g_ep = [(g_v[0], g_v[1])]
            return [g_v, g_ec, g_ep]
        else:
            # return []
            return g_v
    return []


def return_guide_data(obj, only_vis=True):
    if obj:
        if obj.type == "EMPTY":
            if only_vis and not obj.visible_get():
                return []
            keys = ["StartX", "StartY", "StartZ"]
            if return_guide_keys_exist(obj, keys):
                return [
                    obj.location,
                    Vector((obj[keys[0]], obj[keys[1]], obj[keys[2]])),
                ]
            else:
                return [Vector((obj.location))]
    return []


def return_guide_keys_exist(obj, keys):
    # if hasattr(obj,'_RNA_UI'):
    if all(k in obj.keys() for k in keys):
        return True
    return False


# INFO BAR DISPLAY
def update_info_bar(context, val):
    if not context.area:
        return
    if val != "":
        context.area.header_text_set(text=val)
        # context.workspace.status_text_set(text=val)
    else:
        context.area.header_text_set(None)
        # context.workspace.status_text_set(None)

def return_scaled_dist(context, dist):
    scale = return_b_unit_scale(context)
    unit = context.scene.unit_settings.length_unit
    full_dist = dist[0] * (unit_scale(unit) * scale)
    x_dist = dist[1] * (unit_scale(unit) * scale)
    y_dist = dist[2] * (unit_scale(unit) * scale)
    z_dist = dist[3] * (unit_scale(unit) * scale)

    return [full_dist, x_dist, y_dist, z_dist]


def display_cur_tape_dist(context, dist):
    scn_system = return_scene_unit_sys(context)
    full_dist, x_dist, y_dist, z_dist = return_scaled_dist(context, dist)

    if scn_system != "NONE":
        ddist = bpy.utils.units.to_string(
            scn_system, "LENGTH", full_dist, 3, True, True
        )
        dx = bpy.utils.units.to_string(scn_system, "LENGTH", x_dist, 3, True, True)
        dy = bpy.utils.units.to_string(scn_system, "LENGTH", y_dist, 3, True, True)
        dz = bpy.utils.units.to_string(scn_system, "LENGTH", z_dist, 3, True, True)
    else:
        ddist = str(full_dist)
        dx = str(x_dist)
        dy = str(y_dist)
        dz = str(z_dist)

    update_info_bar(
        context,
        "Distance: "
        + ddist
        + "  dx: "
        + dx
        + "  dy: "
        + dy
        + "  dz: "
        + dz
        + SECOND_CLICK_STATUS,
    )


def find_CL_object(vert, type_name, context):
    for obj in context.scene.objects:
        if obj.name.startswith(type_name):
            verts = obj.data.vertices
            for v in verts:
                if v.co == vert:
                    return obj

    return None


def update_bmesh(bm):
    bm.verts.index_update()
    bm.verts.ensure_lookup_table()
    bm.edges.index_update()
    bm.edges.ensure_lookup_table()
    bm.faces.index_update()
    bm.faces.ensure_lookup_table()
    bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.001)


def update_bm_verts(bm):
    bm.verts.index_update()
    bm.verts.ensure_lookup_table()

def update_bm_edges(bm):
    bm.edges.index_update()
    bm.edges.ensure_lookup_table()

def update_bm_faces(bm):
    bm.faces.index_update()
    bm.faces.ensure_lookup_table()


# LIST OPS
def not_list(l1, l2):
    return [i for i in l1 if i not in l2]


def and_list(l1, l2):
    return [i for i in l1 if i in l2]


def val_in_list_pos(lst, val, pos):
    idxs = [x[pos] for x in lst]

    return val in idxs

def return_highest_val_item(li):
    li.sort(key=lambda x: x[1])
    return li[0][0]

# check if l1 items are in l2
def all_items_in_list(l1, l2):
    for i in l1:
        if i not in l2:
            return False
    return True

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import bpy
import gpu
import bgl
import blf

from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from . import cl_utils as utl
from . import cl_geom as clg


############################################
# OPENGL DRAWING
############################################
vertex_shader = """
        uniform mat4 u_ViewProjectionMatrix;

        in vec3 position;
        in float lineLength;

        out float v_LineLength;

        void main()
        {
            v_LineLength = lineLength;
            gl_Position = u_ViewProjectionMatrix * vec4(position, 1.0f);
        }
    """

fragment_shader = """
    uniform float u_Scale;
    uniform vec4 u_col;

    in float v_LineLength;

    void main()
    {
        if (step(sin(v_LineLength * u_Scale), 0.2) == 1) discard;
        gl_FragColor = u_col;
    }
"""

font_info = {
    "font_id": 0,
    "handler": None,
}



def batch_draw(coords, solid_line, col, context, u_scale=2, line_style="LINE_LOOP"):
    u_scale = utl.reverse_scale(u_scale, context)
    u_scale = utl.map_range((2, 2000), (20, 200), u_scale)
    if not solid_line:
        line_lengths = [0]
        for a, b in zip(coords[:-1], coords[1:]):
            line_lengths.append(line_lengths[-1] + (a - b).length)

        shader = gpu.types.GPUShader(vertex_shader, fragment_shader)
        batch = batch_for_shader(
            shader, line_style, {"position": coords, "lineLength": line_lengths}
        )

        shader.bind()
        matrix = bpy.context.region_data.perspective_matrix
        shader.uniform_float("u_ViewProjectionMatrix", matrix)
        shader.uniform_float("u_Scale", u_scale)
        shader.uniform_float("u_col", col)
    else:
        shader = gpu.shader.from_builtin("3D_UNIFORM_COLOR")
        batch = batch_for_shader(shader, line_style, {"pos": coords})
        shader.bind()
        shader.uniform_float("color", col)
    batch.draw(shader)



def draw_line_3d(col, start, end, obj_mode, context):
    coords = []
    coords.append(start)
    coords.append(end)
    batch_draw(coords, obj_mode, col, context)


def draw_poly_2d(p_verts, axis_lock, obj_mode, context, closed=True):
    col = utl.get_axis_col(axis_lock)
    coords = []
    for v in p_verts:
        vec = v[0], v[1], v[2]
        coords.append(Vector(vec))
    # add fist vert again to complete loop - if closed poly
    if closed:
        vec = p_verts[0][0], p_verts[0][1], p_verts[0][2]
        coords.append(Vector(vec))

    batch_draw(coords, obj_mode, col, context)


def draw_arc_2d(p_verts, axis_lock, obj_mode, context):
    if not p_verts:
        return
    coords = []
    for p in p_verts:
        coords.append(p)

    col = utl.get_axis_col(axis_lock)
    batch_draw(coords, obj_mode, col, context, u_scale=3, line_style="LINE_STRIP")


def draw_tape_line(verts, axis_lock, obj_mode, context):
    if verts is None:
        return
    col = axis_lock
    draw_line_3d(utl.get_axis_col(col), verts[0], verts[1], obj_mode, context)


def draw_guide_lines(guides, context):
    for g in guides:
        guide_geom = utl.return_guide_geom(g)
        if len(guide_geom) > 1:
            draw_guide_line(guide_geom[0], context)


def draw_guide_line(verts, context):
    if verts:
        if len(verts) > 1:
            draw_line_3d(utl.CL_GUIDE_COL, verts[0], verts[1], False, context)


# highlight vert or cursor point
def highlight_point(point2d, col):
    if point2d and col:
        coords = []
        coords.append(point2d)
        shader = gpu.shader.from_builtin("2D_UNIFORM_COLOR")
        batch = batch_for_shader(shader, "POINTS", {"pos": coords})
        shader.bind()
        shader.uniform_float("color", col)
        batch.draw(shader)


# def draw_text_dist(point2d, txt, col):
#     font_id = font_info["font_id"]
#     blf.position(font_id, point2d[0], point2d[1], 0)
#     blf.size(font_id, 15, 72)
#     blf.draw(font_id, txt)


# LINE Callback - draws tape line and drag box
def draw_line_callback_px(cl_op, context):
    bgl.glLineWidth(3)
    if cl_op.tape:
        if cl_op.tape.visible:
            d_pts = cl_op.tape.return_verts()
            d_pts_len = len(d_pts)
            r = clg.calc_len(d_pts)[0]

            if cl_op.poly_mode == utl.POLY_TYPE_CIR:
                draw_poly_2d(
                    clg.plot_circle(
                        r, cl_op.circle_segs, cl_op.axis_lock, cl_op.soft_axis, d_pts
                    ),
                    cl_op.axis_lock,
                    cl_op.obj_mode,
                    context,
                )
            elif cl_op.poly_mode == utl.POLY_TYPE_RECT:
                draw_poly_2d(
                    clg.plot_rect(d_pts, cl_op.axis_lock, cl_op.soft_axis),
                    cl_op.axis_lock,
                    cl_op.obj_mode,
                    context,
                )
            elif cl_op.poly_mode == utl.POLY_TYPE_ARC and d_pts_len > 2:
                if d_pts_len > 2:
                    draw_arc_2d(
                        clg.plot_arc_2(
                            d_pts,
                            cl_op.axis_lock,
                            cl_op.soft_axis,
                            cl_op.circle_segs,
                            context,
                        ),
                        cl_op.axis_lock,
                        cl_op.obj_mode,
                        context,
                    )
            else:
                obj_mode = cl_op.obj_mode
                # override obj_mode if in measure mode
                if cl_op.poly_mode == utl.POLY_TYPE_TAPE:
                    obj_mode = False

                draw_tape_line(d_pts, cl_op.axis_lock, obj_mode, context)

    # draw construction lines
    if cl_op.cl_points:
        draw_guide_lines(cl_op.cl_points, context)


# POINT Callback
def draw_callback_px(cl_op, context):
    if cl_op is not None:
        if cl_op.close_vert:
            sel_type = cl_op.close_vert[1]
            vert = utl.convert_loc_2d(cl_op.close_vert[0], context)
            highlight_point(vert, utl.highlight_col(sel_type))
        elif cl_op.mouse_pos:
            vec = []
            vec.append(cl_op.mouse_pos[0])
            vec.append(cl_op.mouse_pos[1])
            highlight_point(vec, utl.CL_DEFAULT_COL)

        if cl_op.select_verts:
            for v in cl_op.select_verts:
                v = utl.convert_loc_2d(v, context)
                highlight_point(v, utl.CL_SELECT_COL)

        # if display dist
        # shouldn't run any calculations here
        # if cl_op.tape:
        #     draw_text_dist(utl.convert_loc_2d(cl_op.tape.return_verts()[-1], context), str(utl.return_scaled_dist(context, cl_op.tape.get_tape_len())[0]), utl.CL_SELECT_COL)

        if cl_op.tape and cl_op.guide_div > 0:
            guide_divs = clg.plot_guide_pts(cl_op.tape.return_verts(), cl_op.guide_div)
            for v in guide_divs:
                v = utl.convert_loc_2d(v, context)
                highlight_point(v, utl.CL_SELECT_COL)

# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import bmesh
from . import cl_utils as utl
from . import cl_geom as clg


def vert_exists(edge, co):
    for v in edge.verts:
        if v.co == co:
            return True
    return False


def calc_edge_intersections(bm, edge):
    edges = [e for e in bm.edges if e != edge]
    edges_to_split = []
    new_edges = []
    new_edges.append([[edge.verts[0].co, edge.verts[1].co]])
    for e in edges:
        check_edges = [edge, e]
        co = clg.find_edge_edge_intersection(check_edges)
        if co:
            if clg.check_intersect_possible(check_edges):
                # check point lies on both edges
                if clg.point_on_edge(
                    co, [edge.verts[0].co, edge.verts[1].co]
                ) and clg.point_on_edge(co, [e.verts[0].co, e.verts[1].co]):
                    # original edge may need spliting
                    edges_to_split.append([edge, co.copy()])
                    edges_to_split.append([e, co.copy()])  # add other edges

    # don't return initial edge if it will be split
    if edges_to_split:
        new_edges.remove(new_edges[0])

    # Split edges and add new vert to newly created edges
    for es in edges_to_split:
        s_edge = es[0]
        co = es[1]
        if not s_edge.is_valid:
            bm.edges.remove(s_edge)
            continue
        if co:
            # p1, p2 = [globCo(v.co, obj) for v in s_edge.verts]
            p1, p2 = [v.co for v in s_edge.verts]
            if p1 == p2:
                continue
            fac = (co - p1).length / (p2 - p1).length
            # store new edge splits as edge vert tuples
            new_e = split_edge_from_verts(s_edge.verts, co)
            if not return_edges_from_verts(new_e, bm):
                new_edges.append(new_e)
                try:
                    bmesh.utils.edge_split(s_edge, s_edge.verts[0], fac)
                except:
                    print("can't split edge")
    utl.update_bmesh(bm)
    # remove_double_edges(bm.edges)
    # return list of new bmedges from stored split edges
    return return_edges_from_verts(new_edges, bm)


# returns two new edge's verts
def split_edge_from_verts(evs, split_v):
    return [[evs[0].co, split_v], [evs[1].co, split_v]]


# expects list of vert tuples [[[co,co], [co,co]], [[...]]]
def return_edges_from_verts(edge_vs, bm):
    r_edges = []
    for e in edge_vs:
        for evs in e:
            edge = bm_edge_from_verts(evs[0], evs[1], bm)
            if edge:
                r_edges.append(edge)
    return list(set(r_edges))


def bm_edge_from_verts(v1, v2, bm):
    for e in bm.edges:
        if e.verts[0].co in (v1, v2) and e.verts[1].co in (v1, v2):
            return e
    return None


############################
# SPLIT FACES
############################
def split_faces(bm, edges):
    face_split = False
    for e in edges:
        if not e.link_faces:
            for f in bm.faces:
                if e.verts[0] in f.verts and e.verts[1] in f.verts and f.index != -1:
                    try:
                        face_split = bmesh.utils.face_split(
                            f, e.verts[0], e.verts[1], use_exist=False
                        )
                    except:
                        print("can't split face")
    utl.update_bmesh(bm)
    return face_split


def split_face_plane(face_to_split, face, obj):
    try:
        bmesh.utils.face_split_edgenet(face_to_split, face.edges)
        bmesh.update_edit_mesh(obj.data)
    except:
        return False
    return True

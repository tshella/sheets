# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import bpy
import bmesh

from mathutils import Vector
from . import cl_utils as utl
from . import cl_geom as clg
from . import cl_edgeintersects as ei
from . import cl_graph as gph


class ConstructLine:
    def __init__(self, context, cl_type, verts, start_obj=None):
        self.context = context
        self._type = cl_type
        self.verts = verts.copy()
        self._start_obj = start_obj
        self.visible = True
        self._start_obj_pos = (
            start_obj.original.matrix_world.translation.copy() if start_obj else []
        )
        self._end_set = False
        self._tape_finished = False

    def return_verts(self):
        return self.verts.copy()

    def return_tape_finished(self):
        return self._tape_finished

    def set_tape_finished(self, val):
        if isinstance(val, bool):
            self._tape_finished = val

    def set_end_vert(self, new_v):
        v_c = len(self.verts)

        if v_c == 2:
            self.verts[1] = new_v.copy()
        elif v_c == 3:
            self.verts[2] = new_v.copy()

    def cancel_type3_tape(self):
        if len(self.verts) > 2:
            del self.verts[2]

        self.set_tape_finished(False)

    def set_tape_type(self, cl_type):
        if self._type == utl.TAPE_TYPE_A:
            self.cancel_type3_tape()
        self._type = cl_type

    def get_tape_type(self):
        return self._type

    def set_ctrl_vert(self, new_v):
        # control vert (mid vert in arc case)
        self.verts.append(new_v)

    def set_visible(self, vis):
        self.visible = vis

    def get_start_obj(self):
        return self._start_obj

    def get_start_obj_pos_snap(self):
        # return position of object offset at current tape/snap point
        return self._start_obj_pos - self.verts[0]

    def get_start_obj_pos(self):
        return self._start_obj_pos

    def get_tape_name(self):
        return utl.CL_C_NAME

    def get_tape_len(self):
        v_c = len(self.verts)
        v1 = self.verts[0]
        v2 = self.verts[1]

        if v_c == 3:
            v1 = clg.find_edge_center(v1, v2)
            v2 = self.verts[2]

        return clg.calc_len([v1, v2])

    def return_ctrl_axis_lock(self, axis_lock):
        if axis_lock[0] or axis_lock[1]:
            return [False, False, True]
        if axis_lock[2]:
            return [False, True, False]

    def drag_tape_end(self, loc, axis_lock, poly_mode):
        v = self.verts.copy()

        if not loc:
            return

        l = loc.copy()  # [x,y,z]

        # no effect if in circle or rect poly mode - only line or arc modes
        if (
            axis_lock is not None
            and True in axis_lock
            and poly_mode not in {utl.POLY_TYPE_RECT, utl.POLY_TYPE_CIR}
        ):

            n_v = Vector(v[0])
            if axis_lock[0]:
                n_v.x = l[0]
            if axis_lock[1]:
                n_v.y = l[1]
            if axis_lock[2]:
                n_v.z = l[2]
        else:
            n_v = Vector(l)

        self.set_end_vert(n_v.copy())

    # get tape current delta
    # extend by val in direction
    def extend_tape_by_amnt(self, amnt):
        v_c = len(self.verts)
        verts = self.verts.copy()
        v1 = verts[0]
        v2 = verts[1]
        c = clg.find_edge_center(v1, v2)

        # convert amnt to current scale
        amnt = utl.convert_to_cur_scale(amnt, self.context)

        if v_c == 2:
            v_dir = v2 - v1
            v_dir.normalize()
            v2 = v1 + v_dir * amnt
            self.verts[1] = v2
        elif v_c == 3:
            v3 = verts[2]
            v_dir = v3 - c
            v_dir.normalize()
            v3 = c + v_dir * amnt
            self.verts[2] = v3

    # set tape_finished when enough increments for each type
    # type 1 = line, rect, circle = 2 increments
    # type 2 = arc = 3 increments
    def finish_tape(self):
        v_c = len(self.verts)
        if self._type == utl.TAPE_TYPE_LRC and v_c == 2:
            self._tape_finished = True
        elif self._type == utl.TAPE_TYPE_A:
            if v_c == 2:
                # add ctrl point at mid point
                self.set_ctrl_vert(clg.find_edge_center(self.verts[0], self.verts[1]))
            elif v_c == 3:
                self._tape_finished = True

    # adds final construction points or line obj based on obj_mode
    # construction points will include start and end along with any divisions
    def add_final_end(self, divs, create_obj, working_obj):
        verts = self.verts
        if not create_obj:
            # pass in segments/divisions (clg.plot_guide_pts)
            guide_pts = self.return_verts()
            guide_pts.extend(clg.plot_guide_pts(guide_pts, divs))
            self.create_construction_points(guide_pts, verts[0].copy())
            return None
        else:
            return self.create_line(verts, working_obj)

    # adds circle/rect construction points or circle/rect obj based on obj_mode
    def add_poly_points(self, verts, create_obj, working_obj, name, create_face=True):
        # if not create_obj:
        #     for v in verts:
        #         self.create_construction_point(v, utl.CL_C_POINTNAME)
        # else:
        return self.create_poly(verts, name, working_obj, create_face)

    # adds a named construction point at location
    # add new custom property with start point
    def create_construction_points(self, pts, loc_start=None):
        name = utl.CL_C_POINTNAME + " "
        dist = "({0},{1},{2})".format(pts[0][0], pts[0][1], pts[0][2])
        for i, gp in enumerate(pts):
            if i > 0:
                dist = str(
                    utl.reverse_scale(clg.calc_len([pts[0], gp])[0], self.context)
                )
            obj = bpy.data.objects.new(name + dist, None)
            self.add_to_collection(obj)
            obj.empty_display_size = utl.CL_CP_SCALE
            obj.empty_display_type = "PLAIN_AXES"
            obj.location = gp
            if loc_start and gp == pts[1]:
                obj["StartX"] = loc_start[0]
                obj["StartY"] = loc_start[1]
                obj["StartZ"] = loc_start[2]

    #################################
    # CREATE AND EXTEND BLENDER OBJECTS
    #################################
    # POLY
    def create_poly(self, verts, name, working_obj, create_face):
        # obj = self.context.active_object
        obj = working_obj
        add_exist = False
        if obj and bpy.context.mode == "EDIT_MESH":
            verts = clg.verts_to_vect3(verts)
            for i, v in enumerate(verts):
                new_edge = []
                if i < len(verts) - 1:
                    new_edge = [verts[i], verts[i + 1]]
                else:
                    # allow for closed geometry final edge
                    if create_face:
                        new_edge = [verts[i], verts[0]]
                # free on final vert
                add_exist = not self.add_to_existing_mesh(
                    obj,
                    new_edge,
                    False if i < len(verts) - 1 else True,
                    construct_plane=verts,
                )
                # toggle mode to update
                bpy.ops.object.mode_set(mode="OBJECT")
                bpy.ops.object.mode_set(mode="EDIT")
        else:
            obj, mesh, bm = utl.setup_new_obj(name, self.context)
            for v in verts:
                bm.verts.new(v)
            utl.update_bm_verts(bm)
            if create_face:
                bm.faces.new(bm.verts)
            else:
                for i in range(len(bm.verts) - 1):
                    bm.edges.new((bm.verts[i], bm.verts[i + 1]))
                    utl.update_bm_edges(bm)

            bm.to_mesh(mesh)
            bm.free()
            # make sure origin is set to center of new geometry
            bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
        return obj if add_exist else None

    # LINE
    # if in object mode, create a new line
    # else if in edit mode add to mesh and attempt to create faces
    def create_line(self, verts, working_obj):
        obj = working_obj
        add_exist = False

        if obj is not None and bpy.context.mode == "EDIT_MESH":
            # continue line until face has been created or split
            add_exist = not self.add_to_existing_mesh(obj, verts, True)
            # reset mode to update
            bpy.ops.object.mode_set(mode="OBJECT")
        else:
            obj, mesh, bm = utl.setup_new_obj(utl.CL_C_LINENAME, self.context)
            for v in verts:
                bm.verts.new(v)
            utl.update_bm_verts(bm)
            bm.edges.new(bm.verts)
            utl.update_bm_edges(bm)
            bm.to_mesh(mesh)
            bm.free()
            add_exist = True

        utl.only_select(obj)
        # keep/put in edit mode for continuous lines
        bpy.ops.object.mode_set(mode="EDIT")
        return obj if add_exist else None

    # add verts to existing mesh
    # if mesh cycles exist, create face
    # Current Obj, Verts to add, Free Obj as finished, Construct on a particular plane/face (Vector[verts])
    def add_to_existing_mesh(self, obj, verts, free_obj, construct_plane=None):
        mtrx = obj.matrix_world.inverted().copy()
        verts = [mtrx @ v for v in verts]
        face_added_split = False
        if construct_plane:
            construct_plane = [mtrx @ v for v in construct_plane]

        if bpy.context.mode == "EDIT_MESH":
            bm = bmesh.from_edit_mesh(obj.data)
        else:
            return False

        nv = []
        for v in verts:
            nv.append(bm.verts.new(v))
            utl.update_bm_verts(bm)
        if nv:
            new_edge = bm.edges.new((nv[0], nv[1]))
            utl.update_bm_edges(bm)
            utl.update_bm_faces(bm)
            # attempt to find construct_plane def
            if not construct_plane:
                construct_plane = self.return_face_edit_verts(bm, nv)
            # Query mesh for edge intersections
            new_edges = ei.calc_edge_intersections(bm, new_edge)
            # Split any faces if needed
            face_added_split = ei.split_faces(bm, new_edges)
            bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.001)
            # Find cycles
            new_face = self.find_faces(bm, construct_plane)
            if new_face:
                face_added_split = True
                face_hits = []
                for f in bm.faces:
                    # the face with the most hits will be the working face
                    if f is not new_face:
                        hits = clg.all_points_on_face(f, new_face)
                        if hits > 0:
                            face_hits.append([f, hits])
                
                if face_hits:
                    hit_face = utl.return_highest_val_item(face_hits)
                    # match face normals
                    if new_face.normal != hit_face.normal:
                        new_face.normal_flip()
                    if ei.split_face_plane(hit_face, new_face, obj):
                        bm.faces.remove(new_face)
                        utl.update_bm_faces(bm)

        if bpy.context.mode == "EDIT_MESH":
            bm.normal_update()
            bmesh.update_edit_mesh(obj.data)

        obj.data.update()
        if free_obj:
            bm.free()

        return face_added_split

    # return list of wire edges and list of wire edges and edge links
    def return_wire_edges_and_links(self, bm):
        w_edges = [e for e in bm.edges if e.is_wire]
        v_edges = []
        edges_and_links = []
        for e in w_edges:
            for v in e.verts:
                # get link_edges of wire_edges
                for le in v.link_edges:
                    if not le.is_wire:
                        v_edges.append(le)
        edges_and_links = w_edges.copy()
        for e in v_edges:
            if e not in w_edges:
                edges_and_links.append(e)
        return w_edges, edges_and_links

    # Cycles
    def find_faces(self, bm, construct_plane=None):
        w_edges, e_and_l = self.return_wire_edges_and_links(bm)
        if not w_edges:
            return []
        mg = gph.mesh_graph(e_and_l, construct_plane)
        new_face = None
        cycles = mg.return_cycles([w_edges[0].verts[0], w_edges[0].verts[1]])
        if cycles:
            for c in cycles:
                if not self.face_exists(bm.faces, c):
                    nf = bm.faces.new(c)
                    nf.normal_update()
                    utl.update_bm_faces(bm)
                    new_face = nf
                    break
        del mg
        return new_face

    def return_any_edge_in_edges(self, edges1, edges2):
        for e in edges1:
            if e in edges2:
                return True
        return False

    def return_edges_from_verts(self, bm, verts):
        edges = []
        for i, v in enumerate(verts):
            if i < len(verts) - 1:
                for e in bm.edges:
                    if v in e.verts and verts[i + 1] in e.verts:
                        edges.append(e)
        return edges

    def face_exists(self, bm_faces, new_face_vs):
        for f in bm_faces:
            # if lengths don't match can't be an existing face
            if len(f.verts) == len(new_face_vs):
                # check existing face against new_vs not the other way
                if utl.all_items_in_list(f.verts, new_face_vs):
                    return True
        return False

    def return_face_edit_verts(self, bm, bm_verts):
        for f in bm.faces:
            if bm_verts in f.verts:
                return [v.co for v in f.verts]
        return None

    # COLLECTION ACCESS
    def add_to_collection(self, obj):
        CL_collection = None

        if utl.CL_COL_NAME in bpy.data.collections:
            CL_collection = bpy.data.collections[utl.CL_COL_NAME]
        else:
            CL_collection = bpy.data.collections.new(
                name=utl.CL_COL_NAME
            )  # create new one
            bpy.context.scene.collection.children.link(CL_collection)
            CL_collection.hide_render = True

        if CL_collection is not None:
            CL_collection.objects.link(obj)

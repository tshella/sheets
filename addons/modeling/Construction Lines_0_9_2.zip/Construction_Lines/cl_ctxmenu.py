# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import os
import bpy

from bpy.props import StringProperty
from . import cl_utils as utl

ICONS = "M_LIN O_LIN O_RCT O_CIR O_ARC CL_VIS CL_SCL CL_DEL CL_MOV CL_FAC".split(" ")
icon_collection = {}


class VIEW_OT_CLMenuAction(bpy.types.Operator):
    bl_idname = "wm.cl_menu_action"
    bl_label = "CL Menu Action"
    act_val: StringProperty()

    def execute(self, context):
        bpy.context.scene.cl_settings.cl_menuact_str = self.act_val
        return {"FINISHED"}


class CL_CTX_Menu(bpy.types.Menu):
    bl_label = "Construction Lines"
    bl_idname = "OBJECT_MT_cl_menu"

    def draw(self, context):
        prev_coll = icon_collection["main"]

        def get_icon(name):
            return prev_coll[name].icon_id

        layout = self.layout
        layout.operator(
            "wm.cl_menu_action",
            text="Tape              T",
            icon_value=get_icon("M_LIN"),
        ).act_val = utl.ACTION_DRAWTAPE
        layout.separator()
        layout.operator(
            "wm.cl_menu_action",
            text="Line              L",
            icon_value=get_icon("O_LIN"),
        ).act_val = utl.ACTION_DRAWLINE
        layout.operator(
            "wm.cl_menu_action",
            text="Rectangle    R",
            icon_value=get_icon("O_RCT"),
        ).act_val = utl.ACTION_DRAWRECT
        layout.operator(
            "wm.cl_menu_action",
            text="Circle           C",
            icon_value=get_icon("O_CIR")
        ).act_val = utl.ACTION_DRAWCIRCLE
        layout.operator(
            "wm.cl_menu_action",
            text="2 Point Arc   U",
            icon_value=get_icon("O_ARC")
        ).act_val = utl.ACTION_DRAWARC
        layout.separator()
        layout.operator(
            "wm.cl_menu_action",
            text="Move               G/M",
            icon_value=get_icon("CL_MOV")
        ).act_val = utl.ACTION_MOVE
        layout.separator()
        layout.operator(
            "wm.cl_menu_action",
            text="Create Face         F",
            icon_value=get_icon("CL_FAC")
        ).act_val = utl.ACTION_FACE
        layout.separator()
        layout.operator(
            "wm.cl_menu_action",
            text="Hide/Show All      H",
            icon_value=get_icon("CL_VIS")
        ).act_val = utl.ACTION_HIDESHOW
        layout.operator(
            "wm.cl_menu_action",
            text="Scale All             S",
            icon_value=get_icon("CL_SCL")
        ).act_val = utl.ACTION_SCALE_CLS
        layout.operator(
            "wm.cl_menu_action",
            text="Remove All         DEL",
            icon_value=get_icon("CL_DEL")
        ).act_val = utl.ACTION_REMOVEALL
        layout.separator()
        layout.operator(
            "wm.cl_menu_action",
            text="Exit             ESC",
            icon='X'
        ).act_val = utl.ACTION_EXITCANCEL


def draw_item(self, context):
    layout = self.layout
    layout.menu(CL_CTX_Menu.bl_idname)


def register_icons():
    import bpy.utils.previews

    prev_coll = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    for icon_name in ICONS:
        prev_coll.load(icon_name, os.path.join(icons_dir, icon_name + ".png"), "IMAGE")
    icon_collection["main"] = prev_coll


def unregister_icons():
    for prev_coll in icon_collection.values():
        bpy.utils.previews.remove(prev_coll)
    icon_collection.clear()

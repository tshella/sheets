# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import bpy
from bpy.props import BoolProperty, StringProperty

import bmesh

from mathutils import Vector
from bpy_extras.view3d_utils import region_2d_to_location_3d, region_2d_to_vector_3d

from . import cl_utils as utl
from . import cl_geom as clg
from . import cl_drawing as drw
from . import cl_snapto as snp
from . import cl_ctxmenu as cm
from . import cl_clobject as cl

CL_NAME = __name__.split(".")[0]


def tape_finish(cl_op):
    cl_op.tape_dist = cl_op.tape.get_tape_len()
    cl_op.tape.finish_tape()
    # make sure axis_lock is off (wil affect arcs)
    # reset_axis_lock(cl_op, -1)
    return True if cl_op.tape.return_tape_finished() else False


def cancel_tape(cl_op, context):
    if cl_op.state == utl.CL_STATE_MV:
        move_geom(cl_op, True)
    reset_operator(cl_op, context)


def reset_axis_lock(cl_op, xyz):
    if xyz > -1:
        lock = cl_op.axis_lock[xyz]
        lock = not lock  # switch axis lock
    cl_op.axis_lock = [False, False, False]
    if xyz > -1:
        cl_op.axis_lock[xyz] = lock


def set_pref_colours(context):
    prefs = context.preferences.addons[CL_NAME].preferences
    utl.CL_GUIDE_COL = prefs.cl_guide_col


def show_hide_cls():
    if utl.CL_COL_NAME in bpy.data.collections:
        CL_collection = bpy.data.collections[utl.CL_COL_NAME]
        CL_collection.hide_viewport = not CL_collection.hide_viewport


def remove_all_cls(cl_op, context):
    e_mode = False
    # store mode if in edit mode
    if bpy.context.mode == "EDIT_MESH":
        e_mode = True
        bpy.ops.object.mode_set(mode="OBJECT")

    for o in bpy.data.objects:
        o.select_set(False)

    for ob in context.scene.objects:
        ob.select_set(ob.type == "EMPTY" and ob.name.startswith(utl.CL_C_NAME))
        deselect_vert(cl_op, ob.location)
        bpy.ops.object.delete()

    # reset to edit mode if was in edit
    if e_mode:
        bpy.ops.object.mode_set(mode="EDIT")

    refresh_all_cls(cl_op, context)


# scale between %50 and %100
def scale_all_cls(context):
    zoom = utl.viewport_zoom_dist()
    scale = utl.map_range((0, 10), (0.5, 1), zoom)
    v_Scale = Vector((scale, scale, scale))
    clps = utl.return_all_CL_POINTS(context)
    for clp in clps:
        clp.scale = v_Scale


def refresh_all_cls(cl_op, context):
    cl_op.cl_points = utl.return_all_CL_POINTS(context)


############################################
# SELECT AND CREATE FACES
############################################
def select_vert(cl_op, add_vert):
    for v in cl_op.select_verts:
        if v == add_vert:
            cl_op.select_verts.remove(v)
            return

    cl_op.select_verts.append(add_vert)


def select_verts(cl_op, context, s_all):
    cl_op.select_verts = []

    if s_all:
        return

    for ob in context.scene.objects:
        if ob.name.startswith(utl.CL_C_NAME):
            select_vert(cl_op, ob.location)


def deselect_vert(cl_op, loc):
    for v in cl_op.select_verts:
        if v == loc:
            cl_op.select_verts.remove(v)


def query_selections(cl_op, context):
    exists = False
    cl_list = []
    rem_v = []

    for ob in context.scene.objects:
        if ob.name.startswith(utl.CL_C_NAME):
            cl_list.append(ob.location)

    for v in cl_op.select_verts:
        for c_l in cl_list:
            if v == c_l:
                exists = True

        if not exists:
            rem_v.append(v)

    for v in rem_v:
        cl_op.select_verts.remove(v)


def create_face(context, verts):
    # Create face between selected verts
    # If less than 3 points then create edge
    if verts == [] or len(verts) < 2:
        return

    # Create object and add mesh
    msh_name = utl.CL_NEW_NAME + "_Mesh"
    obj_name = utl.CL_NEW_NAME
    bm = bmesh.new()
    for v in verts:
        bm.verts.new(v)

    bm.verts.ensure_lookup_table()

    if len(verts) < 3:
        bm.edges.new((bm.verts[0], bm.verts[1]))
    else:
        bm.faces.new(bm.verts)

    bm.normal_update()
    me = bpy.data.meshes.new(msh_name)
    bm.to_mesh(me)
    # add bmesh to scene
    obj = bpy.data.objects.new(obj_name, me)
    context.scene.collection.objects.link(obj)
    bpy.ops.ed.undo_push()


#############################################
def new_construction_line(cl_op, context, start_point=None):
    s_pt = start_point
    if not s_pt:
        s_pt = cl_op.close_vert[0].copy()

    cl_op.tape = cl.ConstructLine(
        context,
        utl.TAPE_TYPE_A if cl_op.poly_mode == utl.POLY_TYPE_ARC else utl.TAPE_TYPE_LRC,
        [s_pt, s_pt],
        cl_op.snap_obj,
    )
    cl_op.cur_tape_name = cl_op.tape.get_tape_name()
    cl_op.close_vert = []


def create_poly(cl_op, context, p_type):
    tape_vs = cl_op.tape.return_verts()
    p_verts = []

    if p_type == utl.CL_C_CIRCLENAME:
        p_verts = clg.plot_circle(
            clg.calc_len(tape_vs)[0],
            cl_op.circle_segs,
            cl_op.axis_lock,
            cl_op.soft_axis,
            tape_vs,
        )
    elif p_type == utl.CL_C_RECTNAME:
        p_verts = clg.plot_rect(tape_vs, cl_op.axis_lock, cl_op.soft_axis)
    elif p_type == utl.CL_C_ARCNAME:
        p_verts = clg.plot_arc_2(
            tape_vs, cl_op.axis_lock, cl_op.soft_axis, cl_op.circle_segs, context
        )

    obj = cl_op.tape.add_poly_points(
        p_verts,
        cl_op.obj_mode,
        cl_op.snap_obj,
        p_type,
        False if p_type == utl.CL_C_ARCNAME else True,
    )

    if obj:
        cl_op.snap_obj = obj


def change_circle_segs(cl_op, context, num):
    min_segs = 3
    if cl_op.poly_mode == utl.POLY_TYPE_ARC:
        min_segs = 2

    cl_op.circle_segs += num
    if cl_op.circle_segs < min_segs:
        cl_op.circle_segs = min_segs
    utl.update_info_bar(context, utl.CIRCLE_SEG_STATUS + str(cl_op.circle_segs))


def change_guide_divisions(cl_op, num):
    min_divs = 0
    cl_op.guide_div += num
    if cl_op.guide_div < min_divs:
        cl_op.guide_div = min_divs


def create_line_axis_point(cl_op, context):
    obj_mode = cl_op.obj_mode
    # override obj_mode if in measure mode
    if cl_op.poly_mode == utl.POLY_TYPE_TAPE:
        obj_mode = False

    obj = cl_op.tape.add_final_end(
        cl_op.guide_div,
        obj_mode,
        context.active_object,
    )

    if obj:
        cl_op.snap_obj = obj
        new_construction_line(cl_op, context, cl_op.tape.return_verts()[1])
        return False
    refresh_all_cls(cl_op, context)
    return True


def change_mode(cl_op, mode):
    if mode not in utl.POLY_ALL_MODES:
        return

    cl_op.poly_mode = mode

    if mode in utl.POLY_NORM_MODES:
        change_type(cl_op, utl.TAPE_TYPE_LRC)
    else:
        change_type(cl_op, utl.TAPE_TYPE_A)

    cl_op.u_num = ""  # reset on change


def change_type(cl_op, cl_type):
    if cl_op.tape:
        cl_op.tape.set_tape_type(cl_type)


# MOVE
def move_geom(cl_op, cancel=False):
    obj = cl_op.tape.get_start_obj()
    if obj:
        if cancel:
            # cancel will set back to original position
            obj.original.matrix_world.translation = cl_op.tape.get_start_obj_pos()
            return

        s_pos = cl_op.tape.get_start_obj_pos_snap()

        # curent position
        c_pos = cl_op.tape.return_verts()[1]
        obj.matrix_world.translation = s_pos + c_pos


#############################################
# INPUT
############################################
def toggle_state(cl_op, state, context):
    # always return to normal tape
    if cl_op.state in {utl.CL_STATE_MV, utl.CL_STATE_EX}:
        if cl_op.tape:
            cl_op.tape.set_visible(True)
            cancel_tape(cl_op, context)
        cl_op.state = utl.CL_STATE_MC
        return

    if state == utl.CL_STATE_EX and bpy.context.mode != "EDIT_MESH":
        return

    cl_op.state = state
    if cl_op.tape:
        cl_op.tape.set_visible(False)


def handle_arrows_wheel(cl_op, context, key, ctrl):
    if key == utl.B_ARROWS_WHEEL[0] or (key == utl.B_ARROWS_WHEEL[1] and ctrl):
        if cl_op.poly_mode in {utl.POLY_TYPE_CIR, utl.POLY_TYPE_ARC}:
            change_circle_segs(cl_op, context, 1)
        elif cl_op.poly_mode == utl.POLY_TYPE_TAPE:
            change_guide_divisions(cl_op, 1)
    elif key == utl.B_ARROWS_WHEEL[2] or (key == utl.B_ARROWS_WHEEL[3] and ctrl):
        if cl_op.poly_mode in {utl.POLY_TYPE_CIR, utl.POLY_TYPE_ARC}:
            change_circle_segs(cl_op, context, -1)
        elif cl_op.poly_mode == utl.POLY_TYPE_TAPE:
            change_guide_divisions(cl_op, -1)


def handle_num_input(cl_op, context, val, rmve, shift):
    if rmve:
        cl_op.u_num = cl_op.u_num[:-1]
    else:
        if val in utl.IMP_OPS:
            n_val = val
        else:
            n_val = utl.convert_bnum(val)
            if shift:
                n_val = utl.convert_shift_bnum(val)
        # only allow commas in rect mode
        if n_val == "," and cl_op.poly_mode != utl.POLY_TYPE_RECT:
            return
        cl_op.u_num = cl_op.u_num + n_val
    utl.update_info_bar(context, cl_op.u_num)


def handle_num_input_end(cl_op, context):
    inpt = cl_op.u_num
    if inpt != "":
        inpt_split = inpt.split(",")
        parsed_inpt = [inpt]
        if utl.return_scene_unit_sys(context) == "IMPERIAL":
            parsed_inpt = []
            for s in inpt_split:
                parsed_inpt.append(utl.parse_imp_input(s, context))
        if cl_op.poly_mode == utl.POLY_TYPE_RECT:
            if len(parsed_inpt) < 2:
                parsed_inpt = parsed_inpt[0].split(",")
            s_w = utl.convert_to_cur_scale(float(parsed_inpt[0]), context)
            s_h = s_w  # same as width unless comma input
            if len(parsed_inpt) > 1:
                s_h = utl.convert_to_cur_scale(float(parsed_inpt[1]), context)
            # change what axis is used to define size - base on axis lock
            s_w, s_h = clg.convert_amnt_by_direction_vec(
                cl_op.tape.return_verts(), cl_op.axis_lock, s_w, s_h
            )
            rect2 = clg.plot_rect_dims(s_w, s_h)  # new rect

            # rotate based on axis lock
            if cl_op.axis_lock[0]:
                clg.rotate_x_mtrx(rect2)
            elif cl_op.axis_lock[1]:
                clg.rotate_y_mtrx(rect2)

            # translate to position
            clg.translate_pos(cl_op.tape.return_verts()[0], rect2)
            cl_op.tape.set_end_vert(rect2[2])
        else:
            if parsed_inpt[0]:
                dist = clg.parse_dist(clg.calc_len(cl_op.tape.return_verts()), parsed_inpt[0], context)
                cl_op.tape.extend_tape_by_amnt(dist)
        end_input(cl_op, context)
    cl_op.u_num = ""
    utl.update_info_bar(context, cl_op.u_num)


# def handle_mode_change():
# bpy.ops.wm.tool_set_by_id(name=utl.CL_TOOL_NAME)


# Left click event
# If ctrl pressed select and store points
# else create tape
def handle_mouse_click(cl_op, context, ctrl):
    if ctrl:
        # maintain a list of selected points
        if cl_op.close_vert:
            if cl_op.close_vert[0]:
                select_vert(cl_op, cl_op.close_vert[0].copy())
        return

    if cl_op.tape:
        # set end tape point
        if cl_op.tape.return_tape_finished() is False:
            if not cl_op.close_vert or True in cl_op.axis_lock:
                cl_op.tape.drag_tape_end([], None, cl_op.poly_mode)
            else:
                cl_op.tape.drag_tape_end(
                    cl_op.close_vert[0].copy(), None, cl_op.poly_mode
                )
            end_input(cl_op, context)
    else:
        if cl_op.close_vert:
            new_construction_line(cl_op, context)
            if cl_op.state in {utl.CL_STATE_MV, utl.CL_STATE_EX}:
                cl_op.tape.set_visible(False)
        else:
            mouse_pos = return_mouse_loc(cl_op, context)
            if utl.is_in_ortho_view(context):
                mouse_pos = utl.flatten_location_to_ortho(
                    utl.get_view_orientation_from_matrix(utl.get_view_matrix(context)),
                    mouse_pos,
                    Vector((0, 0, 0)),
                )
            cl_op.close_vert = [mouse_pos, utl.TYPE_CURSOR]
            new_construction_line(cl_op, context)


# Try to finish tape
# if tape_finish returns false then return and continue
# user input
def end_input(cl_op, context):
    if tape_finish(cl_op):
        clean_up = True
        # check for state - point, circle, rect, arc
        if cl_op.state == utl.CL_STATE_MC:
            if cl_op.poly_mode == utl.POLY_TYPE_CIR:
                create_poly(cl_op, context, utl.CL_C_CIRCLENAME)
            elif cl_op.poly_mode == utl.POLY_TYPE_RECT:
                create_poly(cl_op, context, utl.CL_C_RECTNAME)
            elif cl_op.poly_mode == utl.POLY_TYPE_ARC:
                create_poly(cl_op, context, utl.CL_C_ARCNAME)
            else:
                clean_up = create_line_axis_point(cl_op, context)
        else:
            move_geom(cl_op)
        cl_op.dirty_flag = True
        bpy.ops.ed.undo_push()
        if clean_up:
            reset_operator(cl_op, context)
    else:
        # make sure axis_lock is off (wil affect arcs)
        reset_axis_lock(cl_op, -1)


# Mouse move event
def handle_mouse_move(cl_op, event, context):
    mouse_pos = return_mouse_loc(cl_op, context)
    if not event.alt:
        snp.snap(cl_op, context, cl_op.mouse_pos)
        if cl_op.tape:
            sv = cl_op.tape.return_verts()[0]
        else:
            sv = None
        try:
            cl_op.close_vert, cl_op.close_face, close_face_loc = snp.pr2d(
                context,
                [event.mouse_region_x, event.mouse_region_y],
                cl_op.dirty_flag,
                cl_op.vert_cache,
                utl.cursor_loc(context).copy(),
                cl_op.snap_obj,
                cl_op.snap_geom,
                cl_op.focus_obj,
            )

            cl_op.dirty_flag = False
            cl_op.snap_geom = []
        except:
            print("Invalid Snap Target")
            return

        # soft axis lock and stay on face
        if not cl_op.close_vert:
            if close_face_loc:
                cl_op.close_vert = close_face_loc
            elif sv:
                cl_op.close_vert, cl_op.soft_axis = snp.return_soft_axis(
                    sv, mouse_pos, context
                )

    if cl_op.tape:
        if not cl_op.tape.return_tape_finished():
            if utl.is_in_ortho_view(context):
                t_vs = cl_op.tape.return_verts()
                tape_start = t_vs[0]
                mouse_pos = utl.flatten_location_to_ortho(
                    utl.get_view_orientation_from_matrix(utl.get_view_matrix(context)),
                    mouse_pos,
                    tape_start,
                )
            cl_op.tape.drag_tape_end(mouse_pos, cl_op.axis_lock, cl_op.poly_mode)
            if cl_op.close_vert:
                cl_op.tape.drag_tape_end(
                    cl_op.close_vert[0], cl_op.axis_lock, cl_op.poly_mode
                )

            if cl_op.state == utl.CL_STATE_MV:
                move_geom(cl_op)
            utl.display_cur_tape_dist(context, cl_op.tape.get_tape_len())


def handle_menu_action(cl_op, context, m_act):
    if m_act == utl.ACTION_HIDESHOW:
        show_hide_cls()
    elif m_act == utl.ACTION_REMOVEALL:
        remove_all_cls(cl_op, context)
    elif m_act == utl.ACTION_DRAWTAPE:
        change_mode(cl_op, utl.POLY_TYPE_TAPE)
    elif m_act == utl.ACTION_DRAWLINE:
        change_mode(cl_op, utl.POLY_TYPE_LINE)
    elif m_act == utl.ACTION_DRAWCIRCLE:
        change_mode(cl_op, utl.POLY_TYPE_CIR)
    elif m_act == utl.ACTION_DRAWRECT:
        change_mode(cl_op, utl.POLY_TYPE_RECT)
    elif m_act == utl.ACTION_DRAWARC:
        change_mode(cl_op, utl.POLY_TYPE_ARC)
    elif m_act == utl.ACTION_MOVE:
        toggle_state(cl_op, utl.CL_STATE_MV, context)
    elif m_act == utl.ACTION_FACE:
        create_face(context, cl_op.select_verts)
    elif m_act == utl.ACTION_SCALE_CLS:
        scale_all_cls(context)
    elif m_act == utl.ACTION_EXITCANCEL:
        cl_op.isRunning = False

    bpy.context.scene.cl_settings.cl_menuact_str = ""


#############################################
def return_mouse_loc(cl_op, context):
    coord = cl_op.mouse_pos
    region = context.region

    if context.space_data:
        rv3d = context.space_data.region_3d
        vec = region_2d_to_vector_3d(region, rv3d, coord)
        loc = region_2d_to_location_3d(region, rv3d, coord, vec)
        return loc.copy()

    return []


def reset_operator(cl_op, context):
    reset_axis_lock(cl_op, -1)
    cl_op.cur_tape_name = ""
    cl_op.close_vert = []
    cl_op.close_face = -1
    cl_op.snap_geom = []
    cl_op.focus_obj = None
    cl_op.etrude_obj = None
    cl_op.guide_div = utl.CL_DEFAULT_GUIDE_DIVISIONS
    cl_op.tape_dist = []
    cl_op.state = utl.CL_STATE_MC
    refresh_all_cls(cl_op, context)
    # cl_op.poly_mode = [True, False, False, False]
    if cl_op.tape:
        del cl_op.tape
        cl_op.tape = None

    set_pref_colours(context)
    query_selections(cl_op, context)
    utl.update_info_bar(context, utl.DEFAULT_STATUS)


def cancel_operater(cl_op, context):
    if cl_op.tape is not None:
        del cl_op.tape
        cl_op.tape = None
    utl.update_info_bar(context, "")
    if cl_op._handle:
        bpy.types.SpaceView3D.draw_handler_remove(cl_op._handle, "WINDOW")
        cl_op._handle = None
    if cl_op._handle_line:
        bpy.types.SpaceView3D.draw_handler_remove(cl_op._handle_line, "WINDOW")
        cl_op._handle_line = None
    context.window.cursor_modal_restore()
    context.scene.cl_settings.cl_running_bool = False
    # Return to select tool
    return_to_select_tool()

    return {"CANCELLED"}


def return_to_select_tool():
    bpy.ops.wm.tool_set_by_id(name="builtin.select_box")


def process_undo_action(cl_op, context):
    bpy.ops.ed.undo()
    refresh_op_values(cl_op, context)


def refresh_op_values(cl_op, context):
    # clear snap_obj as may no longer exist
    cl_op.snap_obj = None
    cl_op.focus_obj = None
    cl_op.dirty_flag = True
    refresh_all_cls(cl_op, context)
    context.view_layer.update()


#############################################
# MAIN OPERATOR CODE
############################################
class VIEW_OT_ConstructionLines(bpy.types.Operator):
    """Measure distances, build construction guides, draw lines and build primitive shapes in place."""

    bl_idname = "view3d.construction_lines"
    bl_label = "Construction Lines"
    bl_options = {"REGISTER", "UNDO", "GRAB_CURSOR"}

    @classmethod
    def poll(cls, context):
        return context.area.type == "VIEW_3D"

    def modal(self, context, event):
        if context.area:
            context.area.tag_redraw()

        if not self.isRunning:
            return cancel_operater(self, context)

        # handle any menu actions
        self.obj_mode = context.scene.cl_settings.cl_objmode_bool
        if context.scene.cl_settings.cl_menuact_str != "":
            handle_menu_action(
                self, context, bpy.context.scene.cl_settings.cl_menuact_str
            )
        if event.type in utl.B_INPUT_PT or event.type in utl.B_NUMPAD_NUMS:
            self.dirty_flag = True
            self.close_vert = []
            return {"PASS_THROUGH"}
        if event.type == "MOUSEMOVE":
            self.mouse_pos = [event.mouse_region_x, event.mouse_region_y, 0]
            handle_mouse_move(self, event, context)
            return {"PASS_THROUGH"}
        if event.value == "PRESS":
            if event.type == "LEFTMOUSE":
                # make sure tape is not in use
                if not self.tape and not self.close_vert:
                    if clg.point_in_region(self.mouse_pos, "TOOLS", context):
                        self.isRunning = False
                        return {"PASS_THROUGH"}
            elif event.type in utl.B_ARROWS_WHEEL:
                handle_arrows_wheel(self, context, event.type, event.ctrl)
                if event.type in {utl.B_ARROWS_WHEEL[1], utl.B_ARROWS_WHEEL[3]}:
                    return {"PASS_THROUGH"}
            elif event.unicode in utl.IMP_OPS:
                handle_num_input(
                    self, context, event.unicode, False, event.shift
                )
        if event.value == "RELEASE":
            if event.type == "LEFTMOUSE":
                handle_mouse_click(self, context, event.ctrl)
            elif event.type in utl.B_AKEYS and not event.ctrl:  # AXIS LOCK
                reset_axis_lock(self, utl.convert_bakey(event.type))
            elif (
                event.type in utl.B_NUMS
                or event.type in utl.B_NUM_OPS
                or event.type == "BACK_SPACE"
            ):  # NUM/NUM EXPR INPUT
                handle_num_input(
                    self, context, event.type, event.type == "BACK_SPACE", event.shift
                )
            elif event.type == "RET":  # END NUMBER INPUT
                handle_num_input_end(self, context)
            elif event.type == "Z" and event.ctrl:
                process_undo_action(self, context)
            elif event.type == "F":
                create_face(context, self.select_verts)
            elif event.type == "T":
                change_mode(self, utl.POLY_TYPE_TAPE)
            elif event.type == "L":
                change_mode(self, utl.POLY_TYPE_LINE)
            elif event.type == "C":
                change_mode(self, utl.POLY_TYPE_CIR)
            elif event.type == "R":
                change_mode(self, utl.POLY_TYPE_RECT)
            elif event.type == "U":
                change_mode(self, utl.POLY_TYPE_ARC)
            elif event.type == "A":
                if not event.shift:
                    select_verts(self, context, event.alt)
            elif event.type == "H":
                show_hide_cls()
            elif event.type in {"G", "M"}:
                toggle_state(self, utl.CL_STATE_MV, context)
            elif event.type == "DEL":
                remove_all_cls(self, context)
                self.select_verts = []
        if event.type == "ESC" and event.value == "PRESS":
            if self.tape is not None:
                cancel_tape(self, context)
            else:
                return cancel_operater(self, context)
        if event.type == "RIGHTMOUSE":
            bpy.ops.wm.call_menu(name=cm.CL_CTX_Menu.bl_idname)
        return {"RUNNING_MODAL"}

    def __init__(self):
        self.u_num = ""
        self.u_dist = 0.0
        self.close_vert = []
        self.soft_axis = -1
        self.close_face = -1
        self.select_verts = []
        self.mouse_pos = []
        self.tape = None
        self.tape_dist = []
        self.display_text = ""
        self.axis_lock = [False, False, False]
        self.cur_tape_name = ""
        self.cl_points = []
        self.dirty_flag = True
        self.snap_obj = None
        self.snap_geom = []
        self.focus_obj = None
        self.etrude_obj = None
        self.vert_cache = snp.VertCache([])
        self.obj_mode = None
        self.poly_mode = utl.POLY_TYPE_TAPE
        self.circle_segs = utl.CL_DEFAULT_CIR_SEGS
        self.guide_div = utl.CL_DEFAULT_GUIDE_DIVISIONS
        self.state = utl.CL_STATE_MC
        self.isRunning = True

    def invoke(self, context, event):
        # Check if instance of op already running
        if context.scene.cl_settings.cl_running_bool:
            return {"CANCELLED"}

        if (
            context.space_data.type == "VIEW_3D"
            and not context.space_data.region_quadviews
        ):
            args = (self, context)
            self._handle_line = bpy.types.SpaceView3D.draw_handler_add(
                drw.draw_line_callback_px, args, "WINDOW", "POST_VIEW"
            )
            self._handle = bpy.types.SpaceView3D.draw_handler_add(
                drw.draw_callback_px, args, "WINDOW", "POST_PIXEL"
            )
            wm = context.window_manager
            wm.modal_handler_add(self)
            reset_operator(self, context)

            if context.mode == "EDIT_MESH":
                self.snap_obj = context.active_object

            context.scene.cl_settings.cl_running_bool = True
            bpy.ops.wm.tool_set_by_id(name=utl.CL_TOOL_NAME)
            return {"RUNNING_MODAL"}
        else:
            self.report({"WARNING"}, "Active space must be View3d and not Quad View")
            context.scene.cl_settings.cl_running_bool = False
            return {"CANCELLED"}


#############################################
# PROPERTIES
############################################
class CLSettings(bpy.types.PropertyGroup):
    cl_objmode_bool: BoolProperty(
        name="", description="Object/Measure Mode", default=True
    )

    cl_running_bool: BoolProperty(
        name="PROP_CL_Running", description="Operator is running", default=False
    )

    cl_menuact_str: StringProperty(name="", description="Menu Action", default="")

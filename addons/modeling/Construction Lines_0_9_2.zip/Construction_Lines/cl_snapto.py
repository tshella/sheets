# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import bpy

from bpy_extras import view3d_utils
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils import Vector
from mathutils.geometry import intersect_point_line as PointLineIntersect
from . import cl_utils as utl
from . import cl_geom as clg

# import time
############################################
# CLOSEST VERTEX
############################################
def pr2d(
    context, loc, dirty_flag, vert_cache, cursor_loc, snap_obj, snap_geom, focus_obj
):
    # get the context arguments
    region = context.region
    rv3d = context.region_data
    coord = loc[0], loc[1]
    # exclude_obj = exclude_name

    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_target = ray_origin + view_vector

    def find_closest_face(obj):
        fail_state = None, None, None

        if not obj:
            return fail_state
        try:
            if obj.type != "MESH":
                return fail_state
        except ReferenceError:
            return fail_state

        emode = context.mode == "EDIT_MESH"
        if emode:
            bpy.ops.object.mode_set(mode="OBJECT")

        if focus_obj:
            obj = focus_obj
            obj.select_set(True)

        matrix = obj.matrix_world.copy()
        # get the ray relative to the object
        matrix_inv = matrix.inverted()
        ray_origin_obj = matrix_inv @ ray_origin
        ray_target_obj = matrix_inv @ ray_target
        ray_direction_obj = ray_target_obj - ray_origin_obj

        # cast the ray
        success, location, normal, face_index = obj.ray_cast(
            ray_origin_obj, ray_direction_obj
        )

        if focus_obj:
            obj.select_set(False)

        if emode:
            return_to_snap_edit(snap_obj)

        if success:
            location = matrix @ location
            return face_index, [location, utl.TYPE_FACE], normal
        else:
            return fail_state

    def project_2d(locs):
        if not snap_geom:
            return
        try:
            for v in snap_geom[0]:
                loc2d = location_3d_to_region_2d(region, rv3d, v)
                if loc2d:
                    locs.append([loc2d, v, utl.TYPE_VERT])
            if len(snap_geom) > 1:
                for v in snap_geom[1]:
                    loc2d = location_3d_to_region_2d(region, rv3d, v)
                    if loc2d:
                        locs.append([loc2d, v, utl.TYPE_EDGE_C])
            if len(snap_geom) > 2:
                for e in snap_geom[2]:
                    v1_loc2d = location_3d_to_region_2d(region, rv3d, e[0])
                    v2_loc2d = location_3d_to_region_2d(region, rv3d, e[1])
                    locs.append([[v1_loc2d, v2_loc2d], [e[0], e[1]], utl.TYPE_EDGE])
        except:
            print("Not a valid vert")

    def project_cursor_loc(c_loc):
        try:
            loc2d = location_3d_to_region_2d(region, rv3d, c_loc[0])
            if loc2d:
                return [loc2d, c_loc[0], c_loc[1]]
        except:
            return []
        return []

    def find_closest(verts_cache):
        closest = []
        verts_2d = verts_cache.return_vertsa()
        best_dist = utl.CL_BEST_DIST  # / utl.viewport_zoom_dist(context)
        for v in verts_2d:
            if not v:
                continue
            if v[2] is not utl.TYPE_EDGE:
                dx = v[0][0] - coord[0]
                dy = v[0][1] - coord[1]
                dist = (dx) ** 2 + (dy) ** 2
                if dist < best_dist:
                    best_dist = dist
                    closest = [v[1], v[2]]  # return real location and type
        best_dist = utl.CL_BEST_E_DIST  # / utl.viewport_zoom_dist(context)

        # If no closest vert or edge center, try edge intersect
        if not closest:
            for e in verts_2d:
                if e:
                    if e[2] == utl.TYPE_EDGE:
                        pt0 = e[0][0]
                        pt1 = e[0][1]
                        x, y = PointLineIntersect(coord, pt0, pt1)
                        if y > 1 or y < 0:
                            continue
                        dist = (Vector(coord) - x).length
                        if dist < best_dist:
                            best_dist = dist
                            # get real location
                            r_p0 = e[1][0]
                            r_p1 = e[1][1]
                            v1 = r_p1 - r_p0
                            r_loc = Vector(
                                [getattr(r_p0, i) + y * getattr(v1, i) for i in "xyz"]
                            )
                            closest = [r_loc, e[2]]
        return closest

    # IN
    # cache result and pass in a dirty flag, only project_2d if dirty_flag is True
    if dirty_flag:
        locs = []
        locs.append(project_cursor_loc(cursor_loc))
        if snap_geom:
            project_2d(locs)
        vert_cache.update_cache(locs)
    closest = find_closest(vert_cache)
    closest_face, face_loc, face_norm = find_closest_face(snap_obj)
    if closest_face and closest:
        closest = compare_pts_to_camera(ray_origin, [face_loc, closest])
    return closest.copy(), closest_face, face_loc


# ray_origin, [face_loc, closest]
def compare_pts_to_camera(camera_loc, locs):
    d1 = clg.calc_sq_len(camera_loc, locs[0][0])
    d2 = clg.calc_sq_len(camera_loc, locs[1][0])
    if d1 + utl.CL_FACE_SNAP_SENSITIVITY < d2:
        return []
    return locs[1]


# storage is [[x,y,z],Vector(x,y,z)]
# 2d location, 3d location vector
class VertCache:
    def __init__(self, verts_a):
        self.verts_a = verts_a
        # self.edges = edges

    def return_vertsa(self):
        if self.verts_a != []:
            return self.verts_a.copy()

        return []

    def update_cache(self, verts_a):
        self.verts_a = verts_a.copy()

    def clear_cache(self):
        self.verts_a = []


############################################
# OBJECT SNAP
############################################
# Faster to use built in ops than ray casting against all objects
def snap(cl_op, context, loc):
    if cl_op.close_vert:
        if cl_op.close_vert[1] is not utl.TYPE_FACE:
            return

    emode = context.mode == "EDIT_MESH"

    s_obj = utl.select_closest_obj(
        context, loc[0], loc[1], "EDIT" if emode else "OBJECT"
    )

    geom = []

    if s_obj is not None:
        if s_obj.type == "MESH":
            geom = clg.select_vis_geom(s_obj, loc, context)
        else:
            try:
                s_obj.select_set(False)
                s_obj = cl_op.snap_obj if cl_op.snap_obj else None
                context.view_layer.objects.active = s_obj
            except ReferenceError:
                s_obj = None
        cl_op.dirty_flag = True
        if s_obj:
            s_obj.select_set(False)

        if cl_op.snap_obj is not s_obj:
            cl_op.focus_obj = s_obj
            # only switch object if emode is false
            if not emode:
                cl_op.snap_obj = s_obj

        if not s_obj:
            cl_op.focus_obj = None

    # add all guides to snap geometry
    guides = utl.return_all_guide_geom(context)
    if guides:
        if geom:
            geom[0].extend(guides[0])
            geom[1].extend(guides[1])
            geom[2].extend(guides[2])
        else:
            geom = guides
    cl_op.snap_geom = geom

    if emode:
        return_to_snap_edit(cl_op.snap_obj)


def return_to_snap_edit(snap_obj):
    if snap_obj:
        utl.deselect_all_objects()
        snap_obj.select_set(True)
        bpy.context.view_layer.objects.active = snap_obj
        bpy.ops.object.mode_set(mode="EDIT")
        snap_obj.select_set(False)


############################################
# CLOSEST AXIS SNAP
############################################
# return closest axis for a soft axis lock
def return_soft_axis(v1, loc, context):
    nv, ax = clg.find_closest_axis(v1, loc, context)
    if ax > -1:
        return [nv.copy(), utl.TYPE_AXIS], ax
    return [], -1

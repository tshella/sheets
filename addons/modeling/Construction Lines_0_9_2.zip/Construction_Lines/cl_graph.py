# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

from . import cl_utils as utl
from . import cl_geom as clg

#############################################
# NODE
#############################################
class mesh_node:
    def __init__(self, n_id):
        self.n_id = n_id
        self.connections = []
        self.visited = False
        self.bm_vert = None
        self.connection_store = []

    def store_connections(self):
        if self.connections:
            self.connection_store = self.connections.copy()
            self.connections = []

    def reset_connections(self):
        if self.connection_store:
            self.connections = self.connection_store.copy()
            self.connection_store = []


#############################################
# GRAPH
#############################################
class mesh_graph:
    def __init__(self, edges, limit_plane):
        self.nodes = []
        self.cycles_plane = None
        if limit_plane:
            if len(limit_plane) > 2:
                self.cycles_plane = limit_plane
        self.build_nodes(edges)

    def build_nodes(self, edges):
        for e in edges:
            # loc1 = clg.round_vect_4(e.verts[0].co)
            # loc2 = clg.round_vect_4(e.verts[1].co)
            loc2 = e.verts[1].co
            loc1 = e.verts[0].co
            # limit to points coplanar to cycles plane
            if self.cycles_plane:
                plane_pts = self.cycles_plane
                if not clg.points_coplanar(
                    plane_pts[0], plane_pts[1], plane_pts[2], loc1
                ) or not clg.points_coplanar(
                    plane_pts[0], plane_pts[1], plane_pts[2], loc2
                ):
                    continue
            if loc1 or loc2:
                self.add_node(loc1, loc2, e.verts[0])
                self.add_node(loc2, loc1, e.verts[1])

    # Loop all nodes, if a node has an id the same as another's connection
    # add other id to connections
    def add_node(self, n_id, vert, bm_v):
        exists = False
        for n in self.nodes:
            if n.n_id == n_id:
                n.connections.append(vert.copy())
                exists = True
        if exists:
            return
        m = mesh_node(n_id.copy())
        m.bm_vert = bm_v
        m.connections.append(vert.copy())
        self.nodes.append(m)

    def return_node_by_id(self, n_id):
        for n in self.nodes:
            if n.n_id == n_id:
                return n

    def return_node_by_bmv(self, bm_v):
        for n in self.nodes:
            if n.bm_vert == bm_v:
                return n

    def return_bm_nodes_uniq(self, cycle):
        bm_nodes = [n.bm_vert for n in cycle]
        u_list = []
        for n in bm_nodes:
            if n not in u_list:
                u_list.append(n)
        return u_list

    def remove_nodes(self, rem_list):
        for rv in rem_list:
            for v in self.nodes:
                if v == rv:
                    self.nodes.remove(v)

    # Remove any node that only connects to one other edge
    # re-check node list to see if more singles have been created after removal
    def remove_singles(self):
        rem = True
        while rem:
            rem = False
            rl = []
            for n in self.nodes:
                if len(n.connections) < 2:
                    rl.append(n)
                    rem = True

            for r in rl:
                self.remove_connection_all_nodes(r.n_id)
                self.nodes.remove(r)

    # remove a particular connection from all nodes
    def remove_connection_all_nodes(self, con):
        # change this to go through the nodes connections rather than all nodes
        for n in self.nodes:
            if con in n.connections:
                n.connections.remove(con)

    # remove any nodes from cycle not connected outside of current cycle
    # or only connected to another cycle
    def remove_unconnected(self, cycle):
        rem = []
        for n in cycle:
            if self.connections_only_in_cycle(n, cycle):
                rem.append(n)

        # remove from all node's connections
        for r in rem:
            self.remove_connection_all_nodes(r.n_id)
            if r in self.nodes:
                self.nodes.remove(r)

    # check if nodes connects are only in cycle - not to external nodes
    def connections_only_in_cycle(self, node, cycle):
        for c in node.connections:
            n = self.return_node_by_id(c)
            if n not in cycle:
                return False

        return True

    def connects_only_in_cycles(self, node, cycles):
        for c in node.connections:
            n = self.return_node_by_id(c)
            # not in any cycle
            if self.node_in_any_cycle(n, cycles) is False:
                return False
        return True

    # node is connected to any cycle
    def node_in_any_cycle(self, node, cycles):
        for c in cycles:
            if node in c:
                return True
        return False

    def reset_nodes(self):
        for n in self.nodes:
            n.visited = False
            n.reset_connections()

    def return_bmesh_verts(self, cycles):
        bm_cycle = []
        for c in cycles:
            bm_cycle.append(self.return_bm_nodes_uniq(c))
        return bm_cycle

    # try to return to home
    # new_edge is vert tuple ([vert],[vert])
    def return_cycles(self, new_edge):
        rtn_cycles = []
        # self.remove_singles()
        if self.nodes:
            # try from either end of edge
            for i in range(2):
                n1 = self.return_node_by_bmv(new_edge[0] if i == 0 else new_edge[1])
                n2 = self.return_node_by_bmv(new_edge[1] if i == 0 else new_edge[0])
                if n1 is None or n2 is None:
                    break
                n1.store_connections()
                n1.connections.append(n2.n_id)
                cycles = self.find_cycles(n1)
                if cycles:
                    # limit returned cycles
                    if len(cycles) > 5:
                        cycles = cycles[:5]
                rtn_cycles.extend(cycles)
                self.reset_nodes()
            if rtn_cycles:
                return self.return_bmesh_verts(rtn_cycles)
        return []

    def find_cycles(self, home):
        cycles = []
        cycle = []
        self.find_home(home, home, cycle, cycles, None, 0)
        if cycles:
            return self.order_cycles_by_shortest(cycles)
        return []

    # recursive function to find path home
    def find_home(self, node, home, cycle, cycles, prev_node, depth):
        node.visited = True
        coplanar = True
        cycle.append(node)
        # depth += 1

        # if depth > utl.CL_GRAPH_MAX_DEPTH:
        #     cycle.pop()
        #     return

        if len(cycle) > 3:
            if self.cycles_plane:
                coplanar = clg.points_coplanar(
                    cycle[0].n_id, cycle[1].n_id, cycle[2].n_id, node.n_id
                )

        if coplanar:
            for c in node.connections:
                n = self.return_node_by_id(c)
                if not n:
                    continue
                if not n.visited:
                    self.find_home(n, home, cycle, cycles, node, depth)
                elif n == home and n != prev_node:
                    cycles.append(cycle[:])

        if cycle:
            cycle[-1].visited = False
            cycle.pop()

    def get_shortest_cycle(self, cycles):
        c_list = []
        for c in cycles:
            c_list.append([c, self.calc_cycle_dist(c)])
        return self.sort_node_list(c_list)

    def order_cycles_by_shortest(self, cycles):
        c_list = []
        for c in cycles:
            c_list.append([c, self.calc_cycle_dist(c)])
        return self.sort_cycles_list(c_list)

    def calc_cycle_dist(self, cycle):
        dist = 10000000
        for i, c in enumerate(cycle):
            if i < len(cycle) - 1:
                dist += clg.calc_sq_len(c.n_id, cycle[i + 1].n_id)
        dist += clg.calc_sq_len(cycle[-1].n_id, cycle[0].n_id)
        return dist

    # loop through nodes and find node which is closest steering and distance to start node
    # return ordered list
    def get_shortest_path_node(self, node, home):
        c_list = []
        for c in node.connections:
            cn = self.return_node_by_id(c)
            if cn:
                d = clg.calc_sq_len(home.n_id, cn.n_id)
                c_list.append((c, d))
            else:
                print("problem with node connections")

        c_list = self.sort_node_list(c_list)
        return c_list

    # sort list based on sort value [i][1]
    # return first list without sort value [0][0]
    @staticmethod
    def sort_node_list(li):
        li.sort(key=lambda x: x[1])
        return li[0][0]

    # sort list based on sort value [i][1]
    @staticmethod
    def sort_cycles_list(li):
        # sort by shortest cycle
        li.sort(key=lambda x: x[1])
        return [l[0] for l in li]

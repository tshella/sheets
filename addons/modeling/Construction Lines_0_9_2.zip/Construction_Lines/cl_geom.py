# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####


# Project Name:         Construction Lines
# License:              GPL
# Authors:              Daniel Norris, DN Drawings

import math
import bpy
import bmesh

from mathutils import Vector, Euler
from mathutils.geometry import intersect_line_line as LineIntersect
from mathutils.geometry import intersect_point_line as PointLineIntersect
from . import cl_utils as utl


def find_edge_center(pt1, pt2):
    mx = (pt1.x + pt2.x) / 2
    my = (pt1.y + pt2.y) / 2
    mz = (pt1.z + pt2.z) / 2
    v = Vector((mx, my, mz))
    return v


# return closest with edge type
def point_on_edge_type(pt, edges):
    best_dist = utl.CL_BEST_E_DIST
    closest = []

    for e in edges:
        a, b = e[0], e[1]
        x, y = PointLineIntersect(pt, a, b)

        if y > 1:
            continue
        dist = (pt - x).length

        if dist < best_dist:
            best_dist = dist
            closest = [x, utl.TYPE_EDGE_C]

    return closest


# returns whether point lies on edge
def point_on_edge(pt, edge):
    p, _percent = PointLineIntersect(pt, *edge)
    on_line = (pt - p).length < 1.0e-5
    return on_line and (0.0 <= _percent <= 1.001)


def find_edge_edge_intersection(edges):
    p1, p2 = [v.co for v in edges[0].verts]
    p3, p4 = [v.co for v in edges[1].verts]
    l_is = LineIntersect(p1, p2, p3, p4)

    if not l_is:
        return None

    return (l_is[0] + l_is[1]) / 2


def check_intersect_possible(edges):
    if get_edges_share_verts(edges):
        return False
    return True


def get_edges_share_verts(edges):
    e = edges[0]
    for v1 in e.verts:
        for v2 in edges[1].verts:
            if v1.co == v2.co:
                return True

    return False


def point_dist_to_plane(pts, plane):
    x1 = pts[0]
    y1 = pts[1]
    z1 = pts[2]
    a = plane[0]
    b = plane[1]
    c = plane[2]
    d = plane[3]

    d = abs((a * x1 + b * y1 + c * z1 + d))
    e = math.sqrt(a * a + b * b + c * c)
    # Perpendicular dist
    return d / e


# requires vector3, vector3
def return_direction_vector(v1, v2):
    dx = v2[0] - v1[0]
    dy = v2[1] - v1[1]
    dz = v2[2] - v1[2]

    return Vector([dx, dy, dz])


# will return face with edges hit count
# when check face edges inside face
def all_points_on_face(ex_face, chk_face):
    # only need to query first edge
    chk_edge = chk_face.edges[0]
    result = []
    hits = 0
    for e in ex_face.edges:
        co = find_edge_edge_intersection([chk_edge, e])
        if co:
            # check if co lies on existing edge
            if point_on_edge(co, [e.verts[0].co, e.verts[1].co]):
                a = chk_edge.verts[0].co.normalized()
                b = co.normalized()
                if not utl.val_in_list_pos(result, co, 2):
                    result.append(
                        [chk_edge, return_direction_vector(a, b).normalized(), co]
                    )

    # check direction
    if len(result) > 1:
        for i in range(len(result) - 1):
            v1 = result[i][1]
            v2 = result[i + 1][1]
            # check if result directions are opposite
            d = v1.dot(v2)
            if d <= 0:
                hits += 1
    return hits


def edges_on_face(bm, chk_edges):
    # only need to query first edge
    chk_edge = chk_edges[0]
    result = []

    for f in bm.faces:
        fvs = [v.co for v in f.verts]
        if chk_edge.verts[0].co in fvs and chk_edge.verts[1].co in fvs:
            return f

        for e in f.edges:
            co = find_edge_edge_intersection([chk_edge, e])
            if co:
                # check if co lies on existing edge
                if point_on_edge(co, [e.verts[0].co, e.verts[1].co]):
                    a = chk_edge.verts[0].co.normalized()
                    b = co.normalized()
                    if not utl.val_in_list_pos(result, co, 2):
                        result.append(
                            [chk_edge, return_direction_vector(a, b).normalized(), co]
                        )

        # check direction
        if len(result) > 1:
            for i in range(len(result) - 1):
                v1 = result[i][1]
                v2 = result[i + 1][1]
                # check if result directions are opposite
                d = v1.dot(v2)
                # if any results are in same direction then must be outside
                if d > 0:
                    continue
            return f

        return []


def point_in_bounds(p, x_max, x_min, y_max, y_min, z_max, z_min):
    x = abs(p.x)
    y = abs(p.y)
    z = abs(p.z)
    return (
        x <= x_max
        and x >= x_min
        and y <= y_max
        and y >= y_min
        and z <= z_max
        and z >= z_min
    )


def point_in_bounds_2d(p, x, y, w, h):
    px = p[0]
    py = p[1]

    return px >= x and px <= x + w and py >= y and py <= y + h


def point_in_region(p, region_name, context):
    r_exists = False
    for r in context.area.regions:
        if r.type == region_name:
            bw, bh, bx, by = r.width, r.height, r.x, r.y
            r_exists = True
    if r_exists:
        return point_in_bounds_2d(p, bx, by, bw, bh)
    return False


# plot guide points based on num divsions
# takes [start, end]
# i = len(divs) n = divs-i
# (n/divs) * x1 + (i/divs) + x2
def plot_guide_pts(pts, divs):
    if divs <= 1:
        return []

    new_pts = []
    pt1 = pts[0]
    pt2 = pts[1]

    for i in range(1, divs):
        n = divs - i
        dx = (n / divs) * pt1.x + i / divs * pt2.x
        dy = (n / divs) * pt1.y + i / divs * pt2.y
        dz = (n / divs) * pt1.z + i / divs * pt2.z
        new_pts.append(Vector((dx, dy, dz)))
    return new_pts


# takes drag points and returns rect verts
def plot_rect(pts, axis_lock, soft_axis):
    if True not in axis_lock:
        n_pts = plot_rect_pts_3d(pts[0], pts[1])
        if n_pts:
            return n_pts

    if axis_lock[0]:  # z,x
        w = pts[1][0] - pts[0][0]
        h = pts[1][2] - pts[0][2]
    elif axis_lock[1]:  # z,-y
        w = pts[0][2] - pts[1][2]
        h = (pts[0][1] - pts[1][1]) * -1
    else:  # x,y
        w = pts[1][0] - pts[0][0]
        h = pts[1][1] - pts[0][1]

    verts = plot_rect_dims(w, h)
    verts = rotate_translate(axis_lock, soft_axis, pts[0], verts)

    return verts


def plot_rect_dims(w, h):
    # anti-clockwise
    verts = []
    verts.append([0, 0, 0])
    verts.append([w, 0, 0])
    verts.append([w, h, 0])
    verts.append([0, h, 0])

    return verts


def plot_rect_pts_3d(pt1, pt2):
    pt1 = round_vect_4(pt1)
    pt2 = round_vect_4(pt2)
    dx = pt1[0] - pt2[0]
    dy = pt1[1] - pt2[1]
    dz = pt1[2] - pt2[2]

    a = [pt1[0], pt1[1], pt1[2]]
    b = [pt1[0], pt1[1], pt1[2]]
    c = [pt2[0], pt2[1], pt2[2]]
    d = [pt2[0], pt2[1], pt2[2]]

    if 0 not in (dx, dy, dz):
        return []

    if dx == 0:  # no change on x
        b = [pt1[0], pt2[1], pt1[2]]
        d = [pt1[0], pt1[1], pt2[2]]
    elif dy == 0:  # no change on y
        b = [pt2[0], pt1[1], pt1[2]]
        d = [pt1[0], pt1[1], pt2[2]]
    elif dz == 0:  # no change on z
        b = [pt1[0], pt2[1], pt1[2]]
        d = [pt2[0], pt1[1], pt1[2]]

    return [a, b, c, d]


def convert_amnt_by_direction_vec(dir_verts, axis_lock, w, h):
    dx = dir_verts[1][0] - dir_verts[0][0]
    dy = dir_verts[1][1] - dir_verts[0][1]
    dz = dir_verts[1][2] - dir_verts[0][2]

    if axis_lock[0]:  # x,z
        if dx < 0:
            w = w * -1
        if dz < 0:
            h = h * -1
    elif axis_lock[1]:  # z,-y
        if dy < 0:
            h = h * -1
        if dz > 0:
            w = w * -1
    else:  # x,y
        if dx < 0:
            w = w * -1
        if dy < 0:
            h = h * -1
    return w, h


# takes radius and num segments and verts circle verts
def plot_circle(rad, segs, axis_lock, soft_axis, pts):
    theta = 2 * math.pi / segs
    dx = 0
    dy = 0
    dz = 0
    verts = []
    for i in range(segs):
        dx = rad * math.sin(theta * i)
        dy = rad * math.cos(theta * i)
        verts.append([dx, dy, dz])

    verts = rotate_translate(axis_lock, soft_axis, pts[0], verts, True)

    return verts


def find_closest_axis(v1, loc, context):
    l = loc.copy()

    if isinstance(v1, Vector):
        tol = utl.CL_CLOSE_AXIS_TOL

        if utl.is_in_ortho_view(context):
            l = utl.flatten_location_to_ortho(
                utl.get_view_orientation_from_matrix(utl.get_view_matrix(context)),
                l,
                v1,
            )
            tol = utl.CL_CLOSE_AXIS_TOL_O

        v_dir = l - v1
        v_dir.normalize()
        x = abs(v_dir.x)
        y = abs(v_dir.y)
        z = abs(v_dir.z)
        ax = []

        if x > y and x > z:
            ax = [0, x]
        elif y > x and y > z:
            ax = [1, y]
        elif z > x and z > y:
            ax = [2, z]

        # zoom = viewport_zoom_dist()
        if ax:
            if ax[1] > tol:
                nv = Vector(v1)
                axis = ax[0]
                if axis == 0:
                    nv[0] = l[0]
                elif axis == 1:
                    nv[1] = l[1]
                elif axis == 2:
                    nv[2] = l[2]

                return nv.copy(), axis

    return [], -1


def plot_arc_2(pts, axis_lock, soft_axis, segs, context):
    st = pts[0]
    md = pts[2]
    ed = pts[1]

    cm = find_edge_center(st, ed)

    # SET AXIS
    nv, ax = find_closest_axis(st, ed, context)

    if st[1] < ed[1] or st[2] < ed[2]:
        st_n = ed.copy()
        ed_n = st.copy()
        st = st_n.copy()
        ed = ed_n.copy()

    if ax == 1:  # on y axis = z or x
        if soft_axis == 2 or axis_lock[2]:
            h = cm[2] - md[2]
        else:
            h = md[0] - cm[0]
    elif ax == 2:  # z axis = y or x
        if soft_axis == 1 or axis_lock[1]:
            h = cm[1] - md[1]
        else:
            h = cm[0] - md[0]
    else:  # on x axis = z or y
        if soft_axis == 2 or axis_lock[2]:
            h = md[2] - cm[2]
        else:
            h = md[1] - cm[1]

    w = abs(calc_len([ed, st])[0])
    m = [w / 2, 0]

    verts = plot_2_point_arc(m, w, h, segs)

    # rotate
    t = vector_angle([st, ed])
    eul = Euler((t[0], t[1], t[2]), "XYZ")
    for v in verts:
        v.rotate(eul)

    # find out what axis start and end are on
    # then calc which axis is used for bulge
    # rotate to bulge direction
    if ax == 0:
        if soft_axis == 2 or axis_lock[2]:
            rotate_x_mtrx(verts)
    elif ax == 1:
        if soft_axis == 2 or axis_lock[2]:
            rotate_y_mtrx(verts)
    elif ax == 2:
        rotate_y_mtrx(verts)
        if soft_axis == 1 or axis_lock[1]:
            eul = Euler((0, 0, math.pi / 2), "XYZ")
            for v in verts:
                v.rotate(eul)

    translate_pos(st, verts)

    return round_vects_4(verts)


def plot_2_point_arc(m, w, h, segs):
    neg = False

    if h < 0:
        neg = True

    if h == 0:
        return [Vector([0, 0, 0]), Vector([w / 2, 0, 0]), Vector([w, 0, 0])]

    h = abs(h)
    # pts
    pt1 = [m[0] - w / 2, 0]  # chord start
    pt2 = [m[0] + w / 2, 0]  # chord end
    pt3 = [m[0], m[1] + h]

    # calc dimensions (mid pt between pt1 & pt2,
    # chord, height, radius, dist from chord to circle center)
    c = calc_len_2D([pt1, pt2])[0]  # pt2[0] - pt1[0]
    r = (h / 2) + ((c * c) / (8 * h))
    d = r - h
    if h > c / 2:
        d = r - (2 * r - h)
    # circle center
    mx = pt3[0]
    my = pt3[1] - r

    # start and end angles
    et = math.atan2(pt2[1] - my, pt2[0] - mx)
    # 180 degrees from et
    st = math.pi - et

    if neg:
        et -= math.pi
        st -= math.pi

    step = (st - et) / segs
    # start forward 1 step as appending start point vector
    i = st - step
    j = 360
    verts = []

    if not neg:
        verts.append(Vector([pt1[0], pt1[1], 0]))
    else:
        verts.append(Vector([pt2[0], pt2[1], 0]))

    # -theta to theta
    while i > et:
        dx = round(mx + math.cos(i) * r, 4)
        dy = round(my + math.sin(i) * r, 4)
        if neg:
            # fixes issues when bulge gets shallower
            if h < w / 2:
                dy += d * 2
            else:
                dy -= d * 2
        verts.append(Vector([dx, dy, 0]))
        i -= step

        # failsafe
        if j <= 0:
            break
        j -= 1

    if dx != pt2[0] and dy != pt2[1] and not neg:
        verts.append(Vector([pt2[0], pt2[1], 0]))
    elif dx != pt1[0] and dy != pt1[1] and neg:
        verts.append(Vector([pt1[0], pt1[1], 0]))

    if neg:
        verts.reverse()

    return verts


def vector_angle(pts):
    p1 = Vector(pts[0])
    p2 = Vector(pts[1])

    dx = p2[0] - p1[0]
    dy = p2[1] - p1[1]
    dz = p2[2] - p1[2]

    tz = math.atan2(dy, dx)
    ty = 0.0
    tx = 0.0
    # ty = math.atan2(dx, dz)
    tx = math.atan2(dz, dx)

    return [tx, ty, tz]


def angle_between_vects(v1, v2):
    a = v1.normalized()
    b = v2.normalized()

    n = a.dot(b)  # a[0]*b[0] + a[1]*b[1] + a[2]*b[2]
    d = math.sqrt(a[0] ** 2 + a[1] ** 2 + a[2] ** 2) * math.sqrt(
        b[0] ** 2 + b[1] ** 2 + b[2] ** 2
    )

    cos_t = 0
    if n != 0 and d != 0:
        cos_t = n / d

    return cos_t


def translate_pos(v1, mtrx):
    for v in mtrx:
        v[0] += v1[0]
        v[1] += v1[1]
        v[2] += v1[2]


# translate and rotate points - only when axis locked
# or if geom not built at origin
def rotate_translate(axis_lock, soft_axis, v1, verts, override_trans=False):
    if axis_lock[0] or soft_axis == 0:
        rotate_x_mtrx(verts)
    elif axis_lock[1] or soft_axis == 1:
        rotate_y_mtrx(verts)

    if v1:
        if override_trans or verts[0] == [0, 0, 0]:
            translate_pos(v1, verts)
    return verts


def rotate_x_mtrx(mtrx):
    t = math.pi / 2
    c = math.cos(t)
    s = math.sin(t)

    for v in mtrx:
        x = v[0]
        y = v[1]
        z = v[2]

        dx = x + 0 + 0
        dy = 0 + y * c - z * s
        dz = 0 + y * s + z * c

        v[0] = dx
        v[1] = dy
        v[2] = dz


def rotate_y_mtrx(mtrx):
    t = math.pi / 2
    c = math.cos(t)
    s = math.sin(t)

    for v in mtrx:
        x = v[0]
        y = v[1]
        z = v[2]

        dx = x * c + 0 + z * s
        dy = 0 + y + 0
        dz = x * -s + 0 + z * c

        v[0] = dx
        v[1] = dy
        v[2] = dz


# point 4 is always the point to check
# points are 3d [x,y,z]
def points_coplanar(p1, p2, p3, p4):
    a1 = p2[0] - p1[0]
    b1 = p2[1] - p1[1]
    c1 = p2[2] - p1[2]

    a2 = p3[0] - p1[0]
    b2 = p3[1] - p1[1]
    c2 = p3[2] - p1[2]

    a = b1 * c2 - b2 * c1
    b = a2 * c1 - a1 * c2
    c = a1 * b2 - b1 * a2
    d = -a * p1[0] - b * p1[1] - c * p1[2]

    # equation of plane: a*p1x + b*p1y + c*p1z = 0
    # checking if the 4th point satisfies equation
    p = a * p4[0] + b * p4[1] + c * p4[2] + d
    if p == 0:
        return True

    return False


# LINE INTERSECTIONS
# Find edges that intersect with this edge
def get_edge_intersects(bm, edge):
    ips = []
    for e in bm.edges:
        ip = edges_interset(edge, e)
        if ip:
            ip = (ip[0] + ip[1]) / 2
            ips.append(ip)
    return ips


def edges_interset(e1, e2):
    verts = return_edge_verts(e1, e2)
    return LineIntersect(*verts)


def return_edge_verts(e1, e2):
    return [e1.verts[0].co, e1.verts[1].co, e2.verts[0].co, e2.verts[1].co]


# parse string to work out if contains operators +-*/
def parse_dist(dist, user_val, context):
    r_val = 0.0

    # if /*+- as first character then apply this to the current distance
    # else return current user value/expression
    if user_val[0] in utl.NUM_OPS:
        num = user_val
        r_val = str(utl.reverse_scale(dist[0], context)) + num
    else:
        r_val = user_val

    # evaluate expression before return
    return float(eval(str(r_val)))


def calc_len(verts):
    vert1 = verts[0]
    vert2 = verts[1]
    dx = vert1[0] - vert2[0]
    dy = vert1[1] - vert2[1]
    dz = vert1[2] - vert2[2]
    dist = math.sqrt((dx) ** 2 + (dy) ** 2 + (dz) ** 2)

    return round(dist, 4), round(dx, 4), round(dy, 4), round(dz, 4)


def calc_len_2D(verts):
    vert1 = verts[0]
    vert2 = verts[1]
    dx = vert1[0] - vert2[0]
    dy = vert1[1] - vert2[1]
    dist = math.sqrt((dx) ** 2 + (dy) ** 2)

    return round(dist, 4), round(dx, 4), round(dy, 4)


def calc_sq_len(vert1, vert2):
    dx = vert1[0] - vert2[0]
    dy = vert1[1] - vert2[1]
    dz = vert1[2] - vert2[2]
    dist = (dx) ** 2 + (dy) ** 2 + (dz) ** 2

    return dist


def round_vects_4(vects) -> []:
    rnd_vs = []
    for v in vects:
        rnd_vs.append(round_vect_4(v))
    return rnd_vs


def round_vect_4(vect):
    nv = vect.copy()
    return Vector((round(nv[0], 4), round(nv[1], 4), round(nv[2], 4)))


def verts_to_vect3(verts) -> []:
    vects = []
    for v in verts:
        vects.append(Vector((v[0], v[1], v[2])))
    return vects


# GEOM SELECTION
def select_vis_geom(obj, cursor_loc, context):
    if not obj:
        return

    emode = bpy.context.mode == "EDIT_MESH"

    if not emode:
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")

    bpy.ops.view3d.select_circle(
        x=cursor_loc[0],
        y=cursor_loc[1],
        radius=utl.CL_SELECT_REGION_SIZE,
        wait_for_input=False,
        mode="SET",
    )

    # make sure any edges that run out of view are selected
    bpy.ops.mesh.select_mode(type="EDGE")
    bpy.ops.view3d.select_circle(
        x=cursor_loc[0],
        y=cursor_loc[1],
        radius=utl.CL_SELECT_REGION_SIZE,
        wait_for_input=False,
        mode="ADD",
    )

    matrix = obj.matrix_world.copy()
    bm = bmesh.from_edit_mesh(obj.data)
    # verts
    bm_v = [matrix @ v.co for v in bm.verts if v.select]
    # edge centers
    bm_ec = [
        find_edge_center(matrix @ e.verts[0].co, matrix @ e.verts[1].co)
        for e in bm.edges
        if e.select
    ]

    # edge points
    bm_ep = [
        (matrix @ e.verts[0].co, matrix @ e.verts[1].co) for e in bm.edges if e.select
    ]

    bpy.ops.mesh.select_all(action="DESELECT")
    bpy.ops.object.mode_set(mode="OBJECT")
    if emode:
        bpy.ops.object.mode_set(mode="EDIT")

    return bm_v, bm_ec, bm_ep

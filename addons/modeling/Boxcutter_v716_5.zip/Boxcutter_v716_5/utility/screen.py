import bpy

from . import addon, new_type, method_handler


def system_dpi():
    system = bpy.context.preferences.system
    return round(system.dpi * system.pixel_size)


def dpi_factor(rnd=False):
    factor = system_dpi() / 72 if addon.preferences().behavior.use_dpi_factor else 1
    return factor if not rnd else round(factor)

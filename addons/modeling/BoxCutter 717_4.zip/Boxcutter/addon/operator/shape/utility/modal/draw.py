# from ... import shape as _shape
from .. import lattice, mesh


def shape(op, context, event, index=-1):
    bc = context.scene.bc

    # if op.modified or (op.mouse['location'] - op.init_mouse).length > context.preferences.inputs.drag_threshold:
    if op.shape_type != 'NGON':
        lattice.draw(op, context, event)
    else:
        mesh.draw(op, context, event, index=index)

    points = bc.lattice.data.points
    location_z = None
    opposite_co = [points[i].co_deform for i in lattice.front][0].z
    for point in lattice.back:
        if not location_z:
            location_z = points[point].co_deform.z - opposite_co
        points[point].co_deform.z = location_z + opposite_co if location_z < -lattice.thickness_clamp(context) else opposite_co - lattice.thickness_clamp(context)

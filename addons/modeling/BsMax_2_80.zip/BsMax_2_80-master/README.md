# BsMax_2_80 
(Works on Blender 2.80 ~ 2.83)

FixedBugs
* ...preferences['select_mouse'] error on Blender fixed

Recent Updates
* Rightclick Droptool disabled when rightclick select is active
* Automate animated link(child of). active animation assistance tool pack to see it.
* Float Primitive Panel can run in blender mode with out activing the 3DsMax tools.
* Mesh Primitives Update faster (for Blender 2.81 and above).
* New Extrud Mesh object added to Create/Mesh menu (Genarate a Mesh object) (Under Construction).
* Extrud shape object added to Create/Curve menu (Genarate a curve object).
* Convert to regular object added to contex menu and primitive parameters panel.
* Ask for close the Line if click on first point while drawing.

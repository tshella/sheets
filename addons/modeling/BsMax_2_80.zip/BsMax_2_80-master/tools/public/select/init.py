from .selection import *

def select_cls(register, pref):
	selection_cls(register)

__all__ = ["select_cls"]
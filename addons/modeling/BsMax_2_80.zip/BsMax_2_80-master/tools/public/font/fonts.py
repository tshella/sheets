

def fonts_cls(register):
	pass

__all__ = ["fonts_cls"]
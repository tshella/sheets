from .bone import *

def armature_cls(register, pref):
	bone_cls(register)

__all__ = ["armature_cls"]
import addon_utils

# Note: this will enabled needed addons
# not active for now

addon_utils.enable("my_addon")
addon_utils.disable("my_addon")


Node:Node Wrangler
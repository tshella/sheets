from statistics import median
from mathutils import Vector


def longest_center(mesh, face):
    center = Vector()
    max_length = 0.0
    for index in face.vertices:
        for check in face.vertices:
            if check == index:
                continue

            vert = mesh.vertices[index]
            vert_check = mesh.vertices[check]
            length = (vert.co - vert_check.co).length
            current_mid = median((vert.co, vert_check.co))

            if length < max_length:
                continue

            max_length = length
            center = current_mid

    return center

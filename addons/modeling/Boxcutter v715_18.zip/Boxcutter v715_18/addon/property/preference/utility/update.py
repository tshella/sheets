from .... utility import addon

sort_options = (
    'sort_modifiers',
    'sort_bevel',
    'sort_array',
    'sort_mirror',
    'sort_solidify',
    'sort_weighted_normal',
    'sort_simple_deform',
    'sort_triangulate',
    'sort_decimate',
    'sort_remesh',
    'sort_subsurf',
    'sort_bevel_last',
    'sort_array_last',
    'sort_mirror_last',
    'sort_solidify_last',
    'sort_weighted_normal_last',
    'sort_simple_deform_last',
    'sort_triangulate_last',
    'sort_decimate_last',
    'sort_remesh_last',
    'sort_subsurf_last')


#TODO: turn into generic util
def sync_sort(prop, context):
    for option in sort_options:

        if addon.hops() and hasattr(addon.hops().property, option):
            addon.hops().property[option] = getattr(prop, option)

        else:
            print(F'Unable to sync sorting options with Hard Ops; Box Cutter {option}\nUpdate Hard Ops!')

        if addon.kitops() and hasattr(addon.kitops(), option):
            addon.kitops()[option] = getattr(prop, option)

        else:
            print(F'Unable to sync sorting options with KIT OPS; Box Cutter {option}\nUpdate KIT OPS!')


def simple_topbar(display, context):
    toggle = not display.simple_topbar
    display.topbar_pad = toggle
    display.pad_menus = toggle

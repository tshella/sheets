import bpy

from bpy.utils import register_class, unregister_class
from bpy.types import PropertyGroup, Object, Collection
from bpy.props import *

from . import data, dots, last, object, scene, snap, preference
from . utility import update
from .. utility import addon


class option(PropertyGroup):
    running: BoolProperty()
    addon: StringProperty(default=addon.name)


classes = [
    data.option,
    dots.Dots,
    dots.Groups,
    dots.option,
    last.option,
    object.option,
    snap.option,
    scene.option,
    option]


def register():
    for cls in classes:
        register_class(cls)

    bpy.types.WindowManager.bc = PointerProperty(type=option)
    bpy.types.Object.bc = PointerProperty(type=object.option)
    bpy.types.Mesh.bc = PointerProperty(type=data.option)
    bpy.types.Lattice.bc = PointerProperty(type=data.option)
    bpy.types.Scene.bc = PointerProperty(type=scene.option)


def unregister():
    for cls in classes:
        unregister_class(cls)

    del bpy.types.WindowManager.bc
    del bpy.types.Object.bc
    del bpy.types.Mesh.bc
    del bpy.types.Lattice.bc
    del bpy.types.Scene.bc

import bpy

from bpy.types import PropertyGroup, Object
from bpy.props import PointerProperty, BoolProperty


def sync_state(option, context):
    option.solidify_state = option.solidify


class option(PropertyGroup):
    target: PointerProperty(type=Object)
    shape: BoolProperty()
    slice: BoolProperty()
    applied: BoolProperty()
    applied_cycle: BoolProperty()
    inset: BoolProperty()
    copy: BoolProperty()

    array: BoolProperty()
    array_circle: BoolProperty()
    solidify: BoolProperty(update=sync_state)
    solidify_state: BoolProperty()
    bevel: BoolProperty()
    mirror: BoolProperty()

from mathutils import Matrix, Vector

from . import axis, display, dots, refresh, bevel

from ..... import topbar

from .. import modifier
# from .... utility import lattice, mesh, modifier
from .... utility import lattice, mesh
from ..... utility import addon, view3d


def change(ot, context, event, to='NONE', modified=True, init=False, clear_mods=[], dot=False):
    preference = addon.preference()
    bc = context.scene.bc
    ot.modified = modified

    if modified and ot.lmb:
        ot.modified_lock = True
    else:
        ot.modified_lock = False

    if to == 'BEVEL_Q':
        bc.q_bevel = not bc.q_bevel
        bc.shape.data.bc.q_beveled = bc.q_bevel
        to = 'BEVEL'

    if not init:
        ot.last['operation'] = ot.operation

    for mod in bc.shape.modifiers:
        if mod.type in clear_mods:
            setattr(bc.shape.bc, mod.type.lower(), False)
            bc.shape.modifiers.remove(mod)

    if ot.operation == 'DRAW' and ot.shape_type == 'NGON':
        if not ot.add_point:
            mesh.remove_point(ot, context, event)

    elif ot.operation in {'EXTRUDE', 'OFFSET'}:
        bc.plane.matrix_world = bc.shape.matrix_world
        ot.start['matrix'] = bc.plane.matrix_world.copy()
        ot.start['extrude'] = bc.lattice.data.points[lattice.back[0]].co_deform.z

    elif ot.operation == 'ARRAY':
        if bc.axis == 'NONE':
            axis.change(ot, context, to='X')

        axis_index = [bc.axis == axis for axis in 'XYZ'].index(True)

        for mod in bc.shape.modifiers:
            if mod.type == 'ARRAY':
                ot.last['modifier']['offset'] = mod.constant_offset_displace[axis_index]
                ot.last['modifier']['count'] = mod.count
                break

        # if modified:
            # if to == 'ARRAY' and bc.shape.bc.array_circle:
                # to = 'NONE'

        if to == 'ARRAY' and not bc.shape.bc.array_circle:
            bc.shape.bc.array_circle = True

        elif to == 'ARRAY' and ot.operation == 'ARRAY' and bc.shape.bc.array_circle:
            bc.shape.bc.array_circle = False
            for mod in bc.shape.modifiers:
                if mod.type == 'ARRAY':
                    bc.shape.modifiers.remove(mod)
                elif mod.type == 'DISPLACE':
                    bc.shape.modifiers.remove(mod)
        # elif to == 'NONE' and ot.operation == 'ARRAY' and bc.shape.bc.array_circle:
            # to = 'NONE'

    elif ot.operation == 'SOLIDIFY':
        obj = bc.shape if ot.mode != 'INSET' else ot.datablock['slices'][-1]
        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                if ot.mode != 'INSET':
                    ot.last['modifier']['thickness'] = mod.thickness
                else:
                    ot.last['thickness'] = mod.thickness
                break

        if modified:
            if to == 'SOLIDIFY': to = 'NONE'

        del obj

    elif ot.operation == 'BEVEL':
        for mod in bc.shape.modifiers:
            if mod.type == 'BEVEL' and not init:
                ot.last['modifier']['width'] = mod.width
                ot.last['modifier']['segments'] = mod.segments
                ot.last['modifier']['limit_method'] = mod.limit_method
                ot.last['modifier']['use_only_vertices'] = mod.use_only_vertices
                ot.last['modifier']['use_clamp_overlap'] = mod.use_clamp_overlap
                break

        ot.last['mouse'] = ot.mouse['location']

        if modified:
            if to == 'BEVEL':
                to = 'NONE'

    rebevel = False
    if (ot.shape_type == 'NGON' and to == 'EXTRUDE'):
        for mod in bc.shape.modifiers:
            if mod.type == 'BEVEL':
                bc.shape.modifiers.remove(mod)

                rebevel = True

    if ot.modified and ot.alt_lock:
        ot.alt_lock = False

    value = to

    ot.operation = value
    topbar.change_prop(context, 'operation', value)

    if value in {'EXTRUDE', 'OFFSET'}:
        mouse = ot.mouse['location']

        bc.plane.matrix_world = bc.shape.matrix_world
        matrix = bc.plane.matrix_world
        inverse = matrix.inverted()

        front = (1, 2, 5, 6)
        back = (0, 3, 4, 7)
        side = front if value == 'OFFSET' else back
        coord = matrix @ (0.25 * sum((ot.bounds[point] for point in side), Vector()))

        location = inverse @ view3d.location2d_to_location3d(mouse.x, mouse.y, coord)

        ot.start['offset'] = location.z

    elif value == 'ROTATE':
        ot.angle = 0
        ot.last['track'] = ot.mouse['location'] - view3d.location3d_to_location2d(bc.lattice.matrix_world.translation)
        ot.last['mouse'] = ot.mouse['location']
        bc.axis = 'Z' if bc.axis == 'NONE' else bc.axis

    elif value == 'ARRAY':
        bc.shape.bc.array = True

        if bc.axis == 'NONE':
            axis.change(ot, context, to='Y')

        axis_index = [bc.axis == axis for axis in 'XYZ'].index(True)

        for mod in bc.shape.modifiers:
            if mod.type == 'ARRAY':
                ot.last['modifier']['offset'] = mod.constant_offset_displace[axis_index]
                ot.last['modifier']['count'] = mod.count

                break

    elif value == 'SOLIDIFY':
        bc.shape.bc.solidify = True
        obj = bc.shape if ot.mode != 'INSET' else ot.datablock['slices'][-1]
        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                if ot.mode != 'INSET':
                    ot.last['modifier']['thickness'] = mod.thickness
                else:
                    ot.last['thickness'] = mod.thickness
                break

        del obj

        ot.last['mouse'] = ot.mouse['location']

    elif value == 'BEVEL':
        bc.shape.bc.bevel = True
        for mod in bc.shape.modifiers:
            if mod.type == 'BEVEL':
                preference.shape.bevel_segments = mod.segments
                bc.shape.modifiers.remove(mod)

        ot.last['mouse'] = ot.mouse['location']

    elif value == 'DISPLACE':
        displace = None

        for mod in bc.shape.modifiers:
            if mod.type == 'DISPLACE':
                displace = mod

                break

        if displace:
            ot.start['displace'] = displace.strength / 2

    if ot.modified:
        dots.collect(ot)

    if not init:
        if value == 'NONE':
            ot.report({'INFO'}, 'Shape Locked')

        else:
            ot.report({'INFO'}, '{}{}{}'.format(
                'Added ' if value == 'ARRAY' else '',
                value.title()[:-1 if value in {'MOVE', 'ROTATE', 'SCALE', 'EXTRUDE', 'DISPLACE'} else len(value)],
                'ing' if value != 'ARRAY' else ''))

        refresh.shape(ot, context, event, dot=dot)

    elif value != 'DRAW':
        refresh.shape(ot, context, event)

    if rebevel:
        bevel.shape(ot, context, event)

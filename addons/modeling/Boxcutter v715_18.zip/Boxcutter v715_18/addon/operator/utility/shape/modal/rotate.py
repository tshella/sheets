from math import radians
from mathutils import Matrix


def shape(ot, context, event, inside=False, init=False):
    bc = context.scene.bc


    if inside and ot.shape_type != 'NGON':

        if not init:
            bc.shape.data.transform(Matrix.Rotation(radians(-90*bc.rotated_inside), 4, 'Z'))

            if bc.rotated_inside > 3:
                bc.rotated_inside = 0

            bc.rotated_inside += 1

        bc.shape.data.transform(Matrix.Rotation(radians(90*bc.rotated_inside), 4, 'Z'))

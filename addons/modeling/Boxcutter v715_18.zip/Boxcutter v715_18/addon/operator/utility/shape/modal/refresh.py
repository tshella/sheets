import bpy
from mathutils import Vector

from . import array, axis, behavior, bevel, displace, display, draw, extrude, mode, move, offset, operation, origin, ray, refresh, solidify

from .. import modifier
# from .... utility import lattice, mesh,  modifier
from .... utility import lattice, mesh
from ..... utility import view3d


def shape(ot, context, event, dot=False):
    wm = context.window_manager
    bc = context.scene.bc

    if not ot.bounds:
        return

    mouse = ot.mouse['location']

    if context.window_manager.bc.running:
        matrix = bc.plane.matrix_world
        inverse = matrix.inverted()

        normal = matrix.to_3x3() @ Vector((0, 0, 1))

        ot.mouse['intersect'] = inverse @ view3d.location2d_to_intersect3d(mouse.x, mouse.y, ot.ray['location'], normal)
        # ot.view3d['origin'] = matrix.inverted() @ (matrix @ (0.125 * sum((ot.bounds[point] for point in (0, 1, 2, 3, 4, 5, 6, 7)), Vector())))
        ot.view3d['origin'] = 0.125 * sum((ot.bounds[point] for point in (0, 1, 2, 3, 4, 5, 6, 7)), Vector())

        front = (1, 2, 5, 6)
        back = (0, 3, 4, 7)
        side = back if ot.operation == 'EXTRUDE' else front
        coord = matrix @ (0.25 * sum((ot.bounds[point] for point in side), Vector()))

        thin = bc.lattice.dimensions[2] < 0.0001

        location = inverse @ view3d.location2d_to_location3d(mouse.x, mouse.y, coord)
        start_offset = ot.start['offset'] if ot.operation == 'EXTRUDE' else ot.start['offset'] + ot.start['extrude']
        ot.view3d['location'] = Vector((ot.mouse['intersect'].x, ot.mouse['intersect'].y, location.z - start_offset + ot.start['extrude']))

        if dot:
            if ot.operation == 'DRAW' and ot.shape_type == 'NGON':
                index = -1
                for grp in bc.dots.groups:
                    for dot in grp.dot:
                        if dot.type == 'DRAW' and dot.highlight:
                            index = dot.index

                            break

                    if index != -1:
                        break

                draw.shape(ot, context, event, index=index)

            else:
                globals()[ot.operation.lower()].shape(ot, context, event)

        elif ot.operation != 'NONE':
            globals()[ot.operation.lower()].shape(ot, context, event)

        if context.active_object:
            if modifier.shape_bool(ot, context.active_object):
                display.shape.boolean(ot)

        if ot.operation not in {'NONE', 'BEVEL', 'ARRAY'} and not bc.shape.bc.copy:
            for mod in bc.shape.modifiers:
                if mod.type == 'BEVEL':
                    mod.width = ot.last['modifier']['width'] if ot.last['modifier']['width'] > 0.0004 else 0.0004

                    if mod.width > bevel.clamp(ot):
                        mod.width = bevel.clamp(ot) - 0.0025

                elif mod.type == 'SOLIDIFY':
                    mod.show_viewport = bc.lattice.dimensions[2] > 0.001 or ot.shape_type == 'NGON'

        if (ot.operation != 'DRAW' or ot.original_mode == 'EDIT_MESH') and ot.live:
            if ot.mode in {'CUT', 'SLICE', 'INSET', 'JOIN', 'EXTRACT'}:
                if hasattr(wm, 'Hard_Ops_material_options'):
                    bc.shape.hops.status = 'BOOLSHAPE'

                if bc.shape.display_type != 'WIRE':
                    bc.shape.display_type = 'WIRE'
                    bc.shape.hide_set(False)

                if not modifier.shape_bool(ot, context.active_object):
                    modifier.create(ot)

                if ot.original_mode == 'EDIT_MESH':

                    for target in ot.datablock['targets']:
                        for mod in target.modifiers:
                            if mod != modifier.shape_bool(ot, target):
                                mod.show_viewport = False

                                if ot.mode == 'INSET' and mod.type == 'BOOLEAN' and mod.object in ot.datablock['slices'] and not thin:
                                    mod.show_viewport = True

                    modifier.update(ot, context)

            elif ot.mode == 'MAKE':
                if hasattr(wm, 'Hard_Ops_material_options'):
                    bc.shape.hops.status = 'UNDEFINED'

                if bc.shape.display_type != 'TEXTURED':
                    bc.shape.display_type = 'TEXTURED'
                    bc.shape.hide_set(True)

                if ot.datablock['targets']:
                    if modifier.shape_bool(ot, context.active_object):
                        modifier.clean(ot)

            elif ot.mode == 'KNIFE':
                if hasattr(wm, 'Hard_Ops_material_options'):
                    bc.shape.hops.status = 'UNDEFINED'

                if bc.shape.display_type != 'WIRE':
                    bc.shape.display_type = 'WIRE'
                    bc.shape.hide_set(False)

                if modifier.shape_bool(ot, context.active_object):
                    modifier.clean(ot)

                mesh.knife(ot, context, event)

import bpy
import bmesh

from mathutils import Vector

from .... utility import active_tool, addon, mesh
from .... utility.modifier import apply, sort, new, unmodified_bounds, bevels

sort_types = [
    'ARRAY',
    'MIRROR',
    'BEVEL',
    'SOLIDIFY',
    'DISPLACE',
    'LATTICE',
    'DECIMATE'
    'SCREW',
]

if bpy.app.version[1] >= 82:
    sort_types.insert(1, 'WELD')


def shape_bool(ot, obj):
    bc = bpy.context.scene.bc

    for mod in reversed(obj.modifiers):
        if mod.type == 'BOOLEAN' and mod.object == bc.shape:

            return mod

    return None


def update(ot, context):
    bc = context.scene.bc
    original_active = context.active_object
    targets = ot.datablock['targets']
    overrides = ot.datablock['overrides']

    if not overrides:
        ot.datablock['overrides'] = [obj.data for obj in targets]

    for pair in zip(targets, overrides):
        obj = pair[0]
        override = pair[1]

        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='OBJECT')

        old_data = obj.data

        if obj.data != override:
            obj.data = override
        else:
            obj.data = obj.data.copy()

        if old_data not in ot.datablock['overrides']:
            bpy.data.meshes.remove(old_data)

        new_obj = obj.copy()
        coords = [vert.co for vert in new_obj.data.vertices]

        for mod in new_obj.modifiers:
            if mod.type == 'BOOLEAN':
                if mod.object == bc.shape or mod.object in ot.datablock['slices']:
                    new_obj.modifiers.remove(mod)

        for mod in obj.modifiers:
            if mod.type == 'BOOLEAN':
                if mod.object != bc.shape or mod.object in ot.datablock['slices']:
                    obj.modifiers.remove(mod)
            else:
                obj.modifiers.remove(mod)

        obj.data = bpy.data.meshes.new_from_object(obj.evaluated_get(bpy.context.evaluated_depsgraph_get()))

        for mod in new_obj.modifiers:
            new(obj, mod=mod)

        bpy.data.objects.remove(new_obj)

        bm = bmesh.new()
        bm.from_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        new_verts = []
        for v in bm.verts:
            if v.co not in coords:
                v.select_set(True)
                new_verts.append(v)

        bm.select_flush(True)

        bm.edges.ensure_lookup_table()
        bw = bm.edges.layers.bevel_weight.verify()
        for e in bm.edges:
            if False not in [v in new_verts for v in e.verts]:
                e[bw] = 0

        bm.to_mesh(obj.data)
        bm.free()

    del targets
    del overrides

    context.view_layer.objects.active = original_active

    bpy.ops.object.mode_set(mode='EDIT')


#TODO: move to operator.utility.shape.modifier
def clean(ot, modifier_only=False):
    for obj in ot.datablock['targets']:
        if shape_bool(ot, obj):
            obj.modifiers.remove(shape_bool(ot, obj))

    if not modifier_only:
        for obj in ot.datablock['slices']:
            bpy.data.meshes.remove(obj.data)

        ot.datablock['slices'] = list()


# TODO: move array here
class create:


    def __init__(self, ot):
        # ot.datablocks['overrides']

        if ot.datablock['overrides']:
            for pair in zip(ot.datablock['targets'], ot.datablock['overrides']):
                obj = pair[0]
                override = pair[1]

                name = obj.data.name
                obj.data.name = 'tmp'

                obj.data = override
                obj.data.name = name

                for mod in obj.modifiers:
                    mod.show_viewport = True

            ot.datablock['overrides'] = list()

        self.boolean(ot)


    @staticmethod
    def boolean(ot, show=False):
        wm = bpy.context.window_manager
        preference = addon.preference()
        bc = bpy.context.scene.bc

        if not ot.datablock['targets']:
            return

        if shape_bool(ot, ot.datablock['targets'][0]):
            for obj in ot.datablock['targets']:
                if shape_bool(ot, obj):
                    obj.modifiers.remove(shape_bool(ot, obj))

            for obj in ot.datablock['slices']:
                bpy.data.meshes.remove(obj.data)

            ot.datablock['slices'] = []

        if ot.mode != 'MAKE':
            bc.shape.display_type = 'WIRE'
        else:
            bc.shape.display_type = 'TEXTURED'

        bc.shape.hide_set(True)

        for obj in ot.datablock['targets']:
            if not ot.active_only or obj == bpy.context.view_layer.objects.active:
                mod = obj.modifiers.new(name='Boolean', type='BOOLEAN')
                mod.show_viewport = show
                mod.show_expanded = False
                mod.object = bc.shape
                mod.operation = 'DIFFERENCE' if ot.mode != 'JOIN' else 'UNION'

                # sort(obj, option=preference.behavior)
                ignore_vgroup = preference.behavior.sort_bevel_ignore_vgroup
                ignore_verts = preference.behavior.sort_bevel_ignore_only_verts
                bvls = bevels(obj, vertex_group=ignore_vgroup, props={'use_only_vertices': True} if ignore_verts else {})
                sort(obj, option=preference.behavior, ignore=bvls)

                if ot.mode in {'INSET', 'SLICE', 'EXTRACT'}:
                    new = obj.copy()
                    new.data = obj.data.copy()

                    if ot.mode in {'SLICE', 'EXTRACT'}:
                        if obj.users_collection:
                            for collection in obj.users_collection:
                                collection.objects.link(new)
                        else:
                            bpy.context.scene.collection.objects.link(new)

                        bc.slice = new

                        if bc.original_active and preference.behavior.parent_shape:
                            bc.slice.parent = bc.original_active

                    else:
                        bc.collection.objects.link(new)
                        new.bc.inset = True

                    new.select_set(True)

                    new.name = ot.mode.title()
                    new.data.name = ot.mode.title()

                    if preference.behavior.apply_slices and ot.mode != 'EXTRACT':
                        apply(new, ignore=[shape_bool(ot, new)], types={'BOOLEAN'})

                    if ot.mode not in {'SLICE', 'EXTRACT'}:
                        new.hide_set(True)

                    shape_bool(ot, new).operation = 'INTERSECT'

                    if addon.preference().behavior.apply_slices or ot.mode == 'INSET':
                        if ot.mode == 'INSET':
                            for mod in new.modifiers[:]:
                                if mod.type == 'BEVEL':
                                    if mod.use_only_vertices or mod.limit_method == 'VGROUP':
                                        continue

                                    new.modifiers.remove(mod)

                        apply(new, ignore=[shape_bool(ot, new)], types={'BOOLEAN' if ot.mode == 'SLICE' else ''})

                    if ot.mode == 'INSET':
                        new.display_type = 'WIRE'
                        new.hide_render = True

                        if hasattr(new, 'cycles_visibility'):
                            new.cycles_visibility.camera = False
                            new.cycles_visibility.diffuse = False
                            new.cycles_visibility.glossy = False
                            new.cycles_visibility.transmission = False
                            new.cycles_visibility.scatter = False
                            new.cycles_visibility.shadow = False
                            new.cycles.is_shadow_catcher = False
                            new.cycles.is_holdout = False

                        solidify = new.modifiers.new(name='Solidify', type='SOLIDIFY')
                        solidify.thickness = ot.last['thickness']
                        solidify.offset = 0
                        solidify.show_on_cage = True
                        solidify.use_even_offset = True
                        solidify.use_quality_normals = True

                        new.modifiers.remove(shape_bool(ot, new))

                        mod = new.modifiers.new(name='Boolean', type='BOOLEAN')
                        mod.show_viewport = show
                        mod.show_expanded = False
                        mod.object = bc.shape
                        mod.operation = 'INTERSECT'

                        for mod in bc.shape.modifiers:
                            if mod.type == 'SOLIDIFY':
                                bc.shape.modifiers.remove(mod)

                        bool = None
                        for mod in reversed(obj.modifiers):
                            if mod.type == 'BOOLEAN' and mod.object == new:
                                bool = mod
                                break

                        if not bool:
                            mod = obj.modifiers.new(name='Boolean', type='BOOLEAN')
                            mod.show_viewport = show
                            mod.show_expanded = False
                            mod.object = new
                            mod.operation = 'DIFFERENCE'

                            if hasattr(wm, 'Hard_Ops_material_options'):
                                new.hops.status = 'BOOLSHAPE'

                            # sort(obj, option=preference.behavior)
                            ignore_vgroup = preference.behavior.sort_bevel_ignore_vgroup
                            ignore_verts = preference.behavior.sort_bevel_ignore_only_verts
                            bvls = bevels(obj, vertex_group=ignore_vgroup, props={'use_only_vertices': True} if ignore_verts else {})
                            sort(obj, option=preference.behavior, ignore=bvls)

                        bc.inset = new

                        if bc.original_active and preference.behavior.parent_shape:
                            bc.inset.parent = bc.original_active

                    ot.datablock['slices'].append(new)

        hops = getattr(wm, 'Hard_Ops_material_options', False)

        if not len(bpy.data.materials[:]):
            hops = False

        if hops and hops.active_material:
            active_material = bpy.data.materials[hops.active_material]

            bc.shape.data.materials.clear()

            if ot.mode not in {'SLICE', 'INSET', 'KNIFE', 'EXTRACT'}:
                bc.shape.data.materials.append(active_material)

                if ot.mode != 'MAKE':
                    for obj in ot.datablock['targets']:
                        mats = [slot.material for slot in obj.material_slots if slot.material]

                        obj.data.materials.clear()

                        for index, mat in enumerate(mats):
                            if not index or (mat != active_material or mat in ot.existing[obj]['materials']):
                                obj.data.materials.append(mat)

                        if active_material not in obj.data.materials[:]:
                            obj.data.materials.append(active_material)

            elif ot.mode in {'SLICE', 'INSET'}:
                for obj in ot.datablock['targets']:
                    mats = [slot.material for slot in obj.material_slots if slot.material]

                    obj.data.materials.clear()

                    for index, mat in enumerate(mats):
                        if not index or (mat != active_material or mat in ot.existing[obj]['materials']):
                            obj.data.materials.append(mat)

                    if ot.mode == 'INSET' and active_material not in obj.data.materials[:]:
                        obj.data.materials.append(active_material)

                for obj in ot.datablock['slices']:
                    if ot.mode != 'INSET':
                            obj.data.materials.clear()

                    obj.data.materials.append(active_material)

                    if ot.mode == 'INSET':
                        mats = [slot.material for slot in obj.material_slots]
                        index = mats.index(active_material)

                        for mod in obj.modifiers:
                            if mod.type == 'SOLIDIFY':
                                mod.material_offset = index

                                break

import bpy

from math import sqrt
from mathutils import Vector
from statistics import median

from ... import lattice
from ..... utility import addon, screen, view3d, timed

highlighted_dots = []


def collect(ot):
    pref = addon.preference()
    bc = bpy.context.scene.bc

    bc.dots.groups.clear()

    dots = bc.dots.groups.add()

    if ot.shape_type != 'NGON':
        dot = dots.dot.add()
        dot.type = 'DRAW'
        dot.color = pref.color.dot

    # else:
    #     for vert in bc.shape.data.vertices:
    #         if vert.index not in ot.geo['indices']['extrusion']:
    #             dot = dots.dot.add()
    #             dot.type = 'DRAW'
    #             dot.color = pref.color.dot
    #             dot.index = vert.index

    dots = bc.dots.groups.add()

    # dot = dots.dot.add()
    # dot.type = 'BEVEL_Q'
    # dot.color = pref.color.dot_bevel
    # dot.color[3] = 0.075

    dot = dots.dot.add()
    dot.type = 'BEVEL'
    dot.color = pref.color.dot_bevel

    dots = bc.dots.groups.add()

    dot = dots.dot.add()
    dot.type = 'DISPLACE'
    dot.color = pref.color.dot

    dots = bc.dots.groups.add()

    dot = dots.dot.add()
    dot.type = 'EXTRUDE'
    dot.color = pref.color.dot

    dot = dots.dot.add()
    dot.type = 'OFFSET'
    dot.color = pref.color.dot

    update(ot)


def test_select(ot, location):
    preference = addon.preference()
    mouse = ot.mouse['location']

    dot_size = preference.display.dot_size * screen.dpi_factor()
    dot_factor = preference.display.dot_factor

    return (mouse - location).length < dot_size * dot_factor


def update(ot):
    global highlighted_dots
    highlighted_dots = []

    preference = addon.preference()
    bc = bpy.context.scene.bc

    for grp in bc.dots.groups:
        for dot in grp.dot:
            if not bc.lattice:
                break

            displace = len([mod for mod in bc.shape.modifiers if mod.type == 'DISPLACE'])

            dot.enable = ot.operation in {dot.type, 'NONE'} and ot.modified

            if dot.type == 'OFFSET' and bc.lattice.dimensions[2] < 0.001:
                dot.enable = False

            if dot.type == 'DISPLACE' and not displace:
                dot.enable = False

            if dot.type == 'DISPLACE' and displace and bc.shape.bc.array_circle and ot.operation in 'ARRAY':
                dot.enable = True

            if dot.type == 'BEVEL_Q' and ot.shape_type in {'CIRCLE', 'CUSTOM'}:
                dot.enable = False

            if dot.type == 'BEVEL' and ot.shape_type == 'CUSTOM':
                dot.enable = False

            if dot.enable or dot.alpha:
                if not dot.enable and not timed.timers[dot].reverse:
                    timed.timers[dot].reverse = True

                dot.alpha = timed(dot,
                    seconds = preference.display.dot_fade_time_in * 0.001,
                    exit = preference.display.dot_fade_time_out * 0.001)

            if not dot.enable:
                continue

            dot_refresh(ot, dot)

    bc.dots.active = ''

    locations = [(ot.mouse['location'] - Vector(dot.location2d[:]), dot) for dot in highlighted_dots]

    if not len(locations):
        return

    closest = min(locations)

    for dot in highlighted_dots:
        if dot != closest[1]:
            dot.highlight = False

    bc.dots.active = closest[1].type


def dot_refresh(ot, dot):
    global highlighted_dots

    bc = bpy.context.scene.bc
    matrix = bc.shape.matrix_world

    location = None

    if dot.type in {'OFFSET', 'EXTRUDE'}:
        front = (1, 2, 5, 6)
        back = (0, 3, 4, 7)
        side = front if dot.type == 'OFFSET' else back
        location = matrix @ (0.25 * sum((ot.bounds[point] for point in side), Vector()))

    elif dot.type == 'DRAW':
        if ot.shape_type in {'BOX', 'CUSTOM'}:
            location = matrix @ ot.bounds[ot.draw_dot_index]

        elif ot.shape_type == 'CIRCLE':
            if ot.draw_dot_index in {5, 6}:
                location = matrix @ (0.5 * sum((ot.bounds[point] for point in (5, 6)), Vector()))

            else:
                location = matrix @ (0.5 * sum((ot.bounds[point] for point in (1, 2)), Vector()))

        else:
            location = matrix @ bc.shape.data.vertices[dot.index].co

    elif dot.type == 'DISPLACE':
        left = (4, 5, 6, 7)
        right = (0, 1, 2, 3)

        if ot.draw_dot_index in {5, 6}:
            location = matrix @ (0.25 * sum((ot.bounds[point] for point in right), Vector()))

        else:
            location = matrix @ (0.25 * sum((ot.bounds[point] for point in left), Vector()))

    elif 'BEVEL' in dot.type:
        indices = {1: 7, 2: 4,
                   5: 3, 6: 0}

        offset = 0.05 if dot.type[-1] != 'Q' else 0.15
        if ot.draw_dot_index in indices.keys():
            location = Vector(ot.bounds[indices[ot.draw_dot_index]])
            location.x -= offset if ot.draw_dot_index in {5, 6} else -offset
            location.y -= offset if ot.draw_dot_index in {2, 6} else -offset
            location.z -= offset

            location = matrix @ location

    if location:
        dot.location = location
        dot.location2d = view3d.location3d_to_location2d(dot.location)
        dot.highlight = test_select(ot, Vector(dot.location2d[:]))

        if ot.operation == dot.type:
            dot.highlight = True

    else:
        dot.enable = False

        if ot.operation != dot.type:
            dot.highlight = False

    if dot.highlight:
        highlighted_dots.append(dot)

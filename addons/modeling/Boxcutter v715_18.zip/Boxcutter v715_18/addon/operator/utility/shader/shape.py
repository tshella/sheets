import time
import traceback

import bpy
import bmesh
import gpu

from math import cos, sin

from bgl import *
from gpu_extras.batch import batch_for_shader

from mathutils import *

from ... shape import draw
from .... utility import addon, screen, object, timed


class setup:
    handlers = []


    def __init__(self, ot, context):
        preference = addon.preference()

        self.handler = None
        self.finished = False

        self.geo_batch = None
        self.geo_shader = None
        self.wire_shader = None
        self.batch_finished = False

        self.alpha = 0.0

        self.time = 0.0
        self.time_in = preference.display.shape_fade_time_in
        self.time_out = preference.display.shape_fade_time_out
        self.exit = False
        self.custom_exit = False

        # self.shape = None


    def main(self, _, context):
        if self.handler not in setup.handlers:
            setup.handlers.append(self.handler)

        try:
            self.update_handler(context)
        except Exception:
            print(F'\nRemove shader handler fallback: Shape\nReason:\n')
            traceback.print_exc()

            self.finished = True


    def update_handler(self, context):
        if self.finished:
            return

        preference = addon.preference()
        # bc = context.scene.bc

        self.alpha = timed(F'{self} alpha', seconds=self.time_in * 0.001, exit=self.time_out * 0.001)

        if self.exit or not draw.prop.running:
            self.remove_handler(context)

        elif not self.exit:

            self.color = Vector(getattr(preference.color, draw.prop.mode.lower()))
            self.color[3] = self.color[3] * 2.0 if draw.prop.shape_type == 'NGON' and not draw.prop.extruded else self.color[3]

            solidify = False
            if draw.prop.shape:
                solidify = draw.prop.shape.bc.solidify_state

            if solidify:
                self.color[3] = self.color[3] * 0.5

        self.draw(context)


    def remove_handler(self, context):
        if not self.exit:
            self.exit = True

            context.window_manager.bc.running = False

            timed.timers[F'{self} alpha'].reverse = True

        if not round(self.alpha, 2) and self.handler:
            self.finished = True


    def draw(self, context):
        preference = addon.preference()

        color = Vector(self.color)
        color[3] = color[3] * self.alpha

        wire_color = Vector(preference.color.wire[:]) if not preference.behavior.show_shape else Vector(preference.color.show_shape_wire[:])

        wire_color[3] = wire_color[3] * self.alpha

        if preference.display.wire_only:
            wire_color = (color[0], color[1], color[2], wire_color[3])
            self.wires(context, color=wire_color)

        else:
            self.geometry(context, color=color)
            self.wires(context, color=wire_color)

        if not self.batch_finished and self.exit:
            self.batch_finished = True


    def geometry(self, context, color=tuple()):
        if not self.geo_shader:
            self.geo_shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')

        if not self.batch_finished:
            self.geo_batch = batch_for_shader(self.geo_shader, 'TRIS', {'pos': draw.prop.verts}, indices=draw.prop.indice_tri_loop)

        self.geo_shader.bind()
        self.geo_shader.uniform_float('color', color)

        glEnable(GL_BLEND)

        self.geo_batch.draw(self.geo_shader)

        glDisable(GL_BLEND)


    def wires(self, context, color=tuple()):
        preference = addon.preference()

        if not self.wire_shader:
            self.wire_shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')

        if not self.batch_finished:
            self.wire_batch = batch_for_shader(self.wire_shader, 'LINES', {'pos': draw.prop.verts}, indices=draw.prop.indice_edges)

        self.wire_shader.bind()
        self.wire_shader.uniform_float('color', color)

        width = preference.display.wire_width * screen.dpi_factor()
        if preference.display.wire_only and preference.display.thick_wire:
            width *= preference.display.wire_size_factor

        glEnable(GL_LINE_SMOOTH)
        glEnable(GL_BLEND)

        glLineWidth(width)

        self.wire_batch.draw(self.wire_shader)

        glDisable(GL_LINE_SMOOTH)
        glDisable(GL_BLEND)


    def bounds(context):
        pass

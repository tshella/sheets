import traceback

import bpy

import bmesh
import gpu

from bgl import *
from gpu_extras.batch import batch_for_shader

from math import pi, cos, sin
from mathutils import Vector

from .... utility import addon, screen, timed, method_handler
from ... shape import draw
from .. import shape

# handler = None

class setup:
    handler = None
    exit: bool = False


    def __init__(self, ot, context):
        method_handler(self._init,
            arguments = (ot, context),
            identifier = 'Dot Shader',
            exit_method = self.remove,
            return_result = False)


    def _init(self, ot, context):
        self.handler = bpy.types.SpaceView3D.draw_handler_add(self.shader, (ot, context), 'WINDOW', 'POST_PIXEL')


    def shader(self, ot, context):
        method_handler(self._shader,
            arguments = (ot, context),
            identifier = 'Dots Main',
            exit_method = self.remove,
            return_result = False)


    def _shader(self, ot, context):
        if self.exit:
            self.remove()

            return

        shape.modal.dots.update(ot)
        group(context)


    def remove(self):
        if self.handler:
            self.handler = bpy.types.SpaceView3D.draw_handler_remove(self.handler, 'WINDOW')


def group(context):
    bc = context.scene.bc

    for grp in bc.dots.groups:
        dots(grp)


def dots(grp):
    for point in grp.dot:
        dot(point)


def dot(point):
    preference = addon.preference()

    vertices, indices, vert_edges, indice_edges = circle_collect(point)

    col = Vector(point.color[:]) if not point.highlight else Vector(preference.color.dot_highlight[:])

    col[3] = col[3] * point.alpha

    lines(col, vert_edges, indice_edges)
    circle(col, vertices, indices)


def circle(col, vertices, indices):
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {'pos': vertices}, indices=indices)

    shader.bind()
    shader.uniform_float('color', col)

    glEnable(GL_BLEND)

    batch.draw(shader)

    glDisable(GL_BLEND)

    del shader
    del batch


def lines(col, vert_edges, indice_edges, blend=False):
    shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'LINES', {'pos': vert_edges}, indices=indice_edges)

    shader.bind()
    shader.uniform_float('color', col)

    glEnable(GL_LINE_SMOOTH)
    glEnable(GL_BLEND)

    glLineWidth(1)
    batch.draw(shader)

    glDisable(GL_BLEND)
    glDisable(GL_LINE_SMOOTH)

    del shader
    del batch


def circle_collect(point):
    preference = addon.preference()
    ngon_point = point.type == 'DRAW' and point.index != -1
    size = preference.display.dot_size_ngon if ngon_point else preference.display.dot_size
    size = size * 0.5 * screen.dpi_factor()

    vertices = [(point.location2d[0], point.location2d[1])]

    for i in range(32):
        vertices.append((point.location2d[0] + cos(i * pi * 2 * 0.03125) * size, point.location2d[1] + sin(i * pi * 2 * 0.03125) * size))

    indices = [(0, i + 1, i + 2 if i + 2 < 32 else 1) for i in range(31)]

    vert_edges = vertices[1:]
    vert_edges.append(vert_edges[-1])

    indice_edges = [
        (0, 1), (1, 2), (2, 3), (3, 4), (4, 5), (5, 6), (6, 7), (7, 8), (8, 9), (9, 10), (10, 11),
        (11, 12), (12, 13), (13, 14), (14, 15), (15, 16), (16, 17), (17, 18), (18, 19), (19, 20),
        (20, 21), (21, 22), (22, 23), (23, 24), (24, 25), (25, 26), (26, 27), (27, 28), (28, 29),
        (29, 30), (30, 31), (31, 32), (0, 32)]

    return vertices, indices, vert_edges, indice_edges

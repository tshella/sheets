GEOS -- Geometry Engine, Open Source
====================================

Project homepage: http://geos.osgeo.org/

This is a partial python port of GEOS,
written as fallback for shapely and
focusing on geometric operations required
by archipack.

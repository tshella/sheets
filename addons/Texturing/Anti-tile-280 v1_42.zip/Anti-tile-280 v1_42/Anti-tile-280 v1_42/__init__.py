import bpy

bl_info = {
    "name": "Anti-Tile", 
    "category": "Node", 
    "author": "Tim Crellin (Thatimst3r)", 
    "blender": (2, 80,0), 
    "location": "Node Editor Toolbar", 
    "description":"Removes tiling artifacts from textures",
    "warning": "",
    "wiki_url":"", 
    "tracker_url": "", 
    "version":(1,42)}

class REMOVE_OT_antitile(bpy.types.Operator):
    bl_idname = "remove.antitile"
    bl_label = "Remove"
    bl_description = "Remove Anti-Tile from selected images"

    @classmethod
    def poll(cls, context):
        return cls.poll_helper(context)

    @classmethod
    def poll_helper(cls, context):
        valid = False
        if context.object and context.object.type == "MESH":
            has_mat = context.object.data.materials
            if len(has_mat) > 0:
                active_mat = has_mat[context.object.active_material_index]
                if active_mat.node_tree:
                    iter_list = [list(active_mat.node_tree.nodes)]
                    while iter_list:
                        nodes = iter_list.pop()
                        for check in nodes:
                            if check.type == "GROUP" and check.select and check.node_tree.name.startswith("Anti-tile_"):
                                valid = True
                                break
                            elif check.type == "GROUP" and check.select:
                                iter_list.append(list(check.node_tree.nodes))
                        if valid:
                            break
        return valid

    def fetch_grps(self, context):
        traverse = []
        active_mat = context.object.data.materials[context.object.active_material_index]
        iter_list = [(active_mat.node_tree,list(active_mat.node_tree.nodes))]
        while iter_list:
            tree, nodes = iter_list.pop()
            for check in nodes:
                if check.type == "GROUP" and check.select and check.node_tree.name.startswith("Anti-tile_"):
                    traverse.append((tree, check))
                elif check.type == "GROUP" and check.select:
                    iter_list.append((check.node_tree, list(check.node_tree.nodes)))
        return traverse

    def execute(self, context):
        to_remove = self.fetch_grps(context)
        img_ref = None
        
        for tree, remove_group in to_remove:
            checkShift = remove_group.inputs[1].links
            checkRandom = remove_group.inputs[2].links

            if checkShift and len(checkShift[0].from_node.outputs[0].links) == 1 and checkShift[0].from_node.type == "VALUE":
                tree.nodes.remove(checkShift[0].from_node)
            
            if checkRandom and len(checkRandom[0].from_node.outputs[0].links) == 1 and checkRandom[0].from_node.type == "VALUE":
                tree.nodes.remove(checkRandom[0].from_node)

            for node in remove_group.node_tree.nodes:
                if node.type == "TEX_IMAGE":
                    img_ref = node
                    break
            
            n_node = tree.nodes.new("ShaderNodeTexImage")
            n_node.image = img_ref.image
            n_node.interpolation = img_ref.interpolation
            n_node.projection = img_ref.projection
            n_node.projection_blend = img_ref.projection_blend
            
            if remove_group.inputs[0].links:
                prev = remove_group.inputs[0].links[0]
                tree.links.new(prev.from_node.outputs[prev.from_socket.name], n_node.inputs[0])
            if remove_group.outputs[0].links:
                next_node = remove_group.outputs[0].links[0]
                tree.links.new(next_node.to_node.inputs[next_node.to_socket.name], n_node.outputs[0])

            n_node.location = remove_group.location
            tree.nodes.remove(remove_group)

        for rm_grp in bpy.data.node_groups:
            if rm_grp.name.startswith("Anti-tile_"):
                if rm_grp.users == 0:
                    bpy.data.node_groups.remove(rm_grp)
        #2nd pass
        for rm_grp_2 in bpy.data.node_groups:
            if rm_grp_2.name.startswith("Anti-tile_"):
                if rm_grp_2.users == 0:
                    bpy.data.node_groups.remove(rm_grp_2)

        return {"FINISHED"}

class ADD_OT_antitile(bpy.types.Operator):
    bl_idname = "anti.tile"
    bl_label = "Anti-Tile"
    bl_description = "Anti-tile selected images"

    @classmethod
    def poll(cls, context):
        return cls.poll_helper(context)
    
    @classmethod
    def poll_helper(cls, context):
        valid = False
        if context.object and context.object.type == "MESH":
            has_mat = context.object.data.materials
            if len(has_mat) > 0:
                active_mat = has_mat[context.object.active_material_index]
                if active_mat.node_tree:
                    iter_list = [list(active_mat.node_tree.nodes)]
                    while iter_list:
                        nodes = iter_list.pop()
                        for check in nodes:
                            if check.type == "GROUP" and check.select:
                                iter_list.append(list(check.node_tree.nodes))
                            elif check.type == "TEX_IMAGE" and check.select and check.image:
                                valid = True
                                break
                        if valid:
                            break
        return valid

    def fetch_images(self, context):
        traverse = []
        active_mat = context.object.data.materials[context.object.active_material_index]
        iter_list = [(active_mat.node_tree,list(active_mat.node_tree.nodes))]
        while iter_list:
            tree, nodes = iter_list.pop()
            for check in nodes:
                if check.type == "GROUP" and check.select:
                    iter_list.append((check.node_tree, list(check.node_tree.nodes)))
                elif check.type == "TEX_IMAGE" and check.select and check.image:
                    traverse.append((tree, check))
        return traverse

    def execute(self, context):
        to_add = self.fetch_images(context)

        node_layers = {}
        tree_layers = {}
        for tree, new_image in to_add:
            group = bpy.data.node_groups.new(type="ShaderNodeTree", name="Anti-tile_"+new_image.image.name)
            group.inputs.new("NodeSocketVector", "Coordinate")
            s = group.inputs.new("NodeSocketFloat", "Shift")
            s.default_value = 5
            r = group.inputs.new("NodeSocketFloat", "Random")
            r.default_value = 5
            
            input_node = group.nodes.new("NodeGroupInput")
            input_node.location = (0, 0)

            group.outputs.new("NodeSocketColor", "Result")
            group.outputs.new("NodeSocketColor", "Debug")
            output_node = group.nodes.new("NodeGroupOutput")
            output_node.location = (1100, 0)

            #object info
            obinfo = group.nodes.new(type="ShaderNodeObjectInfo")
            obinfo.location = (0, 150)

            #random multiply
            multi1 = group.nodes.new(type="ShaderNodeMath")
            multi1.operation = 'MULTIPLY'
            multi1.location = (100, 0)
            group.links.new(input_node.outputs["Random"], multi1.inputs[0])
            group.links.new(obinfo.outputs["Random"], multi1.inputs[1])

            #image nodes
            image1 = None
            image2 = None
            image3 = None
            for node in range(3):
                temp_img = group.nodes.new(type="ShaderNodeTexImage")
                temp_img.image = new_image.image
                temp_img.interpolation = new_image.interpolation
                temp_img.projection = new_image.projection
                temp_img.projection_blend = new_image.projection_blend
                if node <1:
                    image1 = temp_img
                    image1.location = (300, 200)
                elif node < 2:
                    image2 = temp_img
                    image2.location = (300, 0)
                else:
                    image3 = temp_img
                    image3.location = (300, -200)
            group.links.new(input_node.outputs["Coordinate"], image1.inputs[0])

            #intense image
            multi2 = group.nodes.new(type="ShaderNodeMath")
            multi2.operation = 'MULTIPLY'
            multi2.inputs[1].default_value = -1
            multi2.location = (400, 750)

            combine1 = group.nodes.new(type="ShaderNodeCombineXYZ")
            combine1.location = (500, 750)

            vectorMath1 = group.nodes.new(type="ShaderNodeVectorMath")
            vectorMath1.operation = 'ADD'
            vectorMath1.location = (600, 750)

            #connections
            group.links.new(multi1.outputs[0], multi2.inputs[0])
            group.links.new(multi1.outputs[0], combine1.inputs[0])
            group.links.new(multi2.outputs[0], combine1.inputs[1])
            group.links.new(input_node.outputs[0], vectorMath1.inputs[0])
            group.links.new(combine1.outputs[0], vectorMath1.inputs[1])
            group.links.new(vectorMath1.outputs[0], image2.inputs[0])

            #secondary image
            combine2 = group.nodes.new(type="ShaderNodeCombineXYZ")
            combine2.location = (400, 500)

            vectorMath2 = group.nodes.new(type="ShaderNodeVectorMath")
            vectorMath2.operation = 'ADD'
            vectorMath2.location=(500, 500)

            #connections
            group.links.new(multi1.outputs[0], combine2.inputs[0])
            group.links.new(multi1.outputs[0], combine2.inputs[1])
            group.links.new(multi1.outputs[0], combine2.inputs[2])
            group.links.new(input_node.outputs[0], vectorMath2.inputs[0])
            group.links.new(combine2.outputs[0], vectorMath2.inputs[1])
            group.links.new(vectorMath2.outputs[0], image3.inputs[0])

            #noise setup
            combine3 = group.nodes.new(type="ShaderNodeCombineXYZ")
            combine3.location = (200, -200)
            group.links.new(input_node.outputs[1], combine3.inputs[0])
            group.links.new(input_node.outputs[1], combine3.inputs[1])
            group.links.new(input_node.outputs[1], combine3.inputs[2])

            vectorMath3 = group.nodes.new(type="ShaderNodeVectorMath")
            vectorMath3.operation = "ADD"
            vectorMath3.location=(300, -100)

            vectorMath4 = group.nodes.new(type="ShaderNodeVectorMath")
            vectorMath4.operation = "SUBTRACT"
            vectorMath4.location=(300, -300)
            group.links.new(input_node.outputs[0], vectorMath3.inputs[0])
            group.links.new(input_node.outputs[0], vectorMath4.inputs[0])
            group.links.new(combine3.outputs[0], vectorMath3.inputs[1])
            group.links.new(combine3.outputs[0], vectorMath4.inputs[1])

            #noise 1
            multi3 = group.nodes.new(type="ShaderNodeMath")
            multi3.operation = 'MULTIPLY'
            multi3.inputs[1].default_value = 2.5
            multi3.location = (200, -500)

            mod3 = group.nodes.new(type="ShaderNodeMath")
            mod3.operation = 'MODULO'
            mod3.inputs[1].default_value = 5
            mod3.location = (300, -500)

            mus1 = group.nodes.new(type="ShaderNodeTexMusgrave")
            mus1.musgrave_type = 'MULTIFRACTAL'
            mus1.inputs["Detail"].default_value = 11
            mus1.location = (400, -500)

            #connections
            group.links.new(vectorMath3.outputs[0], mus1.inputs[0])
            group.links.new(multi1.outputs[0], multi3.inputs[0])
            group.links.new(multi3.outputs[0], mod3.inputs[0])
            group.links.new(mod3.outputs[0], mus1.inputs["Scale"])

            #noise 2
            mod4 = group.nodes.new(type="ShaderNodeMath")
            mod4.operation = 'MODULO'
            mod4.inputs[1].default_value = 2
            mod4.location = (300, -750)

            mus2 = group.nodes.new(type="ShaderNodeTexMusgrave")
            mus2.musgrave_type = 'HETERO_TERRAIN'
            mus2.inputs["Detail"].default_value = 10
            mus2.location = (400, -750)

            #connections
            group.links.new(vectorMath4.outputs[0], mus2.inputs[0])
            group.links.new(multi3.outputs[0], mod4.inputs[0])
            group.links.new(mod4.outputs[0], mus2.inputs["Scale"])

            #get Blender version
            version_number = int(str(bpy.app.version[0])+ str(bpy.app.version[1]))
            past_280 = version_number>280
            #mix first 2
            mix1 = group.nodes.new(type="ShaderNodeMixRGB")
            mix1.location = (750, -200)
            group.links.new(mus1.outputs["Fac"], mix1.inputs[0])
            group.links.new(image1.outputs[0], mix1.inputs[1])
            group.links.new(image2.outputs[0], mix1.inputs[2])

            #mix intense

            mix2 = group.nodes.new(type="ShaderNodeMixRGB")
            mix2.location = (750, 0)
            group.links.new(mus2.outputs["Fac"], mix2.inputs[0])
            group.links.new(image3.outputs[0], mix2.inputs[2])
            group.links.new(mix1.outputs[0], mix2.inputs[1])
            group.links.new(mix2.outputs[0], output_node.inputs[0])

            #debug output
            combineRGB1 = group.nodes.new(type="ShaderNodeCombineRGB")
            combineRGB1.location = (750, 200)
            group.links.new(image1.outputs[0], combineRGB1.inputs[0])

            combineRGB2 = group.nodes.new(type="ShaderNodeCombineRGB")
            combineRGB2.location = (750, 300)
            group.links.new(image2.outputs[0], combineRGB2.inputs[1])

            combineRGB3 = group.nodes.new(type="ShaderNodeCombineRGB")
            combineRGB3.location = (750, 400)
            group.links.new(image3.outputs[0], combineRGB3.inputs[2])

            mix3 = group.nodes.new(type="ShaderNodeMixRGB")
            mix3.location = (850, 250)
            group.links.new(mus1.outputs["Fac"], mix3.inputs[0])
            group.links.new(combineRGB1.outputs[0], mix3.inputs[1])
            group.links.new(combineRGB2.outputs[0], mix3.inputs[2])
            
            mix4 = group.nodes.new(type="ShaderNodeMixRGB")
            mix4.location = (950, 350)
            group.links.new(mus2.outputs["Fac"], mix4.inputs[0])
            group.links.new(combineRGB3.outputs[0], mix4.inputs[2])
            group.links.new(mix3.outputs[0], mix4.inputs[1])
            group.links.new(mix4.outputs[0], output_node.inputs[1])

            for each_node in group.nodes:
                each_node.hide = True
                each_node.select = False

            group_node = tree.nodes.new("ShaderNodeGroup")
            group_node.node_tree = group
            group_node.name = group.name

            if new_image.inputs[0].links:
                prev = new_image.inputs[0].links[0]
                tree.links.new(prev.from_node.outputs[prev.from_socket.name], group_node.inputs[0])
            if new_image.outputs[0].links:
                next_node = new_image.outputs[0].links[0]
                tree.links.new(next_node.to_node.inputs[next_node.to_socket.name], group_node.outputs[0])

            group_node.location = new_image.location
            tree.nodes.remove(new_image)

            if tree.name in node_layers.keys():
                node_layers[tree.name].append(group_node)
            else:
                node_layers[tree.name] = [group_node]
                tree_layers[tree.name] = tree
        
        for t in node_layers.keys():
            tree_ref = tree_layers[t]
            nodes = node_layers[t]
            ref_pos = nodes[0].location

            #check for existing texture coordinate node
            existing_texcoord = None
            texcoord_needed = False
            for n in tree_ref.nodes:
                if n.type=="TEX_COORD":
                    existing_texcoord = n
                if n.type =="GROUP" and n.node_tree.name.startswith("Anti-tile_"):
                    if not n.inputs[0].links:
                        texcoord_needed = True
            
            if not existing_texcoord and texcoord_needed:
                existing_texcoord = tree_ref.nodes.new("ShaderNodeTexCoord")
                existing_texcoord.location = (ref_pos.x - 200, ref_pos.y)

            existing_shift = None
            existing_random = None

            for search_node in tree_ref.nodes:
                if search_node.type=='GROUP' and search_node.node_tree.name.startswith("Anti-tile_"):
                    if not search_node.inputs[0].links:
                        tree_ref.links.new(existing_texcoord.outputs[2], search_node.inputs[0])
                    if search_node.inputs[1].links:
                        check_node = search_node.inputs[1].links[0].from_node
                        if check_node.type == 'VALUE':
                            existing_shift = check_node
                    if search_node.inputs[2].links:
                        check_node = search_node.inputs[2].links[0].from_node
                        if check_node.type == 'VALUE':
                            existing_random = check_node

            if context.scene.useUniform:
                
                if existing_shift == None:
                    shift_node = tree_ref.nodes.new("ShaderNodeValue")
                    shift_node.outputs[0].default_value = 0.7
                    shift_node.location = (ref_pos.x - 200, ref_pos.y + 250)
                else:
                    shift_node = existing_shift            

                if existing_random == None:
                    random_node = tree_ref.nodes.new("ShaderNodeValue")
                    random_node.outputs[0].default_value = 5
                    random_node.location = (ref_pos.x - 200, ref_pos.y + 150)
                else:
                    random_node = existing_random

                for group in nodes:
                    tree_ref.links.new(shift_node.outputs[0], group.inputs[1])
                    tree_ref.links.new(random_node.outputs[0], group.inputs[2])

        return {"FINISHED"}

class ANTITILE_PT_panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_label = "Anti-Tile"
    bl_category= "Anti-Tile"

    def draw(self, context):
        acceptable_engines = ["CYCLES", "BLENDER_EEVEE"]
        if context.scene.render.engine in acceptable_engines:
            layout = self.layout
            row = layout.row()
            row.prop(context.scene, "useUniform")
            col = layout.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.5
            row.operator("anti.tile", icon="GRID")
            row.operator("remove.antitile", icon="X")
        else:
            layout = self.layout
            row = layout.row()
            row.label(text="Only cycles is supported")

classes = (
    ANTITILE_PT_panel,
    ADD_OT_antitile,
    REMOVE_OT_antitile
)

#register, unregister = bpy.utils.register_classes_factory(classes)

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.useUniform = bpy.props.BoolProperty(name = "Uniform Shift and Random", default =False)

def unregister():
    from bpy.utils import unregister_class
    for cls in classes:
        unregister_class(cls)
    del bpy.types.Scene.useUniform
bl_info = {
    "name": "Object Painter",
    "author": "Titus Lavrov / Email: Titus.mailbox@gmail.com",
    "version": (0, 1, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Toolbar and View3D > ObjPainter",
    "warning": "",
    "description": "Simple object painter - allows to draw by selected objects on visible scene objects",
    "wiki_url": ""
                "",
    "category": "Object",
}


import bpy
from bpy.types import(Operator,
                      Menu,
                      Panel,
                      PropertyGroup,
                      AddonPreferences,
                      Gizmo,
                      )
from bpy.props import(BoolProperty,
                      EnumProperty,
                      FloatProperty,
                      IntProperty,
                      PointerProperty,
                      StringProperty,
                      )
from mathutils import Vector
import mathutils
import math
import random
# import bgl
import blf
from bpy_extras import view3d_utils

# Globals
PaintedObjs = []


def draw_callback_px(self, context):
    # print("mouse points", len(self.mouse_path))
    font_id = 0  # need to find out how best to get this.
    # draw some text
    blf.position(font_id, 15, 30, 0)
    blf.size(font_id, 15, 72)
    blf.draw(font_id, "Paint is on - RightMouseClick for deactivate")


def get_active_and_selected(self, context):
    active = context.view_layer.objects.active
    objects = []
    for ob in context.view_layer.objects.selected:
        if ob is not active:
            objects.append(ob)
    return active, objects


# Get object from selected objects
def get_random_obj_from_list(list):
    if len(list) != 0:
        obj = random.choice(list)
        return obj


# Calculate distance between raycasts
def calc_distance(step, old_loc, new_loc):
    distance = math.sqrt(((old_loc[0] - new_loc[0])**2) + ((old_loc[1] - new_loc[1])**2) + ((old_loc[2] - new_loc[2])**2))
    if step <= distance:
        return True
    else:
        return False


# Generate location
def gen_location(vec, min_x, max_x, min_y, max_y, min_z, max_z):
    x = random.uniform(min_x, max_x)
    y = random.uniform(min_y, max_y)
    z = random.uniform(min_z, max_z)
    new_vec = ((vec[0] + x), (vec[1] + y), (vec[2] + z))
    return new_vec


# Generate rotation
def gen_rotation(euler, min_rot_x, max_rot_x, min_rot_y, max_rot_y, min_rot_z, max_rot_z):
    x = euler[0] + (random.uniform(min_rot_x, max_rot_x))
    y = euler[1] + (random.uniform(min_rot_y, max_rot_y))
    z = euler[2] + (random.uniform(min_rot_z, max_rot_z))
    new_euler = mathutils.Euler((x, y, z), 'XYZ')
    return new_euler


# Generate scale
def gen_scale(scale, min_scale, max_scale):
    s = random.uniform(min_scale, max_scale)
    new_scale = ((scale[0] * s), (scale[1] * s), (scale[2] * s))
    return new_scale


# Main paint function and raycast calculations
def ObjectPaint(context, event):
    # get the context arguments
    scene = context.scene
    props = scene.OP_Properties
    # Step
    step = props.step
    # Location
    min_x = props.min_loc_X
    max_x = props.max_loc_X
    min_y = props.min_loc_Y
    max_y = props.max_loc_Y
    min_z = props.min_loc_Z
    max_z = props.max_loc_Z
    # Rotation
    min_rot_x = props.min_rot_X
    max_rot_x = props.max_rot_X
    min_rot_y = props.min_rot_Y
    max_rot_y = props.max_rot_Y
    min_rot_z = props.min_rot_Z
    max_rot_z = props.max_rot_Z
    # Scale
    min_scale = props.min_scale
    max_scale = props.max_scale
    # RayCast
    region = context.region
    rv3d = context.region_data
    coord = event.mouse_region_x, event.mouse_region_y
    view_layer = context.view_layer
    active_layer = view_layer.active_layer_collection
    # Initial location
    if len(PaintedObjs) != 0:
        init_pos = PaintedObjs[-1].location
    else:
        init_pos = (0, 0, 0)
    # get the ray from the viewport and mouse
    # Direction
    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    # Origin
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)

#   Scene.ray_cast(view_layer, origin, direction, distance=1.70141e+38)
#       result, boolean
#       location, The hit location of this ray cast, float array of 3 items in [-inf, inf]
#       normal, The face normal at the ray cast hit location, float array of 3 items in [-inf, inf]
#       index, The face index, -1 when original data isn’t available, int in [-inf, inf]
#       object, Ray cast object, Object
#       matrix, Matrix, float multi-dimensional array of 4 * 4 items in [-inf, inf]
    result, location, normal, index, object, matrix = scene.ray_cast(view_layer, ray_origin, view_vector, distance=1.70141e+38)
    # Paint
    if result and object not in PaintedObjs and calc_distance(step, init_pos, location):
        vec = mathutils.Vector(normal)
        new_vec = vec.to_track_quat('Z', 'Y')
        if len(bpy.context.view_layer.objects.selected) != 0:
            ob = get_random_obj_from_list(bpy.context.view_layer.objects.selected)
            new_ob = ob.copy()
            new_ob.data = ob.data.copy()
            new_ob.location = gen_location(location, min_x, max_x, min_y, max_y, min_z, max_z)
            new_ob.rotation_euler = gen_rotation((new_vec.to_euler()), min_rot_x, max_rot_x, min_rot_y, max_rot_y, min_rot_z, max_rot_z)
            new_ob.scale = gen_scale((new_ob.scale), min_scale, max_scale)
            PaintedObjs.append(new_ob)
            bpy.data.collections[active_layer.name].objects.link(new_ob)
            new_ob.select_set(False)


# Scatter
def ObjectScatter(context, target, source, count):
    active = target
    objects = source

    mesh = active.data
    polygons = mesh.polygons
    matrix = active.matrix_world.transposed()

    # get the context arguments
    scene = context.scene
    props = scene.OP_Properties
    # Step
    step = props.step
    # Location
    min_x = props.min_loc_X
    max_x = props.max_loc_X
    min_y = props.min_loc_Y
    max_y = props.max_loc_Y
    min_z = props.min_loc_Z
    max_z = props.max_loc_Z
    # Rotation
    min_rot_x = props.min_rot_X
    max_rot_x = props.max_rot_X
    min_rot_y = props.min_rot_Y
    max_rot_y = props.max_rot_Y
    min_rot_z = props.min_rot_Z
    max_rot_z = props.max_rot_Z
    # Scale
    min_scale = props.min_scale
    max_scale = props.max_scale

    view_layer = context.view_layer
    active_layer = view_layer.active_layer_collection

    for i in range(count):
        obj = get_random_obj_from_list(objects)
        face = random.choice(polygons)
        face_center = face.center
        location = face_center @ matrix
        vec = mathutils.Vector(face.normal)
        new_vec = vec.to_track_quat('Z', 'Y')

        new_ob = obj.copy()
        new_ob.data = obj.data.copy()
        new_ob.location = gen_location(location, min_x, max_x, min_y, max_y, min_z, max_z)
        new_ob.rotation_euler = gen_rotation((new_vec.to_euler()), min_rot_x, max_rot_x, min_rot_y, max_rot_y, min_rot_z, max_rot_z)
        new_ob.scale = gen_scale((new_ob.scale), min_scale, max_scale)

        bpy.data.collections[active_layer.name].objects.link(new_ob)
        new_ob.select_set(False) 


class OP_Properties(PropertyGroup):
    paint: BoolProperty(
        default=False,
        description="Start/Stop painting")
    step: FloatProperty(
        name="Distance",
        description="Distance between object",
        default=0.0,
        unit='LENGTH')
    min_loc_X: FloatProperty(
        name="min X",
        description="Min value for X axis",
        default=0.0,
        unit='LENGTH')
    max_loc_X: FloatProperty(
        name="max X",
        description="Max value for X axis",
        default=0.0,
        unit='LENGTH')
    min_loc_Y: FloatProperty(
        name="min Y",
        description="Min value for X axis",
        default=0.0,
        unit='LENGTH')
    max_loc_Y: FloatProperty(
        name="max Y",
        description="Max value for X axis",
        default=0.0,
        unit='LENGTH')
    min_loc_Z: FloatProperty(
        name="min Z",
        description="Min value for X axis",
        default=0.0,
        unit='LENGTH')
    max_loc_Z: FloatProperty(
        name="max Z",
        description="Max value for X axis",
        default=0.0,
        unit='LENGTH')
    min_rot_X: FloatProperty(
        name="min X",
        description="Min value for X axis",
        default=0.0,
        unit='ROTATION')
    max_rot_X: FloatProperty(
        name="max X",
        description="Max value for X axis",
        default=0.0,
        unit='ROTATION')
    min_rot_Y: FloatProperty(
        name="min Y",
        description="Min value for X axis",
        default=0.0,
        unit='ROTATION')
    max_rot_Y: FloatProperty(
        name="max Y",
        description="Max value for X axis",
        default=0.0,
        unit='ROTATION')
    min_rot_Z: FloatProperty(
        name="min Z",
        description="Min value for X axis",
        default=0.0,
        unit='ROTATION')
    max_rot_Z: FloatProperty(
        name="max Z",
        description="Max value for X axis",
        default=0.0,
        unit='ROTATION')
    min_scale: FloatProperty(
        name="min",
        description="Min scale",
        default=1.0,
        soft_min=0.0)
    max_scale: FloatProperty(
        name="max",
        description="Max scale",
        default=1.0,
        soft_min=0.0)
    # Scatter
    scatter_amount: IntProperty(
        name="Amount",
        description="Amount of scattered objects",
        default=25,
        soft_min=0)


class OP_OT_SCATTER_MODAL(Operator):
    """Simple scatter"""
    bl_idname = "object.simple_scatter"
    bl_label = "ObjectScatter"
    bl_options = {'REGISTER', 'UNDO'}

    scatter_amount: IntProperty(
        name="Amount",
        description="Amount of scattered objects",
        default=25,
        soft_min=0)

    def __init__(self):
        scene = bpy.context.scene
        props = scene.OP_Properties
        self.count = props.scatter_amount
        self.scatter_amount = self.count

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None and
                context.active_object.type is not 'MESH')

    def execute(self, context):
        scene = context.scene
        props = scene.OP_Properties
        count = props.scatter_amount
        # self.scatter_amount = count
        active, scatter = get_active_and_selected(self, context)
        # print ("Active name=", active.name)
        # print ("Scatter=", scatter)
        ObjectScatter(context, active, scatter, self.scatter_amount)
        return{"FINISHED"}


class OP_OT_PAINT_MODAL(Operator):
    """Simple object painter:\nallows to draw by selected objects on visible scene objects"""
    bl_idname = "object.painter"
    bl_label = "ObjectPainter"

    first_mouse_x: IntProperty()
    first_value: FloatProperty()

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None and
                context.active_object.type is not 'MESH')

    def modal(self, context, event):
        context.area.tag_redraw()
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE'}:
            # allow navigation
            return {'PASS_THROUGH'}
        if event.type == 'MOUSEMOVE':
            bpy.context.scene.OP_Properties.paint = True
            if self.lmb:
                delta = self.first_mouse_x - event.mouse_x
                ObjectPaint(context, event)
        elif event.type == 'LEFTMOUSE':
            # we could handle PRESS and RELEASE individually if necessary
            # bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            # bpy.context.scene.OP_Properties.paint = True
            bpy.context.scene.OP_Properties.paint = True
            self.lmb = event.value == 'PRESS'
            if self.lmb:
                delta = self.first_mouse_x - event.mouse_x
                ObjectPaint(context, event)
            return {'RUNNING_MODAL'}
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            bpy.context.scene.OP_Properties.paint = False
            PaintedObjs.clear()
            # bpy.context.scene.update()
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.space_data.type == 'VIEW_3D':
            # variable to remember left mouse button state
            self.lmb = bpy.context.scene.OP_Properties.paint
            self.first_mouse_x = event.mouse_x
            if context.area.type == 'VIEW_3D':
                # the arguments we pass the the callback
                args = (self, context)
                # Add the region OpenGL drawing callback
                # draw in view space with 'POST_VIEW' and 'PRE_VIEW'
                self._handle = bpy.types.SpaceView3D.draw_handler_add(draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
                context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "Active space must be a View3d")
            return {'CANCELLED'}


class VIEW3D_PT_OP(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'ObjPainter'
    bl_label = "ObjectPainter"

    def draw(self, context):
        layout = self.layout
        props = bpy.context.scene.OP_Properties

        col = layout.column(align=True)
        # Options
        box = col.box()
        col = box.column(align=True)
        col.label(text="Paint options:")
        col.prop(props, "step")

        col.label(text="Location:")
        row = col.row(align=True)
        row.prop(props, "min_loc_X")
        row.prop(props, "max_loc_X")
        row = col.row(align=True)
        row.prop(props, "min_loc_Y")
        row.prop(props, "max_loc_Y")
        row = col.row(align=True)
        row.prop(props, "min_loc_Z")
        row.prop(props, "max_loc_Z")

        col.label(text="Rotation:")
        row = col.row(align=True)
        row.prop(props, "min_rot_X")
        row.prop(props, "max_rot_X")
        row = col.row(align=True)
        row.prop(props, "min_rot_Y")
        row.prop(props, "max_rot_Y")
        row = col.row(align=True)
        row.prop(props, "min_rot_Z")
        row.prop(props, "max_rot_Z")

        col.label(text="Scale:")
        row = col.row(align=True)
        row.prop(props, "min_scale")
        row.prop(props, "max_scale")

        col = layout.column(align=True)
        col.scale_y = 2.0
        ico = 'RADIOBUT_ON' if props.paint else 'RADIOBUT_OFF'
        label = "Object paint ON" if props.paint else "Object paint"
        col.operator('object.painter', text=label, icon=ico)
        #col.prop(props, "paint", toggle = True)

        # Scatter
        col = layout.column(align=True)
        box = col.box()
        col = box.column(align=True)
        col.label(text="Scatter options:")
        col.prop(props, "scatter_amount")
        col.operator('object.simple_scatter', text="Scatter")

classes = (OP_OT_PAINT_MODAL,
           OP_OT_SCATTER_MODAL,
           VIEW3D_PT_OP,
           OP_Properties,
           )


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.OP_Properties = bpy.props.PointerProperty(type=OP_Properties)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.OP_Properties

if __name__ == "__main__":
    register()


import bpy

# TODO: rename this file to types.py


class OpFinishedException(Exception):
    pass

class OpCancelledException(Exception):
    pass

class OpAbortedException(Exception):
    pass


class UvPackerOpcode:
    REPORT_VERSION = 0
    PACK = 1
    OVERLAP_CHECK = 2
    MEASURE_AREA = 3
    VALIDATE_UVS = 4
    SELECT_SIMILAR = 5
    ALIGN_SIMILAR = 6

class UvPackMessageCode:
    PROGRESS_REPORT = 0
    INVALID_ISLANDS = 1
    VERSION = 2
    ISLAND_FLAGS = 3
    PACK_SOLUTION = 4
    AREA = 5
    INVALID_FACES = 6
    SIMILAR_ISLANDS = 7
    BENCHMARK = 8
    ISLANDS = 9

class UvPackerIslandFlags:
    OVERLAPS = 1

class UvPackerFeatureCode:
    DEMO = 0
    ISLAND_ROTATION = 1
    OVERLAP_CHECK = 2
    PACKING_DEPTH = 3
    HEURISTIC_SEARCH = 4
    PACK_RATIO = 5
    PACK_TO_OTHERS = 6
    GROUPED_PACK = 7
    LOCK_OVERLAPPING = 8
    ADVANCED_HEURISTIC = 9
    SELF_INTERSECT_PROCESSING = 10
    VALIDATION = 11
    MULTI_DEVICE_PACK = 12

class UvPackerErrorCode:
    SUCCESS = 0
    GENERAL_ERROR = 1
    INVALID_TOPOLOGY = 2
    NO_SPACE = 3
    NO_VALID_STATIC_ISLAND = 4
    UNEXPECTED_INVALID_TOPOLOGY = 5
    MAX_GROUP_COUNT_EXCEEDED = 6
    INCONSISTENT_ISLANDS = 7
    CANCELLED = 8
    PRE_VALIDATION_FAILED = 9

class UvPackingPhaseCode:
    INITIALIZATION = 0
    TOPOLOGY_ANALYSIS = 1
    PIXEL_MARGIN_ADJUSTMENT = 2
    PACKING = 3
    AREA_MEASUREMENT = 4
    OVERLAP_CHECK = 5
    RENDER_PRESENTATION = 6
    TOPOLOGY_VALIDATION = 7
    VALIDATION = 8
    SIMILAR_SELECTION = 9
    SIMILAR_ALIGNING = 10
    DONE = 100

class UvTopoAnalysisLevel:
    DEFAULT = 0
    EXTENDED = 1
    PROCESS_SELF_INTERSECT = 2
    FORCE_EXTENDED = 3

class UvGroupingMethod:
    MATERIAL = '0'
    SIMILARITY = '1'
    MESH = '2'
    OBJECT = '3'

class UvGroupingMethodCore:
    EXTERNAL = 0
    SIMILARITY = 1

class UvMapSerializationFlags:
    CONTAINS_FLAGS = 1
    CONTAINS_GROUPS = 2

class UvFaceInputFlags:
    SELECTED = 1

class UvDeviceFlags:
    SUPPORTED = 1
    SUPPORTS_GROUPED_PACK = 2




import platform
import multiprocessing
import subprocess

from .prefs import *
from .version import UvpVersionInfo
from .os_iface import *

from .enums import *
from .utils import *
from .connection import *



def platform_check():
    err_msg = 'Unsupported platform detected. Supported platforms are Linux 64 bit, Windows 64 bit'

    sys = platform.system()
    if sys != 'Linux' and sys != 'Windows' and sys != 'Darwin':
        return False, err_msg

    is_64bit = platform.machine().endswith('64')
    if not is_64bit:
        return False, err_msg

    return True, ''


def get_packer_version():
    packer_args = [get_packer_path(), '-E', '-o', str(UvPackerOpcode.REPORT_VERSION)]
    packer_proc = subprocess.Popen(packer_args, stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    try:
        packer_proc.wait(5)
    except:
        packer_proc.terminate()
        raise

    in_stream = packer_proc.stdout

    version_msg = None
    while True:
        msg = connection_rcv_message(in_stream)
        msg_code = force_read_int(msg)

        if msg_code == UvPackMessageCode.VERSION:
            version_msg = msg
            break

    if version_msg is None:
        raise RuntimeError('Could not read the packer version')

    # TODO: make sure this won't block
    version_major = force_read_int(version_msg)
    version_minor = force_read_int(version_msg)
    version_patch = force_read_int(version_msg)
    version_suffix = struct.unpack('c', version_msg.read(1))[0].decode('ascii')

    feature_cnt = struct.unpack('i', version_msg.read(4))[0]
    feature_codes = []

    for i in range(feature_cnt):
        feature_codes.append(struct.unpack('c', version_msg.read(1))[0])

    dev_cnt = force_read_int(version_msg)
    devices = []

    for i in range(dev_cnt):
        id_length = force_read_int(version_msg)
        id = version_msg.read(id_length).decode('ascii')

        name_length = force_read_int(version_msg)
        name = version_msg.read(name_length).decode('ascii')

        dev_flags = force_read_int(version_msg)
        devices.append((id, name, dev_flags))

    core_version = (version_major, version_minor, version_patch)
    return core_version, version_suffix, feature_codes, devices


def parse_feature_codes(feature_codes):
    prefs = get_prefs()

    prefs.FEATURE_demo = False
    prefs.FEATURE_island_rotation = False
    prefs.FEATURE_overlap_check = False
    prefs.FEATURE_packing_depth = False
    prefs.FEATURE_heuristic_search = False
    prefs.FEATURE_pack_ratio = False
    prefs.FEATURE_pack_to_others = False
    prefs.FEATURE_grouped_pack = False
    prefs.FEATURE_lock_overlapping = False
    prefs.FEATURE_advanced_heuristic = False
    prefs.FEATURE_self_intersect_processing = False
    prefs.FEATURE_validation = False
    prefs.FEATURE_multi_device_pack = False

    for code in feature_codes:
        int_code = int.from_bytes(code, 'little')
        if int_code == UvPackerFeatureCode.DEMO:
            prefs.FEATURE_demo = True
        elif int_code == UvPackerFeatureCode.ISLAND_ROTATION:
            prefs.FEATURE_island_rotation = True
        elif int_code == UvPackerFeatureCode.OVERLAP_CHECK:
            prefs.FEATURE_overlap_check = True
        elif int_code == UvPackerFeatureCode.PACKING_DEPTH:
            prefs.FEATURE_packing_depth = True
        elif int_code == UvPackerFeatureCode.HEURISTIC_SEARCH:
            prefs.FEATURE_heuristic_search = True
        elif int_code == UvPackerFeatureCode.PACK_RATIO:
            prefs.FEATURE_pack_ratio = True
        elif int_code == UvPackerFeatureCode.PACK_TO_OTHERS:
            prefs.FEATURE_pack_to_others = True
        elif int_code == UvPackerFeatureCode.GROUPED_PACK:
            prefs.FEATURE_grouped_pack = True
        elif int_code == UvPackerFeatureCode.LOCK_OVERLAPPING:
            prefs.FEATURE_lock_overlapping = True
        elif int_code == UvPackerFeatureCode.ADVANCED_HEURISTIC:
            prefs.FEATURE_advanced_heuristic = True
        elif int_code == UvPackerFeatureCode.SELF_INTERSECT_PROCESSING:
            prefs.FEATURE_self_intersect_processing = True
        elif int_code == UvPackerFeatureCode.VALIDATION:
            prefs.FEATURE_validation = True
        elif int_code == UvPackerFeatureCode.MULTI_DEVICE_PACK:
            prefs.FEATURE_multi_device_pack = True


def reset_debug_params(prefs):
    prefs.write_to_file = False
    prefs.simplify_disable = False
    prefs.seed = 0


def register_specific(bl_info):

    prefs = get_prefs()
    prefs.enabled = True

    prefs.platform_supported = True
    prefs.not_supported_message = ''
    prefs.label_message = ''
    prefs.thread_count = multiprocessing.cpu_count()
    reset_stats(prefs)
    reset_debug_params(prefs)

    result, err_msg = platform_check()
    if not result:
        prefs.platform_supported = False
        prefs.not_supported_message = err_msg
    else:
        result, err_msg = os_platform_check(get_packer_path())
        if not result:
            prefs.platform_supported = False
            prefs.not_supported_message = err_msg

    if not prefs.platform_supported:
        prefs.label_message = prefs.not_supported_message
        return

    try:
        if bl_info['version'] != UvpVersionInfo.addon_version_tuple():
            raise RuntimeError("Addon versions from version and init file do not match")

        core_version, version_suffix, feature_codes, devices = get_packer_version()

        if core_version != UvpVersionInfo.core_version_tuple():
            raise RuntimeError('Unexpected packer version detected')

        edition_array = UvpVersionInfo.packer_edition_array()
        edition_array_tmp = [edition_info for edition_info in edition_array if edition_info.suffix == version_suffix]
        if len(edition_array_tmp) != 1:
            raise RuntimeError('Unexpected number of editions found')

        edition_long_name = edition_array_tmp[0].long_name

        prefs.label_message = 'Packer version: {} ({})'.format(UvpVersionInfo.addon_version_release_string(), edition_long_name)
        parse_feature_codes(feature_codes)
        prefs.dev_array.clear()

        if len(devices) == 0 or devices[0][0] != 'cpu':
            raise RuntimeError('No expected default device found')

        prefs.sel_dev_idx = 0
        prefs.supported_dev_count = 0

        for dev in devices:
            dev_prop = prefs.dev_array.add()
            dev_prop.id = dev[0]
            dev_prop.name = dev[1]

            dev_flags = dev[2]
            dev_prop.supported = (dev_flags & UvDeviceFlags.SUPPORTED) > 0
            dev_prop.supports_grouped_pack = (dev_flags & UvDeviceFlags.SUPPORTS_GROUPED_PACK) > 0

            if dev_prop.supported:
                prefs.supported_dev_count += 1

    except Exception as ex:
        if in_debug_mode():
            print_backtrace(ex)

        prefs.platform_supported = False
        prefs.not_supported_message = 'Unexpected error'
        prefs.label_message = 'Unexpected error'
      
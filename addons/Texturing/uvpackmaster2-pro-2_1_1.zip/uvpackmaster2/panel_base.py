
import multiprocessing

from .prefs import get_prefs
from .operator import *
from .utils import *

from .labels import UvpLabels


import bpy

class UVP2_UL_DeviceList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        dev_name = str(item.name)

        row = layout.row()
        if not item.supported:
            dev_name += ' ' + UvpLabels.FEATURE_NOT_SUPPORTED_MSG
            row.enabled = False
        
        row.label(text=dev_name)


class UVP2_PT_MainBase(bpy.types.Panel):
    bl_idname = 'UVP2_PT_MainBase'
    bl_label = 'UVPackmaster2'
    bl_context = ''

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()

        layout.label(text=prefs.label_message)

        if in_debug_mode():
            col = layout.column(align=True)

            col.label(text="Debug options:")
            col.prop(prefs, "write_to_file")
            col.prop(prefs, "simplify_disable")
            col.prop(prefs, "wait_for_debugger")
            col.prop(prefs, "seed")
            col.prop(prefs, "test_param")

class UVP2_PT_PackingDeviceBase(bpy.types.Panel):
    bl_label = 'Packing Device'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}


    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)

        col.template_list("UVP2_UL_DeviceList", "", prefs, "dev_array",
                          prefs, "sel_dev_idx")

class UVP2_PT_BasicOptionsBase(bpy.types.Panel):
    bl_label = 'Basic Options'
    bl_context = ''

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)

        col.prop(prefs, "thread_count")
        col.prop(context.scene.uvp2_props, "margin")
        col.prop(context.scene.uvp2_props, "precision")

        # Rotation Resolution
        box = col.box()
        box.enabled = prefs.FEATURE_island_rotation

        row = box.row()
        
        if not prefs.FEATURE_island_rotation:
            row.prop(prefs, "DISABLED_rot_enable")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "rot_enable")

        row = box.row()
        row.enabled = context.scene.uvp2_props.rot_enable
        row.prop(context.scene.uvp2_props, "prerot_disable")

        row = col.row(align=True)
        row.enabled = context.scene.uvp2_props.rot_enable
        row.prop(context.scene.uvp2_props, "rot_step")

        # Post scale disable
        box = col.box()
        row = box.row()
        row.prop(context.scene.uvp2_props, "postscale_disable")

        # Overlap check
        box = col.box()
        box.enabled = prefs.FEATURE_overlap_check
        row = box.row()
        
        if not prefs.FEATURE_overlap_check:
            row.prop(prefs, "DISABLED_overlap_check")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "overlap_check")

        # Area measure
        box = col.box()
        row = box.row()
        row.prop(context.scene.uvp2_props, "area_measure")

        # Pre validate
        pre_validate_name = UvpLabels.PRE_VALIDATE_NAME
        if prefs.FEATURE_demo:
            pre_validate_name += ' (DEMO)'

        box = col.box()
        box.enabled = prefs.FEATURE_validation
        row = box.row()
        
        if not prefs.FEATURE_validation:
            row.prop(prefs, "DISABLED_pre_validate", text=pre_validate_name)
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "pre_validate", text=pre_validate_name)


class UVP2_PT_HeuristicBase(bpy.types.Panel):
    bl_label = 'Heuristic'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)

        # Heuristic search
        box = col.box()
        box.enabled = prefs.FEATURE_heuristic_search

        row = box.row()
    
        if not prefs.FEATURE_heuristic_search:
            row.prop(prefs, "DISABLED_heuristic_enable")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "heuristic_enable")

        # Advanced Heuristic
        box = col.box()
        box.enabled = prefs.FEATURE_advanced_heuristic and context.scene.uvp2_props.heuristic_enable
        row = box.row()
        
        if not prefs.FEATURE_advanced_heuristic:
            row.prop(prefs, "DISABLED_advanced_heuristic")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "advanced_heuristic")

        # Multi device
        box = col.box()
        box.enabled = prefs.FEATURE_multi_device_pack and context.scene.uvp2_props.heuristic_enable

        row = box.row()
        
        if not prefs.FEATURE_multi_device_pack:
            row.prop(prefs, "DISABLED_multi_device_pack")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "multi_device_pack")


class UVP2_PT_NonSquarePackingBase(bpy.types.Panel):
    bl_label = 'Non-Square Packing'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)

        # Tex ratio
        box = col.box()
        box.enabled = prefs.FEATURE_pack_ratio
        row = box.row()
        
        if not prefs.FEATURE_pack_ratio:
            row.prop(prefs, "DISABLED_tex_ratio")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "tex_ratio")

        col.separator()
        row = col.row(align=True)
        row.operator(UVP2_OT_AdjustIslandsToTexture.bl_idname)
        row.operator(UVP2_OT_NonSquarePackingHelp.bl_idname, icon='HELP', text='')

        row = col.row(align=True)
        row.operator(UVP2_OT_UndoIslandsAdjustemntToTexture.bl_idname)

class UVP2_PT_AdvancedOptionsBase(bpy.types.Panel):
    bl_label = 'Advanced Options'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        demo_suffix = " (DEMO)" if prefs.FEATURE_demo else ''
        col = layout.column(align=True)

        # Pack to others
        box = col.box()
        box.enabled = prefs.FEATURE_pack_to_others
        row = box.row()
        
        if not prefs.FEATURE_pack_to_others:
            row.prop(prefs, "DISABLED_pack_to_others")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "pack_to_others")

        # Lock overlapping
        box = col.box()
        box.enabled = prefs.FEATURE_lock_overlapping
        row = box.row()
        
        if not prefs.FEATURE_lock_overlapping:
            row.prop(prefs, "DISABLED_lock_overlapping")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
        else:
            row.prop(context.scene.uvp2_props, "lock_overlapping")

        # Grouped pack
        box = col.box()
        box.enabled = True
        row = box.row()
        

        if not prefs.FEATURE_grouped_pack:
            row.prop(prefs, "DISABLED_grouped_pack")
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)
            box.enabled = False
        else:
            row.prop(context.scene.uvp2_props, "grouped_pack")

        row = box.row()
        row.prop(context.scene.uvp2_props, "group_method")
        row.enabled = context.scene.uvp2_props.grouped_pack

        # Similarity threshold
        row = col.row(align=True)
        row.prop(context.scene.uvp2_props, "similarity_threshold")
        row.operator(UVP2_OT_SimilarityDetectionHelp.bl_idname, icon='HELP', text='')
            
        row = col.row(align=True)
        row.operator(UVP2_OT_SelectSimilarOperator.bl_idname, text=UVP2_OT_SelectSimilarOperator.bl_label + demo_suffix)

        row = col.row(align=True)
        row.operator(UVP2_OT_AlignSimilarOperator.bl_idname, text=UVP2_OT_AlignSimilarOperator.bl_label + demo_suffix)

        col.separator()
        col.label(text='Pixel Margin Options:')

        # Pixel margin
        row = col.row(align=True)
        row.prop(context.scene.uvp2_props, "pixel_margin")
        row.operator(UVP2_OT_PixelMarginHelp.bl_idname, icon='HELP', text='')

        # Pixel Margin Adjust Time
        row = col.row(align=True)
        row.prop(context.scene.uvp2_props, "pixel_margin_adjust_time")

        # Pixel Margin Tex Size
        row = col.row(align=True)
        row.prop(context.scene.uvp2_props, "pixel_margin_tex_size")

        if (prefs.FEATURE_pack_ratio and context.scene.uvp2_props.tex_ratio):
            row.enabled = False
            col.label(text='Active texture dimensions are used to calculate pixel margin', icon='ERROR')


class UVP2_PT_OperatorsBase(bpy.types.Panel):
    bl_label = 'Operators'
    bl_context = ''

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        demo_suffix = " (DEMO)" if prefs.FEATURE_demo else ''

        col = layout.column(align=True)

        row = col.row(align=True)
        row.enabled = prefs.FEATURE_overlap_check
        # row = box.row()
        row.operator(UVP2_OT_OverlapCheckOperator.bl_idname)
        if not prefs.FEATURE_overlap_check:
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)

        col.operator(UVP2_OT_MeasureAreaOperator.bl_idname)

        # Validate operator

        row = col.row(align=True)
        row.enabled = prefs.FEATURE_validation

        row.operator(UVP2_OT_ValidateOperator.bl_idname, text=UVP2_OT_ValidateOperator.bl_label + demo_suffix)
        if not prefs.FEATURE_validation:
            row.label(text=UvpLabels.FEATURE_NOT_SUPPORTED_MSG)

        row = col.row(align=True)
        row.scale_y = 1.75

        row.operator(UVP2_OT_PackOperator.bl_idname, text=UVP2_OT_PackOperator.bl_label + demo_suffix)


class UVP2_PT_WarningsBase(bpy.types.Panel):
    bl_label = 'Warnings'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)

        active_dev = prefs.dev_array[prefs.sel_dev_idx] if prefs.sel_dev_idx < len(prefs.dev_array) else None
        warnings = []

        if prefs.thread_count < multiprocessing.cpu_count():
            warnings.append('Thread Count value is lower than the number of cores in your system - consider increasing that parameter in order to increase packer speed')

        if not context.scene.uvp2_props.rot_enable:
            warnings.append('Packing is not optimal for most UV maps with island rotations disabled. Disable rotations only when packing a UV map with a huge number of small islands')

        if prefs.FEATURE_island_rotation and context.scene.uvp2_props.prerot_disable:
            warnings.append('Pre-rotation usually optimizes packing, disable it only if you have a good reason')

        if context.scene.uvp2_props.postscale_disable:
            warnings.append("When the 'Post-Scaling Disable' option is on, islands won't be adjusted to fit the unit UV square after packing is done")

        if prefs.FEATURE_pack_ratio:
            try:
                ratio = get_active_image_ratio(context)

                if not context.scene.uvp2_props.tex_ratio and ratio != 1.0:
                    warnings.append("The active texture is non-square, but the 'Use Texture Ratio' option is disabled. Did you forget to enable it?")

                if context.scene.uvp2_props.tex_ratio and ratio < 1.0:
                    warnings.append('Packing is slower when packing into a vertically oriented texture. Consider changing the texture orientation')
            except:
                pass

        if context.scene.uvp2_props.pixel_margin > 0 and not context.scene.uvp2_props.pack_to_others and not context.scene.uvp2_props.postscale_disable and not context.scene.uvp2_props.heuristic_enable:
            warnings.append("The 'Pixel Margin' option is used, but heuristic search is disabled. The pixel margin fuctionality requires heuristic search in order to work properly in a general case. See the Help panel for more info")

        for warn in warnings:
            box = col.box()

            warn_split = split_by_chars(warn, 40)
            if len(warn_split) > 0:
                box.separator()
                for warn_part in warn_split:
                    box.label(text=warn_part)
                box.separator()


class UVP2_PT_StatisticsBase(bpy.types.Panel):
    bl_label = 'Statistics'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs()
        col = layout.column(align=True)
        col.label(text='Last operation statistics:')
        col.separator()

        if prefs.stats_area >= 0.0:
            box = col.box()
            box.label(text='Area: ' + str(round(prefs.stats_area, 3)))

        for idx, stats in enumerate(prefs.stats_array):
            col.separator()
            col.label(text='Packing device ' + str(idx) + ':')
            box = col.box()
            box.label(text='Iteration count: ' + str(stats.iter_count))

            box = col.box()
            box.label(text='Total packing time: ' + str(stats.total_time))

            box = col.box()
            box.label(text='Average iteration time: ' + str(stats.avg_time) + ' ms')

class UVP2_PT_HelpBase(bpy.types.Panel):
    bl_label = 'Help'
    bl_context = ''
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=True)

        row = col.row(align=True)
        row.operator(UVP2_OT_InvalidTopologyHelp.bl_idname, icon='HELP', text='Invalid Topology')
        row = col.row(align=True)
        row.operator(UVP2_OT_NonSquarePackingHelp.bl_idname, icon='HELP', text='Non-Square Packing')
        row = col.row(align=True)
        row.operator(UVP2_OT_SimilarityDetectionHelp.bl_idname, icon='HELP', text='Similarity Detection')
        row = col.row(align=True)
        row.operator(UVP2_OT_PixelMarginHelp.bl_idname, icon='HELP', text='Pixel Margin')


class UvpEditionInfo:
    suffix = None
    name = None
    long_name = None
    marker = None

    def __init__(self, _num, _suffix, _name, _long_name, _marker, _req_markers):
        self.num = _num
        self.suffix = _suffix
        self.name = _name
        self.long_name = _long_name
        self.marker = _marker
        self.req_markers = _req_markers


class UvpVersionInfo:
    ADDON_VERSION_MAJOR = 2
    ADDON_VERSION_MINOR = 1
    ADDON_VERSION_PATCH = 1

    CORE_VERSION_MAJOR = 2
    CORE_VERSION_MINOR = 1
    CORE_VERSION_PATCH = 0

    RELEASE_SUFFIX = 'blend2.8'

    @classmethod
    def release_suffix(cls):
        return cls.RELEASE_SUFFIX

    @classmethod
    def addon_version_tuple(cls):
        return (cls.ADDON_VERSION_MAJOR, cls.ADDON_VERSION_MINOR, cls.ADDON_VERSION_PATCH)

    @classmethod
    def addon_version_string(cls):
        return '{}.{}.{}'.format(cls.ADDON_VERSION_MAJOR, cls.ADDON_VERSION_MINOR, cls.ADDON_VERSION_PATCH)

    @classmethod
    def addon_version_release_string(cls):
        version_str = cls.addon_version_string()
        release_str = cls.release_suffix()

        return version_str if release_str == '' else (version_str + '-' + release_str)

    @classmethod
    def core_version_tuple(cls):
        return (cls.CORE_VERSION_MAJOR, cls.CORE_VERSION_MINOR, cls.CORE_VERSION_PATCH)

    @classmethod
    def core_version_string(cls):
        return '{}.{}.{}'.format(cls.CORE_VERSION_MAJOR, cls.CORE_VERSION_MINOR, cls.CORE_VERSION_PATCH)

    @classmethod
    def packer_edition_array(cls):
        edition_array = [
            UvpEditionInfo(1, 's', 'std', 'standard', 'UVP_EDITION_STANDARD', []),
            UvpEditionInfo(2, 'p', 'pro', 'professional', 'UVP_EDITION_PRO', ['UVP_FEATURE_CUDA']),
            UvpEditionInfo(3, 'd', 'demo', 'DEMO', 'UVP_EDITION_DEMO', ['UVP_FEATURE_CUDA'])
        ]

        return edition_array





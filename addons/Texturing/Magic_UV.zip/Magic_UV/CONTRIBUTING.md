# Contribution

If you want to contribute this project, please send pull request to **develop** branch.
**DO NOT** send pull request to **master** branch.  

https://github.com/nutti/Magic-UV/tree/develop

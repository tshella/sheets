# Bug Report / Feature Request / Disscussions

If you want to report problem or request feature, please make issues.

https://github.com/nutti/Magic-UV/issues

You can discuss Magic UV at other places.
See the link below for further details.

* [Blender Wiki page](https://en.blender.org/index.php/Extensions:2.6/Py/Scripts/UV/Magic_UV)
* [Blender Artist](https://blenderartists.org/t/magic-uv/1134694)
* [Google+](https://plus.google.com/100058529622539760372/posts/82eS2tGE6Nc)

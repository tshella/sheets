import numpy as np
from math import radians

import bpy
import bmesh

from bpy.props import BoolProperty
from bpy.types import Operator

from ..utils.uv_utils import (
    get_bbox,
    calc_bbox_center,
    universal_rotation_matrix,
    get_objects_seams,
    get_islands,
)


class RotateIslands(Operator):
    bl_idname = "uv.toolkit_rotate_islands"
    bl_label = "Rotate islands"
    bl_description = "Rotate the selected islands"
    bl_options = {'REGISTER', 'UNDO'}

    cw: BoolProperty(
        default=True,
        options={'HIDDEN'},
    )
    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        scene = context.scene
        if scene.tool_settings.use_uv_select_sync:
            self.report({'INFO'}, "Need to disable UV Sync")
            return {'CANCELLED'}

        angle = radians(scene.uv_toolkit.island_rotation_angle)
        objects_seams = get_objects_seams(context)
        if self.cw:
            angle = angle * -1
        if scene.uv_toolkit.island_rotation_mode == "LOCAL":
            for ob in context.objects_in_mode_unique_data:
                seams = objects_seams[ob]
                me = ob.data
                bm = bmesh.from_edit_mesh(me)
                uv = bm.loops.layers.uv.verify()

                for island in get_islands(uv, bm, seams, has_selected_faces=True):
                    bbox = get_bbox(uv, island)
                    pivot = calc_bbox_center(bbox)
                    rotation = universal_rotation_matrix(context, angle, pivot)
                    for f in island:
                        for l in f.loops:
                            u, v = l[uv].uv
                            l[uv].uv = rotation.dot(np.array([u, v, 1]))[:2]

        if scene.uv_toolkit.island_rotation_mode == "GLOBAL":
            space_data = context.space_data
            initial_cursor_position = tuple(space_data.cursor_location)
            bpy.ops.uv.snap_cursor(target='SELECTED')
            pivot = tuple(space_data.cursor_location)
            space_data.cursor_location = initial_cursor_position

            rotation = universal_rotation_matrix(context, angle, pivot)

            for ob in context.objects_in_mode_unique_data:
                seams = objects_seams[ob]
                me = ob.data
                bm = bmesh.from_edit_mesh(me)
                uv = bm.loops.layers.uv.verify()

                for f in bm.faces:
                    for l in f.loops:
                        if l[uv].select:
                            u, v = l[uv].uv
                            l[uv].uv = rotation.dot(np.array([u, v, 1]))[:2]
        bmesh.update_edit_mesh(me)
        return {'FINISHED'}

from math import radians

import bpy
import bmesh
from bpy.types import Operator
from bpy.props import FloatProperty, EnumProperty, BoolProperty


class LazyUnwrap(Operator):
    bl_idname = "uv.toolkit_lazy_unwrap"
    bl_label = "Lazy Unwrap"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    angle: FloatProperty(
        name="Seams by Angle",
        precision=1,
        default=90,
        min=0,
    )
    method: EnumProperty(
        name="Method",
        items=[
            ("ANGLE_BASED", "Angle Based", ""),
            ("CONFORMAL", "Conformal", ""),
        ]
    )
    fill_holes: BoolProperty(
        name="Fill Holes",
        default=True,
    )
    correct_aspect: BoolProperty(
        name="Correct Aspect",
        default=True,
    )
    use_subsurf_data: BoolProperty(
        name="Use Subdivision Surface",
        default=False,
    )
    margin: FloatProperty(
        name="Margin",
        precision=3,
        min=0,
    )
    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        scene = context.scene
        if scene.tool_settings.use_uv_select_sync:
            self.report({'INFO'}, "Need to disable UV Sync")
            return {'CANCELLED'}

        epsilon = 0.0008726646
        angle = radians(self.angle)

        for ob in context.objects_in_mode_unique_data:
            me = ob.data
            bm = bmesh.from_edit_mesh(me)

            for e in bm.edges:
                if e.select:
                    e.seam = False
                    face_angle = e.calc_face_angle(None)

                    if face_angle:
                        if abs(angle - face_angle) < epsilon:
                            e.seam = True
            bmesh.update_edit_mesh(me)

        bpy.ops.uv.unwrap(method=self.method,
                          fill_holes=self.fill_holes,
                          correct_aspect=self.correct_aspect,
                          use_subsurf_data=self.use_subsurf_data,
                          margin=self.margin)
        return {'FINISHED'}

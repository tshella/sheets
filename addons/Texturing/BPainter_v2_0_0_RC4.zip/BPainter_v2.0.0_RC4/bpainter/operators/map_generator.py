'''
Copyright (C) 2017 Andreas Esau
andreasesau@gmail.com

Created by Andreas Esau

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
from mathutils import Vector
from bpy.props import StringProperty, EnumProperty, IntVectorProperty, BoolProperty, IntProperty
from bpy.types import Menu, Panel, UIList
from .. functions import is_paint_channel_node, get_paint_channels
import os
from collections import OrderedDict

cb = ["BP_AO","BP_NORMAL","BP_CURVATURE", "BP_GLOSSY", "BP_SUBSURFACE"] # cycles bake types

class BPAINTER_OT_AddHighPolyObject(bpy.types.Operator):
    bl_idname = "b_painter.add_high_poly_object"
    bl_label = "Add High Poly Object"
    bl_description = ""
    bl_options = {"REGISTER"}

    export_item_name: StringProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        scene = context.scene

        for obj in context.selected_objects:
            export_item = scene.b_painter_export_list[self.export_item_name]
            item = export_item.high_poly_objs.add()
            item.high_poly_obj = obj
        return {"FINISHED"}

class BPAINTER_OT_AddInternalImage(bpy.types.Operator):
    bl_idname = "b_painter.add_internal_image"
    bl_label = "Add Internal Image"
    bl_description = ""
    bl_options = {"REGISTER"}

    img_name: StringProperty()
    index: IntProperty()

    @classmethod
    def poll(cls, context):
        return True

    def draw(self,context):
        row = self.layout
        row.prop(self,"img_name",text="Name")

    def invoke(self,context,event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        export_item = context.scene.b_painter_export_list[self.index]

        img = bpy.data.images.new(self.img_name,width=export_item.resolution_x,height=export_item.resolution_y, alpha=True)

        export_item.internal_image = img.name
        return {"FINISHED"}


class BPAINTER_OT_RemoveHighPolyObject(bpy.types.Operator):
    bl_idname = "b_painter.remove_high_poly_object"
    bl_label = "Add High Poly Object"
    bl_description = ""
    bl_options = {"REGISTER"}

    export_item_name: StringProperty()
    index: IntProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        scene = context.scene

        export_item = scene.b_painter_export_list[self.export_item_name]
        export_item.high_poly_objs.remove(self.index)
        return {"FINISHED"}

class BPAINTER_UL_ExportSlot(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        parent = layout.column()
        box = parent.box()
        col = box.column()

        row1 = col.row(align=True)
        icon = "TRIA_RIGHT" if item.expand == False else "TRIA_DOWN"
        row1.prop(item,"expand",text="",emboss=False,icon=icon)
        row1.prop(item,"export",text="")
        row1.prop(item,"name",text="")
        #row1.prop(item,"keep_internal",text="Keep Internal")
        row1.prop(item,"save_mode",text="")

        op = row1.operator("b_painter.remove_channel_export",text="",icon="X")
        op.index = index

        if item.expand:
            row2 = col.row()
            row2.prop(item,"export_type",expand=True)

            if item.export_type == "GRAY":
                col1 = col.column()
                col1.prop(item,"gray",text="Gray",icon="IMAGE_ALPHA")
            elif item.export_type == "RGB":
                col1 = col.column()
                col1.prop(item,"rgb",text="RGB",icon="COLOR")
            elif item.export_type == "R+G+B":
                col1 = col.column()
                col1.prop(item,"r",text="R",icon="COLOR_RED")
                col1.prop(item,"g",text="G",icon="COLOR_GREEN")
                col1.prop(item,"b",text="B",icon="COLOR_BLUE")
            elif item.export_type == "RGB+A":
                col1 = col.column()
                col1.prop(item,"rgb",text="RGB",icon="COLOR")
                col1.prop(item,"a",text="A",icon="IMAGE_ALPHA")
            elif item.export_type == "R+G+B+A":
                col1 = col.column()
                col1.prop(item,"r",text="R",icon="COLOR_RED")
                col1.prop(item,"g",text="G",icon="COLOR_GREEN")
                col1.prop(item,"b",text="B",icon="COLOR_BLUE")
                col1.prop(item,"a",text="A",icon="IMAGE_ALPHA")

            row = box.split(factor=.33)
            row.label(text="Resolution")
            col = row.column(align=True)
            col.prop(item,"resolution_x")
            col.prop(item,"resolution_y")

            col = box.column()
            col.separator()
            #cb = ["BP_CYCLES_AO","BP_CYCLES_NORMAL"] # cycles bake types

            global cb # cycles bake types
            gray_cycles = item.export_type == "GRAY" and item.gray in cb
            rgb_cycles = item.export_type == "RGB" and item.rgb in cb
            rgb_a_cycles = item.export_type == "RGB+A" and (item.rgb in cb or item.a in cb)
            r_g_b_cycles = item.export_type == "R+G+B" and (item.r in cb or item.g in cb or item.b in cb)
            r_g_b_a_cycles = item.export_type == "R+G+B+A" and (item.r in cb or item.g in cb or item.b in cb or item.a in cb)

            visible_export_channels = []
            if item.export_type == "GRAY":
                visible_export_channels.append(item.gray)
            elif item.export_type == "RGB":
                visible_export_channels.append(item.rgb)
            elif item.export_type == "RGB+A":
                visible_export_channels.append(item.rgb)
                visible_export_channels.append(item.a)
            elif item.export_type == "R+G+B":
                visible_export_channels.append(item.r)
                visible_export_channels.append(item.g)
                visible_export_channels.append(item.b)
            elif item.export_type == "R+G+B+A":
                visible_export_channels.append(item.r)
                visible_export_channels.append(item.g)
                visible_export_channels.append(item.b)
                visible_export_channels.append(item.a)

            #if item.rgb in cb or item.r in cb or item.g in cb or item.b in cb or item.gray in cb or item.a in cb:
            if True:#gray_cycles or rgb_cycles or rgb_a_cycles or r_g_b_cycles or r_g_b_a_cycles:
                show_ao_settings = False
                show_normal_settings = False
                for channel in visible_export_channels:
                    if channel == "BP_AO":
                        show_ao_settings = True
                    elif channel == "BP_NORMAL":
                        show_normal_settings = True

                if show_ao_settings or show_normal_settings:
                    col.label(text="Cycles Bake Settings:")

                if show_ao_settings:
                    col.prop(item,"ao_samples",text="Samples")

                if show_normal_settings:
                    col.prop(item,"normal_space",text="Space")
                    subrow = col.split(factor=.335, align=True)
                    subrow.label(text="Swizzle:")
                    subrow.prop(item,"normal_r",text="")
                    subrow.prop(item,"normal_g",text="")
                    subrow.prop(item,"normal_b",text="")

                if item.save_mode == "INTERNAL":
                    #col.prop(item,"internal_image")
                    split = box.split(factor=.33)
                    col1 = split.column()
                    col1.label(text="Image:")

                    col2 = split.column()
                    row = col2.row(align = True)
                    row.prop_search(item,"internal_image",bpy.data,"images",icon="IMAGE_DATA",text="")
                    op = row.operator("b_painter.add_internal_image",text="",icon="ADD")
                    op.index = index

                col = box.column()
                col.prop(item,"low_poly_obj",text="Target Object")
                if item.low_poly_obj != None and item.low_poly_obj.type == "MESH":
                    col.prop_search(item, "target_uv", item.low_poly_obj.data, "uv_layers", icon="GROUP_UVS", text="Target UV")

                split = box.split(factor=.33)
                col = split.column()
                col.label(text="Source Objects:")

                col = split.column()
                op = col.operator("b_painter.add_high_poly_object",text="",icon="ADD")
                op.export_item_name = item.name
                for i,high_poly_obj in enumerate(item.high_poly_objs):
                    row = col.row(align=True)
                    row.prop(high_poly_obj,"high_poly_obj",text="")
                    op = row.operator("b_painter.remove_high_poly_object",text="",icon="REMOVE")
                    op.export_item_name = item.name
                    op.index = i


        row = parent.row()

class BPAINTER_OT_RemoveChannelExport(bpy.types.Operator):
    bl_idname = "b_painter.remove_channel_export"
    bl_label = "Remove Channel Export"
    bl_description = ""
    bl_options = {"REGISTER"}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        context.scene.b_painter_export_list.remove(self.index)
        return {"FINISHED"}


class BPAINTER_OT_AddChannelExport(bpy.types.Operator):
    bl_idname = "b_painter.add_export_map"
    bl_label = "Add Channel Export"
    bl_description = ""
    bl_options = {"REGISTER"}

    #paint_channel: EnumProperty(name="Paint Channel",items=get_paint_channels)
    name: StringProperty()

    @classmethod
    def poll(cls, context):
        return True

    def draw(self,context):
        row = self.layout
        row.prop(self,"name",text="Export Name")

    def invoke(self,context,event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):

        channel_list = context.scene.b_painter_export_list
        for item in channel_list:
            item.expand = False

        item = channel_list.add()
        item.name = self.name
        item.expand = True
        return {"FINISHED"}


class BPAINTER_PT_ChannelExport(bpy.types.Panel):
    bl_idname = "BPAINTER_PT_texture_export"
    bl_label = "BPainter Map Generator"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"

    @classmethod
    def poll(cls,context):
        if context.scene.render.engine in ["CYCLES", "BLENDER_EEVEE"]:
            return True
        return False

    def draw(self, context):
        layout = self.layout
        #col.template_list("BPAINTER_TextureSlot", "",mat.b_painter, "paint_layers", mat.b_painter, "paint_layers_index", rows=2)
        col = layout.column(align=True)
        row = col.row()
        row.alignment = "LEFT"
        row.operator("b_painter.add_export_map",text="Add Map",icon="ADD")
        row = col.row()
        row.template_list("BPAINTER_UL_ExportSlot","",context.scene,"b_painter_export_list",context.scene,"b_painter_export_list_index")


        col = layout.column(align=False)
        col.prop(context.scene,"b_painter_export_path",text="Export Path")
        col.operator("b_painter.export_paint_channels",text="Generate All Maps",icon="TEXTURE")

class BPAINTER_OT_ExportPaintChannels(bpy.types.Operator):
    bl_idname = "b_painter.export_paint_channels"
    bl_label = "Export Paint Channels"
    bl_description = ""
    bl_options = {"REGISTER"}

    bake_scene = None
    init_scene = None
    export_path = ""

    @classmethod
    def poll(cls, context):
        return True

    def get_channels(self,context,item):
        channels = OrderedDict()
        if item.export_type == "RGB":
            if item.rgb != "NONE":
                channels["RGB"] = item.rgb
        elif item.export_type == "GRAY":
            if item.gray != "NONE":
                channels["GRAY"] = item.gray
        elif item.export_type == "RGB+A":
            if item.rgb != "NONE":
                channels["RGB"] = item.rgb
            if item.a != "NONE":
                channels["A"] = item.a
        elif item.export_type == "R+G+B":
            if item.r != "NONE":
                channels["R"] = item.r
            if item.g != "NONE":
                channels["G"] = item.g
            if item.b != "NONE":
                channels["B"] = item.b
        elif item.export_type == "R+G+B+A":
            if item.r != "NONE":
                channels["R"] = item.r
            if item.g != "NONE":
                channels["G"] = item.g
            if item.b != "NONE":
                channels["B"] = item.b
            if item.a != "NONE":
                channels["A"] = item.a
        return channels

    def get_export_objs(self,context,channel_name):
        export_objs = []
        for obj in bpy.data.objects:
            for mat_slot in obj.material_slots:
                if mat_slot.material != None:
                    mat = mat_slot.material
                    if mat.node_tree != None:
                        for node in mat.node_tree.nodes:
                            if is_paint_channel_node(node):
                                if node.node_tree.name == channel_name:
                                    export_objs.append(obj)
                                    break
        return export_objs


    ### copies r,g,b or a data from one image to another
    def copy_channel(self,from_img=None,to_img=None,from_channel=None,to_channel=None):
        from_img_pixels = list(from_img.pixels)
        to_img_pixels = list(to_img.pixels)

        from_channel_index = 0
        to_channel_index = 0

        if from_channel == "R" or from_channel == "GRAY":
            from_channel_index = 0
        elif from_channel == "G":
            from_channel_index = 1
        elif from_channel == "B":
            from_channel_index = 2
        elif from_channel == "A":
            from_channel_index = 3

        if to_channel == "R" or from_channel == "GRAY":
            to_channel_index = 0
        elif to_channel == "G":
            to_channel_index = 1
        elif to_channel == "B":
            to_channel_index = 2
        elif to_channel == "A":
            to_channel_index = 3

        for i in range(0, len(from_img_pixels), 4):
            to_img_pixels[i+to_channel_index] = from_img_pixels[i+from_channel_index]

        to_img.pixels[:] = to_img_pixels
        to_img.update()
        return to_img

    def copy_target_object_to_bake_scene(self,bake_to_obj):
        bake_to_obj = bake_to_obj.copy()
        bake_to_obj.data = bake_to_obj.data.copy()
        self.bake_scene.collection.objects.link(bake_to_obj)
        return bake_to_obj

    def copy_source_objects_to_bake_scene(self,bake_from_objs):
        for obj in bake_from_objs:
            if obj != None and obj.type == "MESH":
                dupli_obj = obj.copy()
                dupli_obj.data = dupli_obj.data.copy()
                self.bake_scene.collection.objects.link(dupli_obj)

        bake_from_objs = self.bake_scene.objects[:]
        return bake_from_objs

    def setup_bake_to_image(self, context,item, key):
        img = None
        filename = item.name.replace(" ","_").lower()+".png"
        if item.internal_image in bpy.data.images:
            img = bpy.data.images[item.internal_image]
            img.source = "GENERATED"
            img.generated_height = item.resolution_y
            img.generated_width = item.resolution_x
        elif item.internal_image == "":
            img = bpy.data.images.new(key,alpha=True, width=item.resolution_x,height=item.resolution_y )
        else:
            img = bpy.data.images.new(item.internal_image,alpha=True, width=item.resolution_x,height=item.resolution_y )

        abspath = bpy.path.abspath(bpy.context.scene.b_painter_export_path)
        img.filepath = os.path.join(abspath, filename)
        return img

    ### export/bake bpainter channel node
    def export_channel(self, context, item, key, channel_name):
        export_objs = self.get_export_objs(context, channel_name)
        for obj in bpy.data.objects:
            if obj in export_objs:
                dupli_obj = obj.copy()
                dupli_obj.data = dupli_obj.data.copy()
                self.bake_scene.collection.objects.link(dupli_obj)

                dupli_obj.select_set(True, view_layer=self.bake_scene.view_layers[0])
                if obj == item.low_poly_obj:
                    self.bake_scene.view_layers[0].objects.active = dupli_obj
        bpy.ops.object.select_all(action='SELECT')

        if len(export_objs) > 1:
            override = bpy.context.copy()
            override["scene"] = self.bake_scene
            override["selected_objects"] = self.bake_scene.objects
            override["active_object"] = self.bake_scene.view_layers[0].objects.active
            bpy.ops.object.join(override)

        ### create material    
        tmp_obj = self.bake_scene.view_layers[0].objects.active
        for mat_slot in tmp_obj.material_slots:
            mat_slot.material = None
        tmp_mat = bpy.data.materials.new("b_painter_tmp_mat")
        tmp_mat.use_nodes = True
        tmp_obj.material_slots[0].material = tmp_mat

        ### create all needed nodes
        node_tree = tmp_mat.node_tree

        for node in node_tree.nodes:
            node_tree.nodes.remove(node)

        channel_node = node_tree.nodes.new("ShaderNodeGroup")
        channel_node.node_tree = bpy.data.node_groups[channel_name]
        channel_node.location = [0, 0]
        diffuse_node = node_tree.nodes.new("ShaderNodeBsdfDiffuse")
        diffuse_node.location = [200, 0]
        output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
        output_node.location = [400, 0]

        node_tree.links.new(channel_node.outputs["Color"], diffuse_node.inputs[0])
        node_tree.links.new(diffuse_node.outputs[0], output_node.inputs[0])

        filename = item.name.replace(" ", "_").lower() + ".png"
        # img = bpy.data.images.new(key, alpha=True, width=item.resolution_x, height=item.resolution_y)
        img = self.setup_bake_to_image(context, item, key)
        abspath = bpy.path.abspath(self.init_scene.b_painter_export_path)
        img.filepath = os.path.join(abspath, filename)
        texture_node = node_tree.nodes.new("ShaderNodeTexImage")
        texture_node.location = [0, -200]
        texture_node.image = img
        texture_node.select = True
        node_tree.nodes.active = texture_node

        ### setup bake options        
        self.bake_scene.cycles.samples = 1
        self.bake_scene.cycles.bake_type = "DIFFUSE"
        self.bake_scene.render.bake.use_selected_to_active = False
        self.bake_scene.render.bake.use_pass_direct = False
        self.bake_scene.render.bake.use_pass_indirect = False
        self.bake_scene.render.bake.use_pass_color = True

        override = bpy.context.copy()
        override["scene"] = self.bake_scene
        override["selected_objects"] = self.bake_scene.objects
        override["view_layer"] = self.bake_scene.view_layers[0]

        bpy.ops.object.bake(override, 'EXEC_DEFAULT', type="DIFFUSE")
        bpy.data.objects.remove(tmp_obj, do_unlink=True)
        bpy.data.materials.remove(tmp_mat, do_unlink=True)

        return img

    def export_cycles_bake(self,context,item,key,channel_name,bake_type="AO"): ### AO, NORMAL, GLOSSY
        img = None
        bake_to_obj = item.low_poly_obj
        bake_from_objs = []
        for obj in item.high_poly_objs:
            bake_from_objs.append(obj.high_poly_obj)

        bake_from_objs = self.copy_source_objects_to_bake_scene(bake_from_objs)
        bake_to_obj = self.copy_target_object_to_bake_scene(bake_to_obj)
        # if item.target_uv in bake_to_obj.data.uv_layers:
        #     bake_to_obj.data.uv_layers[item.target_uv].active_render = True
        img = self.setup_bake_to_image(context, item, key)

        ### setup render image node
        mat = bake_to_obj.active_material
        node_tree = mat.node_tree
        texture_node = node_tree.nodes.new("ShaderNodeTexImage")
        texture_node.image = img
        texture_node.select = True
        node_tree.nodes.active = texture_node

        ### select source and target objects
        bpy.ops.object.select_all(action='SELECT')
        self.bake_scene.frame_set(self.bake_scene.frame_current)
        for obj in self.bake_scene.objects:
            obj.select_set(True, view_layer=self.bake_scene.view_layers[0])
        self.bake_scene.view_layers[0].objects.active = self.bake_scene.objects[bake_to_obj.name]

        ### setup cycles bake
        if bake_type in ["AO","GLOSSY"]:
            self.bake_scene.cycles.samples = item.ao_samples
        else:
            self.bake_scene.cycles.samples = 1
        self.bake_scene.cycles.bake_type = bake_type
        self.bake_scene.render.bake.normal_space = item.normal_space
        self.bake_scene.render.bake.normal_r = item.normal_r
        self.bake_scene.render.bake.normal_g = item.normal_g
        self.bake_scene.render.bake.normal_b = item.normal_b
        if len(bake_from_objs) > 0:
            self.bake_scene.render.bake.use_selected_to_active = True
        else:
            self.bake_scene.render.bake.use_selected_to_active = False
        self.bake_scene.render.bake.cage_extrusion = .1

        override = bpy.context.copy()
        override["scene"] = self.bake_scene
        override["view_layer"] = self.bake_scene.view_layers[0]
        bpy.ops.object.bake(override,'EXEC_DEFAULT',type=bake_type)

        for obj in bake_from_objs:
            bpy.data.objects.remove(obj,do_unlink=True)
        bpy.data.objects.remove(bake_to_obj,do_unlink=True)
        node_tree.nodes.remove(texture_node)

        return img

    def export_curvature(self,context,item,key,channel_name):
        img = None

        if item.low_poly_obj == None:
            return

        ###
        bake_to_obj = item.low_poly_obj
        bake_from_objs = []
        for obj in item.high_poly_objs:
            bake_from_objs.append(obj.high_poly_obj)


        ### create a copy of source objects
        bake_from_objs = self.copy_source_objects_to_bake_scene(bake_from_objs)

        ### remove material from source objects
        tmp_mat = bpy.data.materials.new("b_painter_tmp_mat")
        tmp_mat.use_nodes = True
        for obj in bake_from_objs:
            for mat_slot in obj.material_slots:
                mat_slot.material = None
            if obj.data.materials:
                obj.data.materials[0] = tmp_mat
            else:
                obj.data.materials.append(tmp_mat)

        ### duplicate bake to obj
        bake_to_obj = self.copy_target_object_to_bake_scene(bake_to_obj)
        # if item.target_uv in bake_to_obj.data.uv_layers:
        #     bake_to_obj.data.uv_layers[item.target_uv].active_render = True

        for mat_slot in bake_to_obj.material_slots:
            mat_slot.material = None
        if bake_to_obj.data.materials:
            bake_to_obj.data.materials[0] = tmp_mat
        else:
            bake_to_obj.data.materials.append(tmp_mat)

        ### generate curvature nodes to bake from
        node_tree = tmp_mat.node_tree
        for node in node_tree.nodes:
            node_tree.nodes.remove(node)

        curvature_node = node_tree.nodes.new("ShaderNodeNewGeometry")
        curvature_node.location = [0,0]
        colorramp_node = node_tree.nodes.new("ShaderNodeValToRGB")
        colorramp_node.location = [200,0]
        #colorramp_node.color_ramp.elements[0].position = 0.4
        #colorramp_node.color_ramp.elements[1].position = 0.6
        colorramp_node.color_ramp.elements[0].position = 0.4
        colorramp_node.color_ramp.elements[1].position = 0.6

        diffuse_node = node_tree.nodes.new("ShaderNodeBsdfDiffuse")
        diffuse_node.location = [500,0]
        output_node = node_tree.nodes.new("ShaderNodeOutputMaterial")
        output_node.location = [700,0]

        node_tree.links.new(curvature_node.outputs["Pointiness"],colorramp_node.inputs["Fac"])
        node_tree.links.new(colorramp_node.outputs["Color"],diffuse_node.inputs["Color"])
        node_tree.links.new(diffuse_node.outputs["BSDF"],output_node.inputs["Surface"])

        ### setup bake to image
        img = self.setup_bake_to_image(context, item, key)

        texture_node = node_tree.nodes.new("ShaderNodeTexImage")
        texture_node.image = img

        ### select source and target objects
        bpy.ops.object.select_all(action='SELECT')
        self.bake_scene.frame_set(self.bake_scene.frame_current)
        for obj in self.bake_scene.objects:
            obj.select_set(True,view_layer=self.bake_scene.view_layers[0])
        self.bake_scene.view_layers[0].objects.active = self.bake_scene.objects[bake_to_obj.name]

        ### setup cycles bake
        self.bake_scene.cycles.samples = 1
        self.bake_scene.cycles.bake_type = "DIFFUSE"
        self.bake_scene.render.bake.use_pass_direct = False
        self.bake_scene.render.bake.use_pass_indirect = False
        self.bake_scene.render.bake.use_pass_color = True
        if len(bake_from_objs) > 0:
            self.bake_scene.render.bake.use_selected_to_active = True
        else:
            self.bake_scene.render.bake.use_selected_to_active = False
        self.bake_scene.render.bake.cage_extrusion = .1

        override = bpy.context.copy()
        override["scene"] = self.bake_scene
        override["view_layer"] = self.bake_scene.view_layers[0]
        bpy.ops.object.bake(override,'EXEC_DEFAULT',type="DIFFUSE")

        for obj in bake_from_objs:
            bpy.data.objects.remove(obj,do_unlink=True)
        bpy.data.objects.remove(bake_to_obj,do_unlink=True)
        bpy.data.materials.remove(tmp_mat,do_unlink=True)
        return img

    def set_target_uv(self, item):
        if item.low_poly_obj != None and item.low_poly_obj.type == "MESH":
            if item.target_uv in item.low_poly_obj.data.uv_layers:
                item.low_poly_obj.data.uv_layers[item.target_uv].active = True
                print(item.low_poly_obj.name,"------------>", item.target_uv)

    def export_item(self,context, item):
        self.set_target_uv(item)

        global cb
        channels = self.get_channels(context,item)
        channel_images = OrderedDict()
        for i,key in enumerate(channels):
            channel_name = channels[key]
            ### if channel is BPainter Channel
            if channel_name not in cb:
                channel_images[key] = self.export_channel(context,item,key,channel_name)
            if channel_name in ["BP_CURVATURE"]:
                channel_images[key] = self.export_curvature(context,item,key,channel_name)
            elif channel_name in ["BP_AO"]:
                channel_images[key] = self.export_cycles_bake(context,item,key,channel_name,bake_type="AO")
            elif channel_name in ["BP_NORMAL"]:
                channel_images[key] = self.export_cycles_bake(context,item,key,channel_name,bake_type="NORMAL")

        to_img = None
        for i, key in enumerate(channel_images):
            if i == 0:
                to_img = channel_images[key]
            elif i > 0:
                from_img = channel_images[key]
                self.copy_channel(from_img=from_img,to_img=to_img,from_channel="R",to_channel=key)
                bpy.data.images.remove(from_img,do_unlink=True)

        if to_img != None:
            image_settings = context.scene.render.image_settings
            if item.export_type in ["GRAY"]:
                image_settings.color_mode = "BW"
            elif item.export_type in ["RGB","R+G+B"]:
                image_settings.color_mode = "RGB"
            elif item.export_type in ["RGB+A","R+G+B+A"]:
                image_settings.color_mode = "RGBA"
            image_settings.file_format = "PNG"
            image_settings.color_depth = "8"

            #if not item.keep_internal:
            if item.save_mode == "EXTERNAL":
                to_img.save_render(to_img.filepath,scene = context.scene)
                bpy.data.images.remove(to_img,do_unlink=True)
            #else:
            elif item.save_mode == "INTERNAL":
                #to_img.source = "GENERATED"
                to_img.name = item.name
                to_img.pack()
                item.internal_image = to_img.name


    def execute(self, context):
        export_channels = context.scene.b_painter_export_list
        try:
            if len(export_channels) > 0:
                wm = context.window_manager
                self.export_path = bpy.path.abspath(context.scene.b_painter_export_path)
                # if not os.path.exists(self.export_path):
                #     self.report({"WARNING"}, "Select a valid Export Path")
                #     return {"FINISHED"}

                self.init_scene = context.scene

                ### create bake scene
                active_scene = bpy.context.scene
                self.bake_scene = bpy.data.scenes.new("BP_BAKE_SCENE")
                self.bake_scene.render.engine = "CYCLES"
                context.window.scene = self.bake_scene


                wm.progress_begin(0,100)
                progress_current = 0
                progress_step = 100/len(export_channels)
                for item in export_channels:
                    progress_current += progress_step
                    wm.progress_update(int(progress_current))
                    if item.export and (item.save_mode == "INTERNAL" or (item.save_mode == "EXTERNAL" and os.path.exists(self.export_path))):
                        self.export_item(context, item)
                wm.progress_end()

                ### remove bake scene
                bpy.data.scenes.remove(self.bake_scene)
                bpy.context.window.scene = active_scene
                self.report({"INFO"}, "All Textures have been exported.")
            else:
                self.report({"INFO"}, "No Maps have been created.")
        except Exception as e:
            if self.bake_scene != None:
                bpy.data.scenes.remove(self.bake_scene)
            self.report({"WARNING"}, e)
        return {"FINISHED"}

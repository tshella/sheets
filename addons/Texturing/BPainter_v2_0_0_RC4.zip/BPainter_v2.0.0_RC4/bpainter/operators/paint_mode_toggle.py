'''
Copyright (C) 2019 Andreas Esau
andreasesau@gmail.com

Created by Andreas Esau

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy


class BPAINTER_OT_EnterTexturePaint(bpy.types.Operator):
    bl_idname = "b_painter.enter_texture_paint"
    bl_label = "Enter Paint Mode"
    bl_description = ""
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        if context.active_object.type == "MESH":
            return True
        else:
            return False

    def execute(self, context):
        bpy.ops.object.mode_set(mode="TEXTURE_PAINT")
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                space = area.spaces[0]
                space.overlay.texture_paint_mode_opacity = 0.0
        bpy.ops.b_painter.force_layer_update()
        return {"FINISHED"}

class BPAINTER_OT_ExitTexturePaint(bpy.types.Operator):
    bl_idname = "b_painter.exit_texture_paint"
    bl_label = "Exit Paint Mode"
    bl_description = ""
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        if context.active_object.type == "MESH":
            return True
        else:
            return False

    def execute(self, context):
        bpy.ops.object.mode_set(mode="OBJECT")
        return {"FINISHED"}

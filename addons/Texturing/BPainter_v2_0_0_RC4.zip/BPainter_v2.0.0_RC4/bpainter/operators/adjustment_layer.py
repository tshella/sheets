'''
Copyright (C) 2017 Andreas Esau
andreasesau@gmail.com

Created by Andreas Esau

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
    
import bpy
from bpy.props import StringProperty, IntProperty

class BPAINTER_OT_ConfigurePaintLayer(bpy.types.Operator):
    bl_idname = "b_painter.configure_paint_layer"
    bl_label = "Configure Paint Layer"
    bl_description = ""
    bl_options = {"REGISTER"}

    node_tree_name: StringProperty()
    index: IntProperty()
    mat_name: StringProperty()
    tex_node_name: StringProperty()
    mix_node_name: StringProperty()
    
    @classmethod
    def poll(cls, context):
        return True
    
    def check(self,context):
        return True
    
    def draw(self,context):
        obj = context.active_object
        mat = bpy.data.materials[self.mat_name]
        node_tree = bpy.data.node_groups[self.node_tree_name]
        
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        paint_layers = paint_channel.paint_layers
        paint_layers_index = paint_channel.paint_layers_index
        paint_layer = paint_layers[paint_layers_index]
        
        tex_node = node_tree.nodes[self.tex_node_name]
        
        mapping_node = None
        coords_node = tex_node.inputs["Vector"].links[0].from_node if len(tex_node.inputs["Vector"].links) > 0 else None
        if coords_node.type == "MAPPING":
            mapping_node = coords_node
            coords_node = mapping_node.inputs["Vector"].links[0].from_node if len(mapping_node.inputs["Vector"].links) > 0 else None
        
        col = self.layout.column()
        row = col.row()
        row.prop(paint_layer,"mapping_mode",expand=True)
        if coords_node != None:
            if coords_node.type == "UVMAP":
                col.prop_search(coords_node,"uv_map",obj.data,"uv_layers",text="UV Map",icon="GROUP_UVS")
            elif coords_node.type == "TEX_COORD":
                box = col.box()
                box.prop(tex_node,"projection_blend")    
                if mapping_node != None:
                    row = box.row()
                    subcol = row.column_flow(columns=3)
                    subcol.prop(mapping_node.inputs["Location"],"default_value", text="Location")
                    subcol.prop(mapping_node.inputs["Rotation"],"default_value", text="Rotation")
                    subcol.prop(mapping_node.inputs["Scale"],"default_value", text="Scale")
            
        col.prop(tex_node,"image")
    
    def set_paint_layer(self,context,set_paint_active=True):
        mat = bpy.data.materials[self.mat_name]

        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        paint_layers = paint_channel.paint_layers
        paint_layers_index = paint_channel.paint_layers_index
        
        paint_channel.paint_layers_index = self.index

        paint_layer = paint_layers[self.index]
        
        node_tree = bpy.data.node_groups[self.node_tree_name]
        tex_node = node_tree.nodes[self.tex_node_name] if self.tex_node_name != "" else None
        mix_node = node_tree.nodes[self.mix_node_name] if self.mix_node_name != "" else None
        
        
        if set_paint_active:
            paint_layer["mask_layer_active"] = False
            paint_layer["paint_layer_active"] = True
        if tex_node != None:
            if not mix_node.b_painter_layer_hide:
                context.tool_settings.image_paint.canvas = tex_node.image
            else:    
                context.tool_settings.image_paint.canvas = None
                
    
    def invoke(self,context,event):
        if event.ctrl:
            self.set_paint_layer(context,set_paint_active=False)
            wm = context.window_manager
            return wm.invoke_props_dialog(self,width=400)
        else:
            return self.execute(context)

    def execute(self, context):
        self.set_paint_layer(context)
        return {"FINISHED"}
    
class BPAINTER_OT_ConfigureMaskLayer(bpy.types.Operator):
    bl_idname = "b_painter.configure_mask_layer"
    bl_label = "Configure Mask Layer"
    bl_description = ""
    bl_options = {"REGISTER"}
    
    
    invert_node_name: StringProperty()
    colorramp_node_name: StringProperty()
    node_tree_name: StringProperty()
    mask_node_name: StringProperty()
    index: IntProperty()
    mat_name: StringProperty()
    mask_tex_node_name: StringProperty()
    mix_node_name: StringProperty()
        
    @classmethod
    def poll(cls, context):
        return True
    
    def check(self,context):
        return True
    
    def draw(self,context):
        
        node_tree = bpy.data.node_groups[self.node_tree_name]
        invert_node = node_tree.nodes[self.invert_node_name]
        colorramp_node = node_tree.nodes[self.colorramp_node_name] if self.colorramp_node_name != "" else None
        mask_node = node_tree.nodes[self.mask_node_name] if self.mask_node_name != "" else None
        mask_tex_node = node_tree.nodes[self.mask_tex_node_name] if self.mask_tex_node_name != "" else None
        mat = bpy.data.materials[self.mat_name]
        
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        paint_layers = paint_channel.paint_layers
        paint_layer = paint_layers[self.index]

        mask_mapping_node = None
        coords_node = mask_tex_node.inputs["Vector"].links[0].from_node if len(mask_tex_node.inputs["Vector"].links) > 0 else None
        if coords_node != None and coords_node.type == "MAPPING":
            mask_mapping_node = coords_node
            coords_node = mask_mapping_node.inputs["Vector"].links[0].from_node if len(mask_mapping_node.inputs["Vector"].links) > 0 else None
        
        layout = self.layout
        col = layout.column(align=True)
        
        row = col.row()
        if mask_node != None:
            row.prop(mask_node,"b_painter_layer_hide",text="Disable Mask")
        if invert_node != None:
            row.prop(invert_node,"b_painter_layer_hide",text="Invert Mask")    
            
        if invert_node != None:
            col.label(text="Mask Mode:")
            row = col.row()
            row.prop(paint_layer,"mask_mode",expand=True,text="Mask Mode")
            
        col.label(text="Mapping Mode:")
        row = col.row()
        row.prop(paint_layer,"mask_mapping_mode",expand=True) 
        if paint_layer.mask_mapping_mode == "BOX_MAP":
            box = col.box()
            box.prop(mask_tex_node,"projection_blend")
            if mask_mapping_node != None:
                row = box.row()
                subcol = row.column_flow(columns=3)
                subcol.prop(mask_mapping_node.inputs["Location"],"default_value", text="Location")
                subcol.prop(mask_mapping_node.inputs["Rotation"],"default_value", text="Rotation")
                subcol.prop(mask_mapping_node.inputs["Scale"],"default_value", text="Scale")
                
        
            
        if colorramp_node != None:
            col.template_color_ramp(colorramp_node,"color_ramp")
        if mask_tex_node != None:    
            col.prop(mask_tex_node,"image")    
    
    def set_mask_layer(self,context,set_mask_active=True):
        mat = bpy.data.materials[self.mat_name]
        
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        paint_layers = paint_channel.paint_layers
        paint_layer = paint_layers[self.index] 
        
        paint_channel.paint_layers_index = self.index
        
        node_tree = bpy.data.node_groups[self.node_tree_name]
        mix_node = node_tree.nodes[self.mix_node_name] if self.mix_node_name != "" else None
        mask_tex_node = node_tree.nodes[self.mask_tex_node_name] if self.mask_tex_node_name != "" else None
        
        if set_mask_active:
            paint_layer["mask_layer_active"] = True
            paint_layer["paint_layer_active"] = False
        if mask_tex_node != None:
            if mix_node and not mix_node.b_painter_layer_hide:
                context.tool_settings.image_paint.canvas = mask_tex_node.image
            else:
                context.tool_settings.image_paint.canvas = None    
        
        
    def invoke(self,context,event):
       
        if event.ctrl:
            self.set_mask_layer(context,set_mask_active=False)
            
            wm = context.window_manager
            return wm.invoke_props_dialog(self,width=400)
        else:
            return self.execute(context)
            
    
    def execute(self, context):
        self.set_mask_layer(context)
        return {"FINISHED"}
        

class BPAINTER_OT_ConfigureAdjustmentLayer(bpy.types.Operator):
    bl_idname = "b_painter.configure_adjustment_layer"
    bl_label = "Configure Adjustment Layer"
    bl_description = ""
    bl_options = {"REGISTER"}
    
    node_name: StringProperty()
    node_tree_name: StringProperty()
    index: IntProperty()
    mat_name: StringProperty()
    
    @classmethod
    def poll(cls, context):
        return True
    
    def check(self,context):
        return True
    
    def draw(self,context):
        node_tree = bpy.data.node_groups[self.node_tree_name]
        node = node_tree.nodes[self.node_name]
        layout = self.layout
        col = layout.column(align=True)
        
        if node.type == "CURVE_RGB":
            col.template_curve_mapping(node,"mapping",type="COLOR")
        elif node.type == "HUE_SAT":
            col.prop(node.inputs[0],"default_value",text="Hue",slider=True)
            col.prop(node.inputs[1],"default_value",text="Saturation",slider=True)
            col.prop(node.inputs[2],"default_value",text="Value",slider=True)
        elif node.type == "VALTORGB":
            col.template_color_ramp(node,"color_ramp")
        
          
        
    def invoke(self,context,event):
        
        node_tree = bpy.data.node_groups[self.node_tree_name]
        node = node_tree.nodes[self.node_name]
        if node.type == "INVERT":
            return{"FINISHED"}
        mat = bpy.data.materials[self.mat_name]
        mat.b_painter.paint_layers_index = self.index
        
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        paint_layers = paint_channel.paint_layers
        paint_layer = paint_layers[self.index] 
        
        paint_layer.paint_layer_active = True
        
        wm = context.window_manager
        return wm.invoke_props_dialog(self,width=400)
    
    def execute(self, context):
        return {"FINISHED"}
    
class BPAINTER_OT_ConfigureProceduralTexture(bpy.types.Operator):
    bl_idname = "b_painter.configure_procedural_texture"
    bl_label = "Configure Procedural Texture"
    bl_description = "Configure Procedural Texture"
    bl_options = {"REGISTER"}
    
    node_tree_name: StringProperty()
    proc_tex_node_name: StringProperty()
    proc_ramp_node_name: StringProperty()
    index: IntProperty()
    mat_name: StringProperty()
    
    @classmethod
    def poll(cls, context):
        return True
    
    def check(self,context):
        return True
    
    def draw(self,context):
        node_tree = bpy.data.node_groups[self.node_tree_name]
        proc_tex_node = node_tree.nodes[self.proc_tex_node_name]
        proc_ramp_node = node_tree.nodes[self.proc_ramp_node_name]
        
        layout = self.layout
        col = layout.column()
        proc_tex_node.draw_buttons_ext(context,col)
        for input in proc_tex_node.inputs:
            if input.name != "Vector":
                col.prop(input,"default_value",text=input.name)
        proc_ramp_node.draw_buttons_ext(context,col)        
    
        
    def invoke(self,context,event):
        node_tree = bpy.data.node_groups[self.node_tree_name]
        proc_tex_node = node_tree.nodes[self.proc_tex_node_name]
        proc_ramp_node = node_tree.nodes[self.proc_ramp_node_name]
        
        wm = context.window_manager
        return wm.invoke_props_dialog(self,width=400)
    
    def execute(self, context):
        return {"FINISHED"}
            
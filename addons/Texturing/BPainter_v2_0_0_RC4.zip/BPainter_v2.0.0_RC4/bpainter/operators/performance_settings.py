'''
Copyright (C) 2019 Andreas Esau
andreasesau@gmail.com

Created by Andreas Esau

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy


class BPAINTER_OT_ChangePerformanceSettings(bpy.types.Operator):
    bl_idname = "b_painter.change_used_threads"
    bl_label = "Change Used Threads"
    bl_description = "This is a workaround. Painting lags a lot if multi threading is enabled. Setting Threads to 1 improves performance alot."
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        context.scene.render.threads_mode = "FIXED"
        context.scene.render.threads = 1
        return {"FINISHED"}

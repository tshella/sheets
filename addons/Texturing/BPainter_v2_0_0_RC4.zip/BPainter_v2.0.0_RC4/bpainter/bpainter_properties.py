'''
Copyright (C) 2017 Andreas Esau
andreasesau@gmail.com

Created by Andreas Esau

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
    
import os
import bpy
from bpy.props import CollectionProperty, StringProperty, PointerProperty, IntProperty, FloatProperty, BoolProperty, EnumProperty, FloatVectorProperty, IntVectorProperty
from mathutils import Vector
import math
from . functions import _tonemap, _invert_ramp, _mute_ramp, setup_brush_tex, id_from_string, set_active_paint_layer, update_all_paint_layers, get_materials_recursive, set_material_shading, set_brush_alpha_lock, get_paint_channels
from . operators.preset_handling import texture_path, get_tex_previews, get_brush_tex_previews, get_stencil_tex_previews

def set_paint_layer(self,context):
    mat = bpy.data.materials[context.active_object.b_painter_active_material]
    b_painter = self.id_data.b_painter
    paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
    paint_channel_active = paint_channel.group_name
    paint_layers = paint_channel.paint_layers
    paint_layers_index = paint_channel.paint_layers_index
    
    if len(paint_layers) > 0:
        self["paint_layers_index"] = min(paint_layers_index,len(paint_layers)-1)
        active_layer = paint_layers[self["paint_layers_index"]]
        
        if active_layer.layer_type in ["PAINT_LAYER","PAINT_CHANNEL_LAYER"]:
            
            
            if paint_layers_index < len(paint_layers) and len(paint_layers) > 0:
                if context.scene.render.engine in ["CYCLES", "BLENDER_EEVEE"]:
                    paint_layer = paint_layers[paint_layers_index]
                    if paint_layer.layer_type in ["PAINT_LAYER","PAINT_CHANNEL_LAYER"]:
                        if paint_layer.paint_layer_active:
                            layer_visible = not bpy.data.node_groups[paint_channel_active].nodes[paint_layer.mix_node_name].b_painter_layer_hide if paint_channel_active in bpy.data.node_groups else None
                            if layer_visible == None:
                                if paint_layer.node_tree_name == "Shader Nodetree" and paint_layer.tex_node_name != "":
                                    layer_visible = not mat.node_tree.nodes[paint_layer.tex_node_name].mute
                                    
                            
                            if paint_layer.layer_type in ["PAINT_LAYER"] and layer_visible:
                                context.tool_settings.image_paint.canvas = bpy.data.images[paint_layer.img_name]
                            else:
                                context.tool_settings.image_paint.canvas = None
                        elif paint_layer.mask_layer_active and paint_layer.mask_img_name != "":
                            context.tool_settings.image_paint.canvas = bpy.data.images[paint_layer.mask_img_name]
                        context.tool_settings.image_paint.mode = "IMAGE"
                    
                                
        elif active_layer.layer_type in ["ADJUSTMENT_LAYER","PROCEDURAL_TEXTURE"]:
            paint_layer = paint_layers[paint_layers_index]
            if active_layer.mask_tex_node_name == "":
                context.tool_settings.image_paint.canvas = None
                context.tool_settings.image_paint.mode = "IMAGE"
            else:
                context.tool_settings.image_paint.canvas = bpy.data.images[paint_layer.mask_img_name]
                context.tool_settings.image_paint.mode = "IMAGE"
        
        update_all_paint_layers(self,context)
                                
        
def invert_ramp(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    _invert_ramp(self,context,tex_type="BRUSH")
    
def invert_stencil_ramp(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    _invert_ramp(self,context,tex_type="STENCIL")
        
def tonemap(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    _tonemap(self,context)

def tonemap_stencil(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    _tonemap(self,context,tex_type="STENCIL")

def mute_ramp(self,context): 
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    _mute_ramp(self,context)   

BRUSHES = []
def get_brushes(self,context):
    wm = context.window_manager
    global BRUSHES
    if wm.b_painter_update_brushes:
        BRUSHES = []
        brush_index = 0
        for i,brush in enumerate(bpy.data.brushes):
            if brush.use_paint_image and "b_painter" in brush:
                if wm.b_painter_brush_filter == "" or wm.b_painter_brush_filter.lower() in brush.name.lower():
                    icon_id = bpy.types.UILayout.icon(brush)
                    BRUSHES.append((str(brush.name),str(brush.name),str(brush.name),icon_id,brush_index))
                    brush_index += 1
        BRUSHES.sort(key= lambda x: bpy.data.brushes[x[0]].b_painter_brush_order)
        wm.b_painter_update_brushes = False
        if len(BRUSHES) == 0:
            BRUSHES.append(("Not found","Not found","Not found","BRUSHES",0))
    return BRUSHES

def get_b_painter_active_brush(self):
    if "b_painter_brush" in self:
        if len(BRUSHES) < self["b_painter_brush"]:
            self["b_painter_brush"] = 0
        return self["b_painter_brush"]
    else:
        return 0

def set_b_painter_active_brush(self, value):
    self["b_painter_brush"] = value
    set_brush(self, bpy.context)
    
IMAGES = []
def get_brush_textures(self,context):
    global IMAGES
    IMAGES = []
    IMAGES.append(("None","None","None","NONE",0))
    for i,image in enumerate(bpy.data.images):
        if "b_painter" in image:
            icon_id = bpy.types.UILayout.icon(image)    
            IMAGES.append((image.name,image.name,image.name,icon_id,i+1))
    return IMAGES


CATEGORIES = []
def get_category_dirs(self,context):
    global CATEGORIES
    CATEGORIES = [] 
    i = 0 
    for name in os.listdir(texture_path):
        if os.path.isdir(os.path.join(texture_path,name)):
            # CATEGORIES.append((name,name,name,"None",id_from_string(name)))
            CATEGORIES.append((name,name,name,"None",i))
            i += 1
    if i == 0:
        CATEGORIES.append(("Default Category","Default Category","Default Category"))        
    return CATEGORIES

def set_brush(self,context):
    wm = context.window_manager
    wm.b_painter_update_brushes = True
    
    brush = context.tool_settings.image_paint.brush
    if brush != None and self.b_painter_brush in bpy.data.brushes:
        if brush.mask_texture != None:
            tex = bpy.data.textures[brush.mask_texture.name]
        else:
            tex = None    
          
        stencil_trans = {}
        stencil_trans["dimension"] = brush.mask_stencil_dimension
        stencil_trans["pos"] = brush.mask_stencil_pos
        stencil_trans["offset"] = brush.mask_texture_slot.offset
        stencil_trans["scale"] = brush.mask_texture_slot.scale
        stencil_trans["angle"] = brush.mask_texture_slot.angle
        #stencil_trans["category"] = context.scene.b_painter_tex_stencil_categories
        stencil_trans["stenci_texture"] = brush.b_painter_stencil_texture
        stencil_trans["invert_mask"] = brush.b_painter_invert_stencil_mask
        stencil_trans["stencil_ramp_r"] = brush.b_painter_stencil_ramp_tonemap_r
        stencil_trans["stencil_ramp_l"] = brush.b_painter_stencil_ramp_tonemap_l
        stencil_trans["mask_map_mode"] = brush.mask_texture_slot.mask_map_mode
        stencil_trans["use_secondary_overlay"] = brush.use_secondary_overlay
        stencil_trans["mask_overlay_alpha"] = brush.mask_overlay_alpha
        stencil_trans["use_secondary_overlay_override"] = brush.use_secondary_overlay_override
          
        context.tool_settings.image_paint.brush = bpy.data.brushes[self.b_painter_brush]
    
        ### set stencil texture
        brush = context.tool_settings.image_paint.brush
        brush.mask_texture = tex
        brush.mask_stencil_dimension = stencil_trans["dimension"]
        brush.mask_stencil_pos = stencil_trans["pos"]
        brush.mask_texture_slot.offset = stencil_trans["offset"]
        brush.mask_texture_slot.scale = stencil_trans["scale"]
        brush.mask_texture_slot.angle = stencil_trans["angle"]
        brush.b_painter_stencil_texture = stencil_trans["stenci_texture"]
        brush.b_painter_invert_stencil_mask = stencil_trans["invert_mask"]
        brush.b_painter_stencil_ramp_tonemap_r = stencil_trans["stencil_ramp_r"]
        brush.b_painter_stencil_ramp_tonemap_l =  stencil_trans["stencil_ramp_l"]
        brush.mask_texture_slot.mask_map_mode = stencil_trans["mask_map_mode"]
        brush.use_secondary_overlay = stencil_trans["use_secondary_overlay"]
        brush.mask_overlay_alpha = stencil_trans["mask_overlay_alpha"]
        brush.use_secondary_overlay_override = stencil_trans["use_secondary_overlay_override"]
        
        context.tool_settings.image_paint.brush.b_painter_use_mask = context.tool_settings.image_paint.brush.b_painter_use_mask
        context.tool_settings.image_paint.brush.b_painter_invert_mask = context.tool_settings.image_paint.brush.b_painter_invert_mask
        context.tool_settings.image_paint.brush.b_painter_ramp_tonemap_l = context.tool_settings.image_paint.brush.b_painter_ramp_tonemap_l
        context.tool_settings.image_paint.brush.b_painter_ramp_tonemap_r = context.tool_settings.image_paint.brush.b_painter_ramp_tonemap_r
    #### set brush alpha settings
    mat = context.active_object.active_material if context.active_object != None else None
    set_brush_alpha_lock(context,mat)     

def set_texture(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    brush = context.tool_settings.image_paint.brush
    
    if brush != None:  
        context.scene.b_painter_active_tex_brush = str(self.b_painter_brush_texture)
        category = brush.b_painter_tex_brush_categories
        if self.b_painter_brush_texture != "None":
            img_path = os.path.join(texture_path,category,self.b_painter_brush_texture)
            brush_tex = setup_brush_tex(img_path)
            img = brush_tex.node_tree.nodes["Image"].image
            img_aspect_ratio = img.size[0]/img.size[1]
            context.tool_settings.image_paint.brush.texture = brush_tex
            context.tool_settings.image_paint.brush.texture_slot.scale[0] = 1
            context.tool_settings.image_paint.brush.texture_slot.scale[1] = img_aspect_ratio
            context.tool_settings.image_paint.brush.texture_slot.scale[2] = 1
        else:
            context.tool_settings.image_paint.brush.texture = None
            context.tool_settings.image_paint.brush.texture_slot.scale[0] = 1
            context.tool_settings.image_paint.brush.texture_slot.scale[1] = 1
            context.tool_settings.image_paint.brush.texture_slot.scale[2] = 1
        
    _invert_ramp(context.tool_settings.image_paint.brush,context) 
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False

def set_stencil_texture(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    
    brush = context.tool_settings.image_paint.brush
    if brush != None:

        category = context.scene.b_painter_tex_stencil_categories
        if self.b_painter_stencil_texture != "None":
            img_path = os.path.join(texture_path,category,self.b_painter_stencil_texture)
            brush_tex = setup_brush_tex(img_path,tex_type="STENCIL")
            context.tool_settings.image_paint.brush.mask_texture = brush_tex
        else:
            context.tool_settings.image_paint.brush.mask_texture = None

    if brush.mask_texture != None:
        img = brush.mask_texture.node_tree.nodes["Image"].image
        ratio = img.size[1]/img.size[0]
        brush.mask_stencil_dimension = [256,256*ratio]

    _invert_ramp(context.tool_settings.image_paint.brush,context,tex_type="STENCIL")
                  


def refresh_brush_category(self,context):
    context.window_manager.b_painter_brush_textures_loaded = False
    context.window_manager.b_painter_stencil_textures_loaded = False
    
    
    brush = context.tool_settings.image_paint.brush
    
    if brush != None:
        context.scene.b_painter_active_tex_brush_category = brush.b_painter_tex_brush_categories
        category = brush.b_painter_tex_brush_categories
        if self.b_painter_brush_texture != "None":
            img_path = os.path.join(texture_path,category,self.b_painter_brush_texture)
            brush_tex = setup_brush_tex(img_path)
            context.tool_settings.image_paint.brush.texture = brush_tex  
        else:
            context.tool_settings.image_paint.brush.texture = None  
    bpy.ops.b_painter.refresh_previews()
        
def refresh_stencil_category(self,context):
    context.window_manager.b_painter_stencil_textures_loaded = False
    context.window_manager.b_painter_brush_textures_loaded = False
    
    context.scene.b_painter_active_stencil_category = context.scene.b_painter_tex_stencil_categories
    
    brush = context.tool_settings.image_paint.brush
    
    if brush != None:
        category = context.scene.b_painter_tex_stencil_categories
        if brush.b_painter_stencil_texture != "None":
            img_path = os.path.join(texture_path,category,brush.b_painter_stencil_texture)
            brush_tex = setup_brush_tex(img_path,tex_type="STENCIL")
            context.tool_settings.image_paint.brush.mask_texture = brush_tex  
        else:
            context.tool_settings.image_paint.brush.mask_texture = None
            
    bpy.ops.b_painter.refresh_previews()
            

PAINT_CHANNELS = []
def get_paint_channel(self,context):
    global PAINT_CHANNELS
    PAINT_CHANNELS = []
    mat = self.id_data

    PAINT_CHANNELS.append(("Unordered Images","Unordered Images","Unordered Images","IMAGE_DATA",0))
    channels = []
    i = 1
    for item in mat.b_painter.paint_channel:
        if (mat.node_tree != None or mat.b_painter.paint_channel_parent_name != "") and item.name != "Unordered Images":
            if item.name not in channels:
                channels.append(item.name)
                PAINT_CHANNELS.append((item.name,item.name,item.name,"COLLAPSEMENU",i))
                i += 1

    PAINT_CHANNELS.sort(key=lambda x: x[0])
    return PAINT_CHANNELS
        
def update_paint_channel(self,context):
    update_all_paint_layers(self,context)
    paint_channel = self.paint_channel[self.paint_channel_active]
    paint_layers = paint_channel.paint_layers
    paint_layers_index = paint_channel.paint_layers_index
    
    set_paint_layer(self,context)
    
    if len(paint_layers) == 0:
        context.tool_settings.image_paint.canvas = None
    
###
def set_show_hide(self,context):
    mat = bpy.data.materials[context.active_object.b_painter_active_material] if context.active_object.b_painter_active_material != "Unordered Images" else None
    
    b_painter = mat.b_painter
    paint_channel = b_painter.paint_channel[b_painter.paint_channel_active] if b_painter.paint_channel_active in b_painter.paint_channel else None
    paint_layers = paint_channel.paint_layers if paint_channel != None else None
    paint_layers_index = paint_channel.paint_layers_index if paint_channel != None else None
    
    
    paint_layer = paint_layers[paint_layers_index] if mat != None else None
    
    if paint_layer != None:
        if self.b_painter_layer_hide:
            context.tool_settings.image_paint.canvas = None
        else:
            if paint_layer.paint_layer_active and paint_layer.img_name in bpy.data.images:
                context.tool_settings.image_paint.canvas = bpy.data.images[paint_layer.img_name]
            elif paint_layer.mask_layer_active and paint_layer.mask_img_name in bpy.data.images:
                context.tool_settings.image_paint.canvas = bpy.data.images[paint_layer.mask_img_name]
            
    self.mute = self.b_painter_layer_hide
    
        
    if self.type == "MIX_RGB":
        if len(self.outputs["Color"].links) > 0:
            to_node = self.outputs["Color"].links[0].to_node
            # if to_node.label == "BPaintMask":
            #     to_node.mute = self.b_painter_layer_hide
        if len(self.inputs["Color2"].links) > 0:
            from_node = self.inputs["Color2"].links[0].from_node
            math_node = self.inputs["Fac"].links[0].from_node
            if from_node.type == "TEX_IMAGE":
                from_node.mute = self.b_painter_layer_hide
            if math_node.type == "MATH":
                math_node.mute = self.b_painter_layer_hide

        if self.inputs[1].links[0].from_node.type != "GROUP_INPUT":
            for link in math_node.outputs[0].links:
                if link.to_node.type == "MATH":
                    link = link.to_node.outputs[0].links[0]
                if link.to_node.type == "GROUP":
                    link.to_node.mute = self.b_painter_layer_hide
                
def set_b_painter_opacity(self,context):
    if self.type == "MATH":
        self.inputs[1].default_value = self.b_painter_opacity
    else:
        self.inputs["Fac"].default_value = self.b_painter_opacity
    
def update_brush_filter(self,context):
    global BRUSHES
    wm = context.window_manager
    wm.b_painter_update_brushes = True
    context.scene["b_painter_brush"] = 0

 
def set_brush_hardness(self, context):
    brush = self
    points_len = len(brush.curve.curves[0].points)
    for i in range(points_len):
        if len(brush.curve.curves[0].points) > 3:
            point = brush.curve.curves[0].points[0]
            brush.curve.curves[0].points.remove(point)
            brush.curve.curves[0].points.update()
            brush.curve.update()       
    while len(brush.curve.curves[0].points) <= 2:
        brush.curve.curves[0].points.new(.5,.5)
        brush.curve.curves[0].points.update()
        brush.curve.update()
        
    brush.curve.curves[0].points[0].location = [0,1]
    brush.curve.curves[0].points[2].location = [1,0]
    hardness = min(0.99,(self.b_painter_hardness*.8)+.2)
    hardness = max(0.2,hardness)
    x = (self.b_painter_hardness * .65) + 0.35
    y = (self.b_painter_hardness * .4) + 0.35
    
    x = min(0.999,x)
    brush.curve.curves[0].points[1].location = [x,y]
    
    brush.curve.curves[0].points.update()
    brush.curve.update()


MATERIALS = []
def get_object_materials(self,context):
    global MATERIALS
    MATERIALS = []
    ob = context.active_object
    if ob != None:
        x = 0
        for i,slot in enumerate(ob.material_slots):
            if slot.material != None:
                mat = slot.material
                mats = get_materials_recursive(mat,mat.node_tree)
                for j,mat in enumerate(mats):
                    icon = bpy.types.UILayout.icon(mat)
                    MATERIALS.append((mat.name,mat.name,mat.name,icon,x))
                    x += 1
    if len(MATERIALS) == 0:
        MATERIALS.append(("NO_MATERIAL","No active Material","No active Material"))
    return MATERIALS      

def set_active_material(self,context):
    global MATERIALS
    wm = context.window_manager
    mat = bpy.data.materials[self.b_painter_active_material] if self.b_painter_active_material in bpy.data.materials else None
    if mat != None:
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active] if b_painter.paint_channel_active in b_painter.paint_channel else None
        paint_layers = paint_channel.paint_layers if paint_channel != None else None
        paint_layers_index = paint_channel.paint_layers_index if paint_channel != None else None

        for i,slot in enumerate(context.active_object.material_slots):
            if slot.material != None and slot.material == mat:
                context.active_object.active_material_index = i
                break
        paint_layers_index = paint_layers_index

def set_mat_shading(self,context):
    if self.b_painter_shadeless:
        set_material_shading(self,self,shadeless=True)
    else:    
        set_material_shading(self,self,shadeless=False)

def set_hotkeys(self,context):
    keymap = bpy.context.window_manager.keyconfigs.addon.keymaps['Image Paint']
    for item in keymap.keymap_items:
        if item.name == "Set Absolute Brush Size":
            item.active = self.b_painter_use_absolute_size
            
##############################        

class BPAINTER_HighPolyObjects(bpy.types.PropertyGroup):
    high_poly_obj: PointerProperty(type=bpy.types.Object)

class BPAINTER_TextureExport(bpy.types.PropertyGroup):
    name: StringProperty()
    
    TEXTURE_TYPE = []
    TEXTURE_TYPE.append(("GRAY","Gray","Gray"))
    TEXTURE_TYPE.append(("RGB","RGB","RGB"))
    TEXTURE_TYPE.append(("RGB+A","RGB+A","RGB+A"))
    TEXTURE_TYPE.append(("R+G+B","R+G+B","R+G+B"))
    TEXTURE_TYPE.append(("R+G+B+A","R+G+B+A","R+G+B+A"))
    
    export_type: EnumProperty(name="Texture Type",items=TEXTURE_TYPE, default="RGB" ,description="Set which Channels should be baked.")
    expand: BoolProperty(default=False)
    export: BoolProperty(default=True)

    mode: EnumProperty(items=(("BPainter Channel","BPainter Channel","BPainter Channel"),("Cycles Channel","Cycles Channel","Cycles Channel")))

    save_mode: EnumProperty(name="Save Mode",items=(("INTERNAL","Internal","Internal"),("EXTERNAL","External","External")))
    internal_image: StringProperty(subtype="FILE_NAME")
    
    high_poly_objs: CollectionProperty(type=BPAINTER_HighPolyObjects)
    low_poly_obj: PointerProperty(type=bpy.types.Object)
    target_uv: StringProperty(name="Target UV", description="Final UV Layout the maps are baked to.")

    resolution_x: IntProperty(name="X",min=1,soft_min=128,default=1024,subtype="PIXEL")
    resolution_y: IntProperty(name="Y",min=1,soft_min=128,default=1024,subtype="PIXEL")
    
    gray: EnumProperty(name="Paint Channel",items=get_paint_channels)
    rgb: EnumProperty(name="Paint Channel",items=get_paint_channels)
    r: EnumProperty(name="Paint Channel",items=get_paint_channels)
    g: EnumProperty(name="Paint Channel",items=get_paint_channels)
    b: EnumProperty(name="Paint Channel",items=get_paint_channels)
    a: EnumProperty(name="Paint Channel",items=get_paint_channels)
    
    ### normal map settings
    ao_samples: IntProperty(default=24,min=1)
    
    normal_r: EnumProperty(name="Normal Space",default="POS_X",items=(("POS_X","+X","Axis to bake in red channel:"), ("POS_Y","+Y","Axis to bake in red channel:"), ("POS_Z","+Z","Axis to bake in red channel:"), ("NEG_X","-X","Axis to bake in red channel:"), ("NEG_Y","-Y","Axis to bake in red channel:"), ("NEG_Z","-Z","Axis to bake in red channel:")))
    normal_g: EnumProperty(name="Normal Space",default="POS_Y",items=(("POS_X","+X","Axis to bake in green channel:"), ("POS_Y","+Y","Axis to bake in green channel:"), ("POS_Z","+Z","Axis to bake in green channel:"), ("NEG_X","-X","Axis to bake in green channel:"), ("NEG_Y","-Y","Axis to bake in green channel:"), ("NEG_Z","-Z","Axis to bake in green channel:")))
    normal_b: EnumProperty(name="Normal Space",default="POS_Z",items=(("POS_X","+X","Axis to bake in blue channel:"), ("POS_Y","+Y","Axis to bake in blue channel:"), ("POS_Z","+Z","Axis to bake in blue channel:"), ("NEG_X","-X","Axis to bake in blue channel:"), ("NEG_Y","-Y","Axis to bake in blue channel:"), ("NEG_Z","-Z","Axis to bake in blue channel:")))
    normal_space: EnumProperty(name="Normal Space", items=(("TANGENT","Tangent","Bake the normals in tangent space."), ("OBJECT","Object","Bake the normals in object space.")))
    
class BPAINTER_ImageSettings(bpy.types.PropertyGroup):
    def set_brush_lock_alpha(self,context):
        brush = context.tool_settings.image_paint.brush if context.tool_settings != None and context.tool_settings.image_paint != None else None
        brush.use_alpha = not(self.lock_alpha)

    lock_alpha: BoolProperty(name="Lock Alpha", default=False, update=set_brush_lock_alpha)
    active: BoolProperty(name="Active", default=False)
    color: FloatVectorProperty(name="Color", subtype="COLOR_GAMMA",min=0.0,max=1.0)

class BPAINTER_PaintLayers(bpy.types.PropertyGroup):
    def rename(self,context):
        if self.mat_name in bpy.data.materials:
            mat = bpy.data.materials[self.mat_name]
            tex = mat.texture_slots[self.index].texture
            tex.name = self.name
            tex.image.name = self.name
            mat.b_painter.paint_layers_index = mat.b_painter.paint_layers_index
    
    def set_paint_layer_active(self,context):
        mat = self.id_data
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        
        paint_channel["mask_layer_active"] = False
        paint_channel["paint_layer_active"] = True
        
        #self.id_data.b_painter["layer_information"][self.name] = [1,0]
        paint_channel.paint_layers_index = paint_channel.paint_layers_index
        
    def set_mask_layer_active(self,context):
        mat = self.id_data
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
        
        paint_channel["paint_layer_active"] = False
        paint_channel["mask_layer_active"] = True
        
        #self.id_data.b_painter["layer_information"][self.name] = [0,1]
        paint_channel.paint_layers_index = paint_channel.paint_layers_index
    
    def change_mask_mode(self,context):
        if self.mask_colorramp_node_name != "" and self.mask_mix_node_name != "":
            mat = self.id_data
            b_painter = mat.b_painter
            paint_channel = b_painter.paint_channel[b_painter.paint_channel_active]
            
            node_tree = bpy.data.node_groups[paint_channel.group_name]
            colorramp_node = node_tree.nodes[self.mask_colorramp_node_name]
            mask_mix_node = node_tree.nodes[self.mask_mix_node_name]
            mask_tex_node = node_tree.nodes[self.mask_tex_node_name]
            mask_invert_node = node_tree.nodes[self.mask_invert_node_name]
            if self.mask_mode == "BW_MASK":
                node_tree.links.new(mask_tex_node.outputs["Color"],mask_invert_node.inputs["Color"])
            elif self.mask_mode == "ALPHA_MASK":
                node_tree.links.new(mask_tex_node.outputs["Alpha"],mask_invert_node.inputs["Color"])
    
    def change_mask_mapping_mode(self,context):
        mat = self.id_data
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active] if b_painter.paint_channel_active in b_painter.paint_channel else None
        paint_layers = paint_channel.paint_layers
        paint_layer = paint_layers[paint_channel.paint_layers_index]
        
        node_tree = bpy.data.node_groups[paint_channel.group_name]
        mask_tex_node = node_tree.nodes[paint_layer.mask_tex_node_name]
        mask_mapping_node = None
        mask_coords_node = mask_tex_node.inputs["Vector"].links[0].from_node if len(mask_tex_node.inputs["Vector"].links) > 0 else None
        if mask_coords_node != None and mask_coords_node.type == "MAPPING":
            mask_mapping_node = mask_coords_node
            mask_coords_node = mask_mapping_node.inputs["Vector"].links[0].from_node if len(mask_mapping_node.inputs["Vector"].links) > 0 else None
        
        if mask_mapping_node == None:
            mask_mapping_node = node_tree.nodes.new("ShaderNodeMapping")     
            mask_mapping_node.location = mask_tex_node.location + Vector((0,-40))
            mask_mapping_node.hide = True
            mask_mapping_node.vector_type = "TEXTURE"
        
        if self.mask_mapping_mode == "UV_MAP":
            
            mask_tex_node.projection = "FLAT"
            
            new_mask_coords_node = node_tree.nodes.new("ShaderNodeUVMap")
            new_mask_coords_node.location = mask_tex_node.location + Vector((0,-80))
            new_mask_coords_node.hide = True
            node_tree.links.new(mask_mapping_node.inputs["Vector"],new_mask_coords_node.outputs["UV"])
            
            if mask_coords_node != None:
                node_tree.nodes.remove(mask_coords_node)
        
        elif self.mask_mapping_mode == "BOX_MAP":
            mask_tex_node.projection = "BOX"
            
            new_mask_coords_node = node_tree.nodes.new("ShaderNodeTexCoord")
            new_mask_coords_node.location = mask_tex_node.location + Vector((0,-80))
            new_mask_coords_node.hide = True
            new_mask_coords_node.outputs["Reflection"].enabled = False
            new_mask_coords_node.outputs["Window"].enabled = False
            new_mask_coords_node.outputs["Camera"].enabled = False
            new_mask_coords_node.outputs["Normal"].enabled = False
            node_tree.links.new(mask_mapping_node.inputs["Vector"],new_mask_coords_node.outputs["Object"])
            
            if mask_coords_node != None:
                node_tree.nodes.remove(mask_coords_node)
                
        node_tree.links.new(mask_tex_node.inputs["Vector"],mask_mapping_node.outputs["Vector"])        
                
        
                
    def change_mapping_mode(self,context):
        mat = self.id_data
        b_painter = mat.b_painter
        paint_channel = b_painter.paint_channel[b_painter.paint_channel_active] if b_painter.paint_channel_active in b_painter.paint_channel else None
        paint_layers = paint_channel.paint_layers
        paint_layer = paint_layers[paint_channel.paint_layers_index]
        
        node_tree = bpy.data.node_groups[paint_channel.group_name]
        tex_node = node_tree.nodes[paint_layer.tex_node_name]
        
        
        mapping_node = None
        coords_node = tex_node.inputs["Vector"].links[0].from_node if len(tex_node.inputs["Vector"].links) > 0 else None
        opacity_node = tex_node.outputs["Alpha"].links[0].to_node
        opacity_node.location = tex_node.location + Vector((0,-120))
        if coords_node.type == "MAPPING":
            mapping_node = coords_node
            coords_node = mapping_node.inputs["Vector"].links[0].from_node if len(mapping_node.inputs["Vector"].links) > 0 else None
            
        if mapping_node == None:
            mapping_node = node_tree.nodes.new("ShaderNodeMapping")     
            mapping_node.location = tex_node.location + Vector((0,-40))
            mapping_node.hide = True
            mapping_node.vector_type = "TEXTURE"
        
        if self.mapping_mode == "UV_MAP":
            tex_node.projection = "FLAT"
            if coords_node == None or (coords_node != None and coords_node.type != "UVMAP"):
                new_coords_node = node_tree.nodes.new("ShaderNodeUVMap")
                new_coords_node.location = tex_node.location + Vector((0,-80))
                new_coords_node.hide = True
                node_tree.links.new(mapping_node.inputs["Vector"],new_coords_node.outputs["UV"])
                if coords_node != None:
                    node_tree.nodes.remove(coords_node)
                
        elif self.mapping_mode == "BOX_MAP":
            tex_node.projection = "BOX"
            if coords_node == None or (coords_node != None and coords_node.type != "TEX_COORD"):
                new_coords_node = node_tree.nodes.new("ShaderNodeTexCoord")
                new_coords_node.location = tex_node.location + Vector((0,-80))
                new_coords_node.hide = True
                new_coords_node.outputs["Reflection"].enabled = False
                new_coords_node.outputs["Window"].enabled = False
                new_coords_node.outputs["Camera"].enabled = False
                new_coords_node.outputs["Normal"].enabled = False
                node_tree.links.new(mapping_node.inputs["Vector"],new_coords_node.outputs["Object"])
                if coords_node != None:
                    node_tree.nodes.remove(coords_node)
        node_tree.links.new(tex_node.inputs["Vector"],mapping_node.outputs["Vector"])

    
    name: StringProperty(update=rename)
    index: IntProperty()
    layer_type: StringProperty()
    mat_name: StringProperty()
    tex_node_name: StringProperty()
    mix_node_name: StringProperty()
    paint_channel_node_name: StringProperty()
    mask_mix_node_name: StringProperty()
    mask_tex_node_name: StringProperty()
    mask_colorramp_node_name: StringProperty()
    mask_invert_node_name: StringProperty()
    mask_img_name: StringProperty()
    img_name: StringProperty()
    node_tree_name: StringProperty()
    merge_layer: BoolProperty(default=False)
    paint_layers_index: IntProperty()
    
    mask_mode: EnumProperty(items=(("BW_MASK","BW Mask","BW Mask","IMAGE_ALPHA",0),("ALPHA_MASK","Alpha Mask","Alpha Mask","IMAGE_RGB_ALPHA",1)),update=change_mask_mode)
    mask_mapping_mode: EnumProperty(items=(("UV_MAP","UV Map","Uv Map"),("BOX_MAP","Box Map","Box Map")),description="UV or Box Mapping. Box Mapping projects the image from all sides onto the model and blends.",update=change_mask_mapping_mode)
    mapping_mode: EnumProperty(items=(("UV_MAP","UV Map","Uv Map"),("BOX_MAP","Box Map","Box Map")),description="UV or Box Mapping. Box Mapping projects the image from all sides onto the model and blends.",update=change_mapping_mode)
    
    ### procedural tex
    proc_tex_node_name: StringProperty()
    proc_ramp_node_name: StringProperty()
    
    ### mask and paint bool
    paint_layer_active: BoolProperty(default=True,update=set_paint_layer_active)
    mask_layer_active: BoolProperty(default=False,update=set_mask_layer_active)

class BPAINTER_AvailableChannelInputs(bpy.types.PropertyGroup):
    name: StringProperty()
    shader_name: StringProperty()
    linked_shader_name: StringProperty()
    checked: BoolProperty(default=False)
    locked: BoolProperty(default=False)
    type: StringProperty()

class BPAINTER_PaintChannels(bpy.types.PropertyGroup):
    name: StringProperty()
    group_name: StringProperty()
    paint_layers_index: IntProperty(default=0, min=0, update=set_paint_layer)
    paint_layers: CollectionProperty(type=BPAINTER_PaintLayers)

class BPAINTER_Properties(bpy.types.PropertyGroup):
    def set_merge_layers_index(self,context):
        self["merge_layers_index"] = -1

    paint_channel_active: EnumProperty(name="Paint Channel",items=get_paint_channel,update=update_paint_channel)
    paint_channel: CollectionProperty(type=BPAINTER_PaintChannels)
    paint_channel_parent_name: StringProperty()
    node_tree_name: StringProperty()
    merge_layers: CollectionProperty(type=BPAINTER_PaintLayers)
    merge_layers_index: IntProperty(default=-1, update=set_merge_layers_index)
    expanded: BoolProperty(default=True)
    external_path: StringProperty(name="BPAINTER_MERGE_TextureSlotExternal Image Path",description="If this path is set, images will be exported on blendfile save.")
    preview_aspect_ratio: IntVectorProperty(default=(1,1),size=2)
    
class BPAINTER_BrushSettings(bpy.types.PropertyGroup):
    hardness: FloatProperty(min=0.0,max=1.0)

def get_b_painter_active_materials(self):
    if "b_painter_active_material" in self:
        if self.type == "MESH" and self.data and len(self.data.materials) - 1 < self["b_painter_active_material"]:
            self["b_painter_active_material"] = 0
        return self["b_painter_active_material"]
    else:
        return 0

def set_b_painter_active_materials(self, value):
    self["b_painter_active_material"] = value

def register():
    bpy.types.WindowManager.b_painter_restart_needed = BoolProperty(default=False)
    bpy.types.WindowManager.b_painter_modal_update = BoolProperty(default=False)
    bpy.types.WindowManager.b_painter_in_view_3d = BoolProperty(default=False)
    bpy.types.WindowManager.b_painter_brush_textures_loaded = BoolProperty(default=False)
    bpy.types.WindowManager.b_painter_stencil_textures_loaded = BoolProperty(default=False)
    bpy.types.WindowManager.b_painter_update_brushes = BoolProperty(default=True)
    bpy.types.WindowManager.b_painter_brush_filter = StringProperty(default="",update=update_brush_filter,options={'TEXTEDIT_UPDATE'})
    bpy.types.Scene.b_painter_texture_preview = BoolProperty(default=False)
    
    bpy.types.Image.b_painter = PointerProperty(type=BPAINTER_ImageSettings)

    bpy.types.Object.b_painter_active_material = EnumProperty(name="Active Material",items=get_object_materials, update=set_active_material, get=get_b_painter_active_materials, set=set_b_painter_active_materials)
    bpy.types.Object.b_painter_shadeless = BoolProperty(name="Shading Mode",description="Make all Materials shadeless.",default=False,update=set_mat_shading)

    bpy.types.Material.b_painter = PointerProperty(type=BPAINTER_Properties)
    bpy.types.ShaderNodeMixRGB.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeGroup.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeRGBCurve.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeHueSaturation.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeInvert.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeValToRGB.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)
    bpy.types.ShaderNodeTexImage.b_painter_layer_hide = BoolProperty(default=False,update=set_show_hide)

    bpy.types.ShaderNodeMath.b_painter_opacity = FloatProperty(default=1.0,min=0.0,max=1.0,update=set_b_painter_opacity)
    bpy.types.ShaderNodeHueSaturation.b_painter_opacity = FloatProperty(default=1.0,min=0.0,max=1.0,update=set_b_painter_opacity)
    bpy.types.ShaderNodeRGBCurve.b_painter_opacity = FloatProperty(default=1.0,min=0.0,max=1.0,update=set_b_painter_opacity)
    bpy.types.ShaderNodeInvert.b_painter_opacity = FloatProperty(default=1.0,min=0.0,max=1.0,update=set_b_painter_opacity)
    bpy.types.ShaderNodeGroup.b_painter_opacity = FloatProperty(default=1.0,min=0.0,max=1.0,update=set_b_painter_opacity)

    bpy.types.Brush.b_painter_hardness = FloatProperty(min=0.0,max=1.0,update=set_brush_hardness)
    bpy.types.Scene.b_painter_absolute_size = FloatProperty(default=50,min=1,max=10000,soft_max=500,subtype="PIXEL")
    bpy.types.Scene.b_painter_use_absolute_size = BoolProperty(default=False,update=set_hotkeys,description="Constraint Brush Size to Zoom.")
    bpy.types.Scene.b_painter_flip_template_list = BoolProperty(name="Flip Layer Stack",default=True)

    bpy.types.Texture.b_painter_use_mask = BoolProperty(default=False,update=mute_ramp)
    bpy.types.Texture.b_painter_invert_mask = BoolProperty(default=False,update=invert_ramp)
    bpy.types.Texture.b_painter_invert_stencil_mask = BoolProperty(default=False,update=invert_stencil_ramp)
    bpy.types.Texture.b_painter_edit_tex = BoolProperty(default=False)

    bpy.types.Brush.b_painter_use_mask = BoolProperty(default=True,update=mute_ramp)
    bpy.types.Brush.b_painter_invert_mask = BoolProperty(default=True,update=invert_ramp)
    bpy.types.Brush.b_painter_invert_stencil_mask = BoolProperty(default=True,update=invert_stencil_ramp)
    bpy.types.Brush.b_painter_ramp_tonemap_l = FloatProperty(default=0.0,min=0.0,max=1.0,update=tonemap)
    bpy.types.Brush.b_painter_ramp_tonemap_r = FloatProperty(default=1.0,min=0.0,max=1.0,update=tonemap)
    bpy.types.Brush.b_painter_stencil_ramp_tonemap_l = FloatProperty(default=0.0,min=0.0,max=1.0,update=tonemap_stencil)
    bpy.types.Brush.b_painter_stencil_ramp_tonemap_r = FloatProperty(default=1.0,min=0.0,max=1.0,update=tonemap_stencil)
    bpy.types.Brush.b_painter_brush_order = IntProperty(default=0)


    bpy.types.Scene.b_painter_export_list = CollectionProperty(type=BPAINTER_TextureExport)
    bpy.types.Scene.b_painter_export_list_index = IntProperty(default=-1,max=-1)
    bpy.types.Scene.b_painter_export_path = StringProperty(subtype="DIR_PATH")

    bpy.types.Scene.b_painter_layer_mode = EnumProperty(items=(("Paint Layer","Paint Layer","Paint Layer"),("Mask Layer","Mask Layer","Mask Layer")))
    bpy.types.Scene.b_painter_show_stencil_settings = BoolProperty(default=True)
    bpy.types.Scene.b_painter_show_brush_settings = BoolProperty(default=True)
    bpy.types.Scene.b_painter_show_brush = BoolProperty(default=True)
    bpy.types.Scene.b_painter_show_layer_settings = BoolProperty(default=True)
    bpy.types.Scene.b_painter_show_color_settings = BoolProperty(default=True)
    bpy.types.Scene.b_painter_show_color_wheel = BoolProperty(default=False)
    bpy.types.Scene.b_painter_show_color_palette = BoolProperty(default=True)

    # bpy.types.Scene.b_painter_brush = EnumProperty(items=get_brushes,update=set_brush,get=get_b_painter_active_brush, set=set_b_painter_active_brush)
    # bpy.types.Scene.b_painter_brush = EnumProperty(items=get_brushes,update=set_brush)
    bpy.types.Scene.b_painter_brush = EnumProperty(items=get_brushes,get=get_b_painter_active_brush, set=set_b_painter_active_brush)

    #####
    bpy.types.Brush.b_painter_brush_texture = EnumProperty(items=get_brush_tex_previews,update=set_texture)
    bpy.types.Brush.b_painter_stencil_texture = EnumProperty(items=get_stencil_tex_previews,update=set_stencil_texture)
    bpy.types.Brush.b_painter_tex_brush_categories = EnumProperty(items=get_category_dirs,name="Texture Categories",update=refresh_brush_category)
    bpy.types.Scene.b_painter_tex_stencil_categories = EnumProperty(items=get_category_dirs,name="Stencil Categories",update=refresh_stencil_category)
    bpy.types.Scene.b_painter_active_stencil_category = StringProperty(default="None")
    bpy.types.Scene.b_painter_active_tex_brush_category = StringProperty(default="None")
    bpy.types.Scene.b_painter_active_tex_brush = StringProperty(default="None")

    bpy.types.Brush.b_painter_multi_layer_brush = BoolProperty(default=False)

    bpy.types.Scene.b_painter_load_first_time = BoolProperty(default=True)

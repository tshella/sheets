# Bake-to-Vertex-Color
Transfer Image to selected Vertex Color in all selected Objects


The word "bake" is an exaggeration!

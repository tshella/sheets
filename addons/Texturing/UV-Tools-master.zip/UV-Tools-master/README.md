# Lightmap Auto UV
Script makes automatic UV unwrap for lightmaps and helps to avoid a pixel sharing issue by islands.
Original author: Tomasz Muszynski

![image](https://raw.githubusercontent.com/muchasty/UV-Tools/master/Information%20%26%20License/LightmapAutoUV.JPG)


# Sure UVW Map - Blender 2.80 Port
Box / Best Planar UVW Map (Make Material With Raster Texture First!)
Original author: Alexander Milovsky

![image](https://raw.githubusercontent.com/muchasty/UV-Tools/master/Information%20%26%20License/SureUVWMap.jpg)


# UV Equalize  - Blender 2.80 Port
This add-on Equalizes scale of UVs of selected objects to active object.
Original author: Jakub Uhlik

Blender 2.80 probably has a bug that does not allow to process the transformation.resize properlly.
Wait for an update.
https://developer.blender.org/T59198

